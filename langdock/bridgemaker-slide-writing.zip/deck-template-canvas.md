# Deck-Template (Kopiervorlage)

Bevorzugt per DATEIOPERATION in die Arbeitsdatei übernehmen; nur
wenn das nicht geht, den kompletten Codeblock-Inhalt — von
`<!doctype html>` bis zur letzten Zeile — unverändert abschreiben.
Nichts weglassen, nichts umbauen. Der Kommentar in Zeile 2
(BM-DECK-TEMPLATE) muss im Ergebnis stehen.

````html
<!doctype html>
<!-- BM-DECK-TEMPLATE v2 — Pflicht-Marker, niemals entfernen: das Quality-Gate prüft ihn -->
<html lang="de">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Bridgemaker — Deck-Template</title>

<!-- ============================================================
     BRIDGEMAKER DECK-TEMPLATE (guidelines/07 §7.8)
     Neufassung 2026-07-17 nach dem Nordstern-Review:
     Linien statt Boxen. Visuelle Referenz:
     ../assets/referenz/website-2026-07/

     So benutzt du dieses File:
     1. Kopieren, umbenennen, dann pro Slide: erst die
        ARGUMENTSTRUKTUR des Inhalts bestimmen (gleichrangig?
        Kontrast? Ursachen → Resultat? Tabelle? benannte Dinge?),
        dann das passende Layout unten wählen. Layouts NICHT neu
        erfinden; duplizieren und umsortieren ist ausdrücklich okay.
     2. Das File muss einen Ordner tief im Brandbook-Repo liegen
        (../tokens/tokens.css und ../assets/... müssen auflösen).
        Kundenarbeit: Projekt-Kit außerhalb des Repos (Skill
        bridgemaker-slides).
     3. Weitergabe IMMER als PDF: im Browser Drucken → als PDF
        sichern (eine Seite pro Slide, macht deck-stage.js).

     Deck-Regeln — nicht verhandelbar:
     - NORDSTERN: Eine Bridgemaker-Slide ist Typografie auf ruhigem
       Grund, gegliedert durch Linien. Boxen sind die Ausnahme mit
       Bedeutung (benanntes Ding, Zitat, Bühne für Illustration).
       Reine Information (Listen, Zahlen, Vergleiche, Prozesse)
       läuft über Hairlines, Spalten und Abstände — nie über Karten.
     - DIE HEADLINE STEHT: Auf jeder Content-Slide beginnt die
       Headline an exakt derselben Position (das Grundgerüst unten
       erzwingt das). Der Inhalt füllt den Raum darunter — nie
       umgekehrt. Beim Durchblättern darf nichts springen.
     - GRUND KONSTANT SAND (Off-White) auf allen Content-Slides.
       Ausnahmen nur mit Bedeutung: Kapiteltrenner (Kapitelband),
       Cover/Schluss (dunkel), max. eine Moment-Slide (Zitat).
     - TÖNUNG BRAUCHT BEDEUTUNG: Dieselbe Surface darf sich frei
       wiederholen — Uniformität ist Ruhe. Unterschiedliche
       Tönungen nur, wenn der Unterschied etwas sagt (Identität,
       Kategorie, Rolle). SCHACHBRETT-ALTERNANZ IST VERBOTEN.
       Summen-/Resultat-Elemente anders exponieren als die Reihe
       darüber (Rolle = Behandlung → .result-band).
     - EINE LINIEN-EBENE PRO FLÄCHE: Die Hairline hat pro Slide
       genau einen Job (Spalten eröffnen ODER Zeilen trennen).
       Sie bindet sich durch Nähe an ihren Inhalt. Zwischen-
       überschriften trennen sich durch Raum, nicht durch eigene
       Striche. Nie Linien-Listen IN Karten stapeln.
     - GRAFIKEN WERDEN GEBAUT (§7.11): Diagramme, Timelines und
       Schaubilder aus der Formensprache — erster Draft reicht,
       iteriert wird gemeinsam. Bei unklarer Datenlage EINE
       Inhalts-Rückfrage, dann bauen. Der gestreifte Platzhalter
       bleibt NUR für Bild-Assets (Fotos, CD-Bildwelt, Logos).
     - Typografie = die normalen type-*-Klassen aus tokens.css
       (der Deck-Layer pinnt nur die clamp()-Stufen). Große
       Ziffern IMMER in Inter — Mono existiert in der UI nicht
       mehr, es bleibt nur für echten Code und Platzhalter-Captions.
     - Kopf- und Fußzeile als System (jede Slide außer den
       Moment-Slides Cover, Zitat und Schluss, immer an exakt
       derselben Position): Kopfzeile =
       NUR das Kapitel-Label „NN / Kapitel" links (type-eyebrow,
       neutral). Fußzeile = Wortmarke (14px) + Kunde/Projekt
       links, Seitenzahl rechts (12px Inter, CSS-Counter).
     - HEADLINES: max. ZWEI ZEILEN — redigieren statt schrumpfen,
       keine willkürlichen max-widths. Umbruch nach Sinn per
       <br /> (dann style="text-wrap: initial"); Gedankenstrich
       nie am Zeilenanfang; im Fließtext Gedankenstriche GANZ
       vermeiden (AI-Slop-Signal), in Headlines als Struktur ok.
     - Max. DREI TEXTGRÖSSEN pro Seite: Headline / Content / Meta
       (12px). Quellen und Fußnoten laufen als .source-note im
       Meta-Register, nie als eigene Stufe.
     - RAUM: Boxen umschließen ihren Inhalt eng — Leerraum lebt
       auf Slide-Ebene, nicht in aufgeblasenen Karten. Grafiken
       füllen ihre Spalte über die Geometrie (viewBox), nie durch
       Skalieren. Ausrichtung übers Layout-System, nie Pixel
       schieben. Box-Reihen: gemeinsame Unterkante + gleiche Höhe
       (min-height im 8px-Raster).
     - Arbeitsstände („folgt nach Freigabe") NIE auf die Slide —
       sie gehören in die Speaker Notes (script#speaker-notes,
       deck-stage.js liest sie).
     - Moment-Flächen: Cover = Charcoal + bg-kasane-cta + topo-
       grafische Konturen (rechts dicht, links offen zum Text —
       wie der Website-Hero; Generator: deck-topo-konturen.js).
       Schluss = Footer-Verlauf (Token bg-contact-cta-static)
       + konzentrische Konturen um den Content, volle Stärke.
       Kapitelbänder bg-kasane-band-*. Vibrante Website-Rezepte
       sind in Decks tabu. Topo-Linien sind Blickführung um den
       Content, nie Deko-Gewusel. Auf Dunkel: Headlines
       --off-white, Fließtext --soft, Links --bm-lavender-dark.
     - Badges nach Vokabular (§7.6): Semantik-Badge (Tint+Deep),
       Themen-Tag (Outline, max. 3), Werte NIE als Badge (→
       .meta-row), Arbeitsstände NIE im Layout. Nur auf Sand/Weiß.
     - Voice: Texte werden in Bridgemaker-Sprache REDIGIERT
       (Aussage bleibt, Sprache wird unsere — 08-voice.md): Du/ihr,
       Headlines ohne Schlusspunkt, keine Meta-/Prozesssätze, kein
       Middot, Gedankenstriche sparsam, kein „→" im Fließtext.
     - Decks sind STATISCH (PDF-Artefakt): keine Animationen,
       kein kasane-drift, keine Hover-Effekte.
     - Icons: NUR Material Symbols Outlined (.msym), einfarbig in
       der Textfarbe des Kontexts (hell: Charcoal), nie in
       Markenfarben, funktional — nie als Zeilenschmuck.
     - Wortmarke auf Cover und Schluss (../assets/logos/).
     - SEHPFLICHT vor jeder Abgabe: PDF rendern, jede Seite gegen
       die Checkliste im Skill bridgemaker-slides prüfen,
       korrigieren, erneut rendern.
     ============================================================ -->

<style>
/* ==== tokens.css (inline für Canvas) ==== */
/* ============================================================
   Bridgemaker Design Tokens — v2.0 (2026-07-14)
   Quelle der Wahrheit: bridgemaker-website/src/app/globals.css
   (Stand Juli 2026). Portabel — kein Framework nötig.
   Regeln & Einsatz: guidelines/ (Kapitel 01–09).

   Hinweis für Tailwind-v4-Projekte: handgeschriebene
   backdrop-filter-Deklarationen in @layer-Blöcken werden von der
   Tailwind-/Lightning-Pipeline gestrippt — dort den Frost über
   Tailwind-Utilities am Element setzen (backdrop-blur-xl,
   backdrop-saturate-150). In diesem framework-freien Stylesheet ist
   backdrop-filter direkt enthalten. Siehe guidelines/04 §4.7.
   ============================================================ */

:root {
  /* ---------- Typografie ---------- */
  --font-sans: "Inter", -apple-system, BlinkMacSystemFont, sans-serif;
  /* Mono ausschließlich für echte Code-Darstellung und Platzhalter-
     Captions — nie für UI-Text (Eyebrows, Badges, KPIs, Nummerierungen,
     Meta-Zeilen, Chart-Achsen laufen in Inter). Stand Website 2026-07-16. */
  --font-mono: "JetBrains Mono", "Menlo", monospace;
  /* Display = Inter (kein separates Inter Display — v2-Entscheidung) */
  --font-display: var(--font-sans);

  /* ---------- Markenfarben — Familien ---------- */
  --bm-purple:        #6B4A94;
  --bm-deep-plum:     #4A2D6B;
  --bm-lavender:      #9070B8;
  --bm-soft-purple:   #C4B1DC;
  --bm-purple-tint:   #EDE3F5;
  --bm-lavender-dark: #AF94D2; /* Links/Buttons auf Dunkel — nie rohes Purple */

  --bm-berry:         #B84A6F;
  --bm-deep-berry:    #8A3050;
  --bm-dusty-rose:    #D4809A;
  --bm-rose-tint:     #F5E0E8;

  --bm-teal:          #3A9E97;
  --bm-deep-teal:     #1D6B66;
  --bm-soft-teal:     #7EC4BE;
  --bm-teal-tint:     #E0F2F0;

  /* Sage als benannte Farbe gestrichen (2026-07-14) — Grüntöne existieren
     nur noch als Bestandteile der Gradient-Rezepte und als surface-sage. */

  /* ---------- Neutrals ---------- */
  --charcoal:  #1C1C1E;
  --dark:      #3D3D3A;
  --mid:       #6B6B65;
  --soft:      #A8A69E; /* Fließtext auf Dunkel */
  --light:     #918F87; /* Eyebrows */
  --off-white: #F5F1EB; /* Grundton der Seite */
  --white:     #FFFFFF; /* Sektionsfläche im Flächenrhythmus */

  /* ---------- Surfaces ---------- */
  --surface-stone:     #E8E5DF;
  --surface-mauve:     #E3E0E8;
  --surface-sage:      #DDE4E0;
  --surface-sand:      #E5E0D8;
  --surface-mid-stone: #C5C0B8; /* = Rand-/Trennlinien-Wert */
  --surface-dark:      #333330;

  /* ---------- Spacing (8px-Raster, 4px halbe Stufe) ---------- */
  --space-1:  4px;
  --space-2:  8px;
  --space-3:  12px;
  --space-4:  16px;
  --space-5:  20px;
  --space-6:  24px;
  --space-8:  32px;
  --space-10: 40px;
  --space-12: 48px;
  --space-16: 64px;
  --space-20: 80px;
  --space-24: 96px;  /* Standard-Sektions-Padding (py) */
  --space-30: 120px;

  /* ---------- Radien ---------- */
  --radius-sm:   8px;
  --radius-md:   12px;  /* Inputs — nie Pill */
  --radius-lg:   16px;
  --radius-xl:   20px;  /* Karten, Bilder */
  --radius-2xl:  28px;
  --radius-pill: 999px; /* Buttons, Pills, Chips — IMMER Pill */

  /* ---------- Schatten (sparsam) ---------- */
  --shadow-xs: 0 1px 2px rgba(28,28,30,0.04);
  --shadow-sm: 0 2px 8px rgba(28,28,30,0.05);
  --shadow-md: 0 6px 24px rgba(28,28,30,0.08);
  --shadow-lg: 0 16px 48px rgba(28,28,30,0.12);

  /* ---------- Ränder ----------
     subtle: Default für Trennlinien, Umriss-Boxen, Tabellenlinien.
     hairline: nur weiche innere Unterteilungen (= Karten-Inset-Ton).
     strong: Fokusringe, aktive Umrisse, Sekundär-Button-Kontur. */
  --border-hairline: 1px solid rgba(28,28,30,0.06);
  --border-subtle:   1px solid #C5C0B8;
  --border-strong:   1.5px solid var(--bm-purple);

  /* ---------- Motion ---------- */
  --duration-fast: 150ms;
  --duration-base: 240ms;
  --duration-slow: 400ms;
  --ease-out:    cubic-bezier(0.22, 1, 0.36, 1);
  --ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1); /* nur verspielte Mikro-Interaktionen */
  /* Swaps & Ambient-Loops: CSS-Keyword ease-in-out */

  /* ---------- Container ---------- */
  --container-max: 1200px;
  --container-pad: 16px; /* ab Desktop 32px */
}

/* ============================================================
   LEGACY-ALIASE (v1) — deprecated, nur für Altbestände.
   Neu: type-*-Klassen und --duration-* verwenden.
   ============================================================ */
:root {
  --bm-lavender-on-dark: var(--bm-lavender-dark);
  --dur-fast: var(--duration-fast);
  --dur-base: var(--duration-base);
  --dur-slow: var(--duration-slow);
  --text-display-xl: 400 128px/1.00 var(--font-display);
  --text-display-l:  500 96px/1.05 var(--font-display);
  --text-display:    600 64px/1.10 var(--font-display);
  --text-h1:      600 48px/1.15 var(--font-display);
  --text-h2:      600 32px/1.25 var(--font-display);
  --text-h3:      500 24px/1.30 var(--font-display);
  --text-h4:      500 20px/1.40 var(--font-display);
  --text-body:    400 16px/1.60 var(--font-sans);
  --text-body-l:  400 18px/1.55 var(--font-sans);
  --text-small:   400 14px/1.50 var(--font-sans);
  --text-caption: 400 12px/1.40 var(--font-sans);
  --text-eyebrow: 500 12px/1.40 var(--font-sans);
  --btn-h: 44px;
  --btn-radius: var(--radius-pill);
}
/* Legacy (v1): weiße Box mit dezentem Lift — neu: .bm-card + .card-clean */
.bm-lift {
  background: var(--white);
  border-radius: var(--radius-xl);
  box-shadow: 0 1px 2px rgba(28,28,30,0.04), 0 0 0 1px rgba(28,28,30,0.03);
}

/* ============================================================
   Base-Reset — konservativ, nur das Nötige.
   ============================================================ */
*, *::before, *::after { box-sizing: border-box; }
html { -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; }
body {
  margin: 0;
  font: 400 16px/1.60 var(--font-sans);
  color: var(--charcoal);
  background: var(--off-white);
  text-wrap: pretty;
}
a { color: inherit; text-decoration: none; }
/* Hover-Unterstreichung NUR für reine Textlinks (guidelines/07 §7.5) */
a:not([class]):hover, a.bm-link:hover { text-decoration: underline; text-underline-offset: 3px; }

/* ============================================================
   Typografie — fluide type-*-Skala (guidelines/03).
   Große Stufen via clamp(); Tracking dort in em (skaliert mit).
   ============================================================ */
.type-display-xl { font-size: clamp(64px, 9vw, 128px); font-weight: 400; line-height: 1.00; letter-spacing: -0.03em; }
.type-display-l  { font-size: clamp(52px, 7.5vw, 96px); font-weight: 500; line-height: 1.05; letter-spacing: -0.03em; }
.type-display    { font-size: clamp(40px, 5.5vw, 64px); font-weight: 600; line-height: 1.10; letter-spacing: -0.03em; }
.type-h1         { font-size: clamp(32px, 4.2vw, 48px); font-weight: 600; line-height: 1.15; letter-spacing: -0.025em; }
.type-h2         { font-size: clamp(26px, 3vw, 32px);   font-weight: 600; line-height: 1.25; letter-spacing: -0.025em; }
.type-stat       { font-size: clamp(28px, 3vw, 36px);   font-weight: 500; line-height: 1.10; letter-spacing: -0.025em; }
.type-h3         { font-size: 24px; font-weight: 500; line-height: 1.30; letter-spacing: -0.5px; }
.type-h4         { font-size: 20px; font-weight: 500; line-height: 1.40; letter-spacing: -0.3px; }
.type-card-title { font-size: 18px; font-weight: 600; line-height: 1.45; letter-spacing: -0.3px; }
.type-h5         { font-size: 16px; font-weight: 500; line-height: 1.45; letter-spacing: -0.2px; }
.type-body-l     { font-size: 18px; font-weight: 400; line-height: 1.55; }
.type-body       { font-size: 16px; font-weight: 400; line-height: 1.60; }
.type-nav        { font-size: 15px; font-weight: 500; line-height: 1.40; }
.type-small      { font-size: 14px; font-weight: 400; line-height: 1.50; }
.type-caption    { font-size: 12px; font-weight: 400; line-height: 1.40; }
.type-eyebrow    { font-size: 12px; font-weight: 500; line-height: 1.40; letter-spacing: 0.10em; text-transform: uppercase; }
.type-micro      { font-size: 10px; font-weight: 400; line-height: 1.40; }

/* ============================================================
   Karten-Familie — Paper & Glass (guidelines/04).
   Karten sitzen auf der Seite, sie fliegen nicht.
   ============================================================ */

/* Basis: Fläche + Radius + Padding (mit card-clean/-elevated kombinieren) */
.bm-card { background: var(--white); border-radius: var(--radius-xl); padding: var(--space-8); }
.bm-card-stone { background: var(--surface-stone); }
.bm-card-mauve { background: var(--surface-mauve); }
.bm-card-sage  { background: var(--surface-sage); }
.bm-card-sand  { background: var(--surface-sand); }
.bm-card-dark  { background: var(--charcoal); color: var(--off-white); }

/* Paper — weiße matte Karte: knackige Inset-Haarlinie + nahe Elevation */
.card-clean {
  box-shadow:
    inset 0 0 0 1px rgba(28, 28, 30, 0.06),
    0 1px 2px rgba(28, 28, 30, 0.03),
    0 10px 24px -18px rgba(28, 28, 30, 0.10);
}

/* Paper — getönte matte Karte: identisches Treatment */
.card-elevated {
  box-shadow:
    inset 0 0 0 1px rgba(28, 28, 30, 0.06),
    0 1px 2px rgba(28, 28, 30, 0.04),
    0 10px 24px -18px rgba(28, 28, 30, 0.12);
}

/* Glass — gefrostete Karte über Gradients. Bewusst transluzent. */
.card-glass {
  background-image: linear-gradient(135deg, rgba(255,255,255,0.72), rgba(255,255,255,0.46));
  -webkit-backdrop-filter: blur(24px) saturate(1.5);
  backdrop-filter: blur(24px) saturate(1.5);
  box-shadow:
    inset 0 1px 0 0 rgba(255, 255, 255, 0.9),
    inset 0 0 0 1px rgba(255, 255, 255, 0.55),
    0 0 0 1px rgba(28, 28, 30, 0.04),
    0 1px 2px rgba(28, 28, 30, 0.05),
    0 6px 16px -8px rgba(28, 28, 30, 0.12);
}

/* Hero-Glass — echte Milchglasscheibe. Karte darf selbst KEINEN filter
   tragen (Compositing-Falle, guidelines/04 §4.7). */
.hero-card-glass {
  -webkit-backdrop-filter: blur(40px) saturate(1.5) brightness(1.05);
  backdrop-filter: blur(40px) saturate(1.5) brightness(1.05);
  box-shadow:
    inset 0 1px 0 0 rgba(255, 255, 255, 0.85),
    inset 0 0 0 1px rgba(255, 255, 255, 0.4),
    0 2px 6px rgba(28, 28, 30, 0.08),
    0 30px 60px -18px rgba(28, 28, 30, 0.18);
}

/* Milchige Scheibe: über dem Ghost, unter dem Inhalt.
   ▲ MILCHIGKEIT: die letzten Weiß-Werte (0.6/0.4) —
     niedriger = glasiger, höher = deckender/matter. */
.hero-card-veil {
  background:
    radial-gradient(120% 60% at 18% -10%, rgba(255,255,255,0.45), transparent 55%),
    linear-gradient(115deg, rgba(255,255,255,0.25) 0%, rgba(255,255,255,0) 30%),
    linear-gradient(135deg, rgba(255,255,255,0.6), rgba(255,255,255,0.4));
}

/* Ergebnis-Leiste über Bildern. Bild darunter: kein filter/blend-mode! */
.case-glass {
  background: linear-gradient(180deg, rgba(255,255,255,0.62), rgba(255,255,255,0.78));
  -webkit-backdrop-filter: blur(24px) saturate(1.5);
  backdrop-filter: blur(24px) saturate(1.5);
  box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.6);
}

/* Pop-Schatten — max. eine Featured-Box pro Seite */
.shadow-pop { box-shadow: 0 18px 44px -18px rgba(28, 28, 30, 0.45); }

/* ============================================================
   Grain — Filmkorn-Finish (guidelines/04 §4.4).
   Als absolutes Overlay (pointer-events-none) einsetzen.
   ============================================================ */
.grain {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
  background-size: 150px 150px;
  mix-blend-mode: multiply;
  opacity: 0.12;
}
.grain-screen {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.8' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
  background-size: 150px 150px;
  mix-blend-mode: screen;
  opacity: 0.1;
}
/* Alpha-Rauschen ohne Blend-Mode — hält Backdrop-Sampling intakt
   (für Bilder UNTER Glasscheiben) */
.grain-photo {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3CfeColorMatrix type='matrix' values='0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.9 0.9 0.9 0 -0.9'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
  background-size: 150px 150px;
  opacity: 0.22;
}
.grain-photo-screen {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='200' height='200'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.65' numOctaves='3' stitchTiles='stitch'/%3E%3CfeColorMatrix type='saturate' values='0'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
  background-size: 150px 150px;
  mix-blend-mode: screen;
  opacity: 0.34;
}

/* ============================================================
   Kasane-Drift — Ambient-Motion (guidelines/05 §5.4).
   Eltern-Element braucht overflow:hidden.
   ============================================================ */
@keyframes kasane-drift {
  0%   { transform: translate(0%,    0%)    scale(1.00); }
  25%  { transform: translate(4.5%,  3.0%)  scale(1.10); }
  50%  { transform: translate(1.5%,  5.5%)  scale(1.14); }
  75%  { transform: translate(-3.0%, 2.5%)  scale(1.10); }
  100% { transform: translate(0%,    0%)    scale(1.00); }
}
@keyframes kasane-drift-bold {
  0%   { transform: translate(0%,    0%)    scale(1.00) rotate(0deg); }
  25%  { transform: translate(9.0%,  6.0%)  scale(1.20) rotate(10deg); }
  50%  { transform: translate(-5.0%, 10.0%) scale(1.28) rotate(18deg); }
  75%  { transform: translate(-8.0%, 3.0%)  scale(1.20) rotate(8deg); }
  100% { transform: translate(0%,    0%)    scale(1.00) rotate(0deg); }
}
.kasane-drift      { animation: kasane-drift 14s ease-in-out infinite; will-change: transform; }
.kasane-drift-bold { animation: kasane-drift-bold 9s ease-in-out infinite; will-change: transform; }
@media (prefers-reduced-motion: reduce) {
  .kasane-drift, .kasane-drift-bold { animation: none; }
}

/* ============================================================
   Gradient-Katalog (guidelines/04 §4.5/4.6).
   Systematik: Familienfarben als radiale Ellipsen über Basis;
   ein Thema = eine Farbwelt.
   ============================================================ */

/* Light Kasane — Seiten-Hero auf Off-White */
.bg-kasane-hero {
  background:
    radial-gradient(ellipse 70% 65% at 12% 80%, rgba(196,177,220,0.65) 0%, transparent 60%),
    radial-gradient(ellipse 70% 60% at 92% 30%, rgba(177,142,182,0.70) 0%, transparent 65%),
    radial-gradient(ellipse 60% 55% at 28%  5%, rgba(168,184,154,0.55) 0%, transparent 60%),
    radial-gradient(ellipse 55% 45% at 75% -5%, rgba(196,177,220,0.55) 0%, transparent 65%),
    radial-gradient(ellipse 80% 30% at 50%  0%, rgba(186,164,196,0.35) 0%, transparent 70%);
}

/* Dark Kasane — dunkle CTA-Flächen, Mobile-Menü */
.bg-kasane-cta {
  background:
    radial-gradient(ellipse 80% 60% at 20% 80%, rgba(138, 48, 80,0.45) 0%, transparent 60%),
    radial-gradient(ellipse 70% 80% at 75% 20%, rgba(107, 74,148,0.55) 0%, transparent 55%),
    radial-gradient(ellipse 50% 50% at 50% 50%, rgba(144,112,184,0.25) 0%, transparent 50%),
    radial-gradient(ellipse 60% 70% at 10% 30%, rgba( 74, 45,107,0.55) 0%, transparent 50%);
}

/* Kontakt-/Abschluss-CTA — Triade auf Deep-Plum; Teal und Berry müssen
   als eigene Farbräume lesbar bleiben, kein homogenes Lila.
   ⚠ NIE PUR ALS FLÄCHE: Das Rezept ist byte-identisch mit der
   Website (globals.css), aber pur erzeugt es Leuchtbälle — die
   Website nutzt es nur über das Anwendungsrezept darunter.
   (Befund 2026-07-17, gelöst 2026-07-20 als Token-Paar:
   .contact-cta-wash für Web, .bg-contact-cta-static für Decks
   und Print.) */
.bg-contact-cta {
  background:
    radial-gradient(ellipse 55% 65% at 24% 26%, rgba( 58,158,151,0.90) 0%, transparent 60%),
    radial-gradient(ellipse 50% 60% at 72% 18%, rgba(144,112,184,0.85) 0%, transparent 60%),
    radial-gradient(ellipse 55% 70% at 68% 84%, rgba(184, 74,111,0.80) 0%, transparent 60%),
    var(--bm-deep-plum);
}

/* Anwendungsrezept WEB (= ContactCta.tsx der Website): Wrapper
   auf Deep-Plum, ZWEI Kopien der Ellipsen als Pseudo-Elemente —
   Overscan inset -35 %, blur(32px), Opacity 0.85/0.50,
   gegenläufiger Drift. Erst das verschmilzt die Ellipsen zum
   Wash. Inhalt liegt als normales Kind darüber (isolation
   hält die Pseudo-Ebenen darunter). ⚠ Handwerks-Fallen gelten:
   Inhalte darüber ohne filter/blend-mode; auf Mobile ruckelt
   blur auf Kasane-Flächen — prefers-reduced-motion stoppt den
   Drift automatisch, den Blur im Mobile-Kontext reduzieren. */
.contact-cta-wash {
  position: relative;
  overflow: hidden;
  isolation: isolate;
  background: var(--bm-deep-plum);
}
.contact-cta-wash::before,
.contact-cta-wash::after {
  content: "";
  position: absolute;
  inset: -35%;
  z-index: -1;
  pointer-events: none;
  background:
    radial-gradient(ellipse 55% 65% at 24% 26%, rgba( 58,158,151,0.90) 0%, transparent 60%),
    radial-gradient(ellipse 50% 60% at 72% 18%, rgba(144,112,184,0.85) 0%, transparent 60%),
    radial-gradient(ellipse 55% 70% at 68% 84%, rgba(184, 74,111,0.80) 0%, transparent 60%);
  filter: blur(32px);
}
.contact-cta-wash::before { opacity: 0.85; animation: kasane-drift 14s ease-in-out infinite; }
.contact-cta-wash::after  { opacity: 0.50; animation: kasane-drift-bold 9s ease-in-out infinite reverse; }
@media (prefers-reduced-motion: reduce) {
  .contact-cta-wash::before, .contact-cta-wash::after { animation: none; }
}

/* Anwendungsrezept STATISCH (Decks, Print, PDF): kein Drift,
   kein Blur (PDF rastert beides) — der Wash ist vorgemischt.
   Abgenommen als Schluss-Verlauf der Decks (DETAX 07/2026). */
.bg-contact-cta-static {
  background:
    radial-gradient(ellipse 85% 100% at 3% 0%, rgba(168, 84,110,0.55) 0%, transparent 62%),
    radial-gradient(ellipse 95% 130% at 100% 55%, rgba(88,102,158,0.55) 0%, transparent 68%),
    linear-gradient(112deg, #8A5C88 0%, #7A5AA0 38%, #6C58A4 68%, #5E64A0 100%);
}

/* Featured-/Produkt-Band — satt farbig auf dunkler Basis, für weiße Typo */
.bg-commercial-os {
  background:
    radial-gradient(ellipse 90% 110% at 10% 12%, rgba( 58,158,151,0.90) 0%, transparent 58%),
    radial-gradient(ellipse 85% 110% at 95% 20%, rgba(144,112,184,0.85) 0%, transparent 58%),
    radial-gradient(ellipse 80% 110% at 72% 112%, rgba(184, 74,111,0.80) 0%, transparent 58%),
    var(--bm-deep-plum);
}

/* Plum Kasane — vollfarbige Moment-Fläche (Vision/Prozess) */
.bg-kasane-plum {
  background:
    radial-gradient(ellipse 110% 120% at -5%   0%, rgba(196,177,220,0.70) 0%, transparent 75%),
    radial-gradient(ellipse 100% 110% at 100% 100%, rgba(184, 74,111,0.55) 0%, transparent 75%),
    radial-gradient(ellipse  95% 100% at 100% -10%, rgba(144,112,184,0.55) 0%, transparent 75%),
    radial-gradient(ellipse  95% 105% at   0% 110%, rgba(107, 74,148,0.55) 0%, transparent 75%),
    radial-gradient(ellipse 130%  90% at  50%  50%, rgba(180,148,210,0.30) 0%, transparent 80%),
    #4A3570;
}

/* Kapitelbänder — Surface-Ton als weiche Kasane-Wolke, läuft an den
   Rändern in den Off-White-Grund aus (kein harter Anstoß) */
.bg-kasane-band-sage {
  background:
    radial-gradient(ellipse 90% 75% at 20% 35%, rgba(168, 184, 154, 0.35) 0%, transparent 62%),
    radial-gradient(ellipse 85% 70% at 85% 65%, rgba(126, 196, 190, 0.28) 0%, transparent 60%),
    radial-gradient(ellipse 120% 70% at 50% 50%, rgba(221, 228, 224, 0.85) 0%, transparent 78%);
}
.bg-kasane-band-mauve {
  background:
    radial-gradient(ellipse 90% 75% at 80% 30%, rgba(196, 177, 220, 0.38) 0%, transparent 60%),
    radial-gradient(ellipse 85% 70% at 15% 70%, rgba(176, 148, 210, 0.26) 0%, transparent 60%),
    radial-gradient(ellipse 120% 70% at 50% 55%, rgba(227, 224, 232, 0.85) 0%, transparent 78%);
}
.bg-kasane-band-teal {
  background:
    radial-gradient(ellipse 90% 75% at 75% 60%, rgba(126, 196, 190, 0.34) 0%, transparent 60%),
    radial-gradient(ellipse 85% 70% at 20% 30%, rgba( 58, 158, 151, 0.16) 0%, transparent 60%),
    radial-gradient(ellipse 120% 70% at 50% 50%, rgba(224, 242, 240, 0.85) 0%, transparent 78%);
}
.bg-kasane-band-rose {
  background:
    radial-gradient(ellipse 90% 75% at 25% 60%, rgba(212, 128, 154, 0.26) 0%, transparent 60%),
    radial-gradient(ellipse 85% 70% at 80% 30%, rgba(184,  74, 111, 0.10) 0%, transparent 60%),
    radial-gradient(ellipse 120% 70% at 50% 55%, rgba(245, 224, 232, 0.85) 0%, transparent 78%);
}
/* Sand = die stille Variante für Kapitel ohne Farbanspruch */
.bg-kasane-band-sand {
  background:
    radial-gradient(ellipse 90% 75% at 70% 35%, rgba(229, 224, 216, 0.90) 0%, transparent 62%),
    radial-gradient(ellipse 85% 70% at 20% 70%, rgba(197, 192, 184, 0.30) 0%, transparent 60%),
    radial-gradient(ellipse 120% 70% at 50% 50%, rgba(232, 229, 223, 0.85) 0%, transparent 78%);
}

/* Themen-Karten-Visuals — ein Hebel = eine Farbwelt */
.bg-hebel-kundenschnittstelle {
  background:
    radial-gradient(ellipse 70% 60% at 20% 25%, rgba(107, 74,148,0.55) 0%, transparent 60%),
    radial-gradient(ellipse 60% 50% at 80% 85%, rgba(196,177,220,0.70) 0%, transparent 55%),
    radial-gradient(ellipse 50% 40% at 70% 25%, rgba(212,128,154,0.25) 0%, transparent 60%),
    var(--surface-mauve);
}
.bg-hebel-vertrieb {
  background:
    radial-gradient(ellipse 70% 60% at 80% 25%, rgba( 29,107,102,0.50) 0%, transparent 60%),
    radial-gradient(ellipse 60% 50% at 15% 80%, rgba(168,184,154,0.55) 0%, transparent 60%),
    radial-gradient(ellipse 40% 40% at 50% 50%, rgba(126,196,190,0.40) 0%, transparent 60%),
    var(--surface-sage);
}
.bg-hebel-neue-felder {
  background:
    radial-gradient(ellipse 70% 60% at 50% 25%, rgba(138, 48, 80,0.45) 0%, transparent 60%),
    radial-gradient(ellipse 60% 60% at 25% 85%, rgba(212,128,154,0.55) 0%, transparent 55%),
    radial-gradient(ellipse 50% 40% at 85% 60%, rgba(196,177,220,0.30) 0%, transparent 60%),
    var(--surface-sand);
}
.bg-hebel-ventures {
  background:
    radial-gradient(ellipse 70% 60% at 80% 25%, rgba( 74, 90, 60,0.45) 0%, transparent 60%),
    radial-gradient(ellipse 60% 50% at 15% 80%, rgba(196,177,220,0.40) 0%, transparent 55%),
    radial-gradient(ellipse 50% 40% at 65% 75%, rgba(168,184,154,0.55) 0%, transparent 60%),
    var(--surface-stone);
}

/* Offene Farbbänder — weicher Farb-Glow oben-mittig + Weiß-Sockel,
   full-bleed hinter 1200er-Content */
.bg-hebel-wash-kundenschnittstelle {
  background:
    radial-gradient(ellipse 120% 75% at 50% -15%, rgba(196,177,220,0.30) 0%, transparent 60%),
    radial-gradient(ellipse 90% 60% at 85% 120%, rgba(107, 74,148,0.07) 0%, transparent 60%),
    rgba(255,255,255,0.45);
}
.bg-hebel-wash-vertrieb {
  background:
    radial-gradient(ellipse 120% 75% at 50% -15%, rgba(126,196,190,0.30) 0%, transparent 60%),
    radial-gradient(ellipse 90% 60% at 85% 120%, rgba( 29,107,102,0.06) 0%, transparent 60%),
    rgba(255,255,255,0.45);
}
.bg-hebel-wash-neue-felder {
  background:
    radial-gradient(ellipse 120% 75% at 50% -15%, rgba(212,128,154,0.26) 0%, transparent 60%),
    radial-gradient(ellipse 90% 60% at 85% 120%, rgba(138, 48, 80,0.06) 0%, transparent 60%),
    rgba(255,255,255,0.45);
}
.bg-hebel-wash-ventures {
  background:
    radial-gradient(ellipse 120% 75% at 50% -15%, rgba(168,184,154,0.32) 0%, transparent 60%),
    radial-gradient(ellipse 90% 60% at 85% 120%, rgba( 74, 90, 60,0.06) 0%, transparent 60%),
    rgba(255,255,255,0.45);
}

/* Case-/Grid-Visuals — rotierende Branchen-Tonalitäten */
.bg-case-visual-1 {
  background:
    radial-gradient(ellipse 80% 60% at 30% 30%, rgba(196,177,220,0.60), transparent 60%),
    radial-gradient(ellipse 70% 50% at 80% 80%, rgba(237,227,245,0.80), transparent 50%),
    var(--surface-mauve);
}
.bg-case-visual-2 {
  background:
    radial-gradient(ellipse 70% 60% at 80% 30%, rgba(126,196,190,0.50), transparent 60%),
    radial-gradient(ellipse 60% 50% at 20% 70%, rgba(224,242,240,0.70), transparent 50%),
    var(--surface-sage);
}
.bg-case-visual-3 {
  background:
    radial-gradient(ellipse 70% 60% at 50% 30%, rgba(212,128,154,0.40), transparent 60%),
    radial-gradient(ellipse 60% 60% at 30% 80%, rgba(245,224,232,0.80), transparent 55%),
    var(--surface-sand);
}
.bg-case-visual-4 {
  background:
    radial-gradient(ellipse 80% 60% at 80% 30%, rgba(168,184,154,0.45), transparent 60%),
    radial-gradient(ellipse 60% 50% at 20% 80%, rgba(226,232,220,0.70), transparent 50%),
    var(--surface-stone);
}
.bg-case-visual-5 {
  background:
    radial-gradient(ellipse 70% 50% at 20% 40%, rgba(196,177,220,0.50), transparent 60%),
    radial-gradient(ellipse 60% 60% at 80% 70%, rgba(212,128,154,0.35), transparent 55%),
    var(--surface-mauve);
}
.bg-case-visual-6 {
  background:
    radial-gradient(ellipse 70% 60% at 60% 40%, rgba(126,196,190,0.45), transparent 60%),
    radial-gradient(ellipse 50% 50% at 25% 75%, rgba(168,184,154,0.40), transparent 50%),
    var(--surface-sage);
}

/* Case-Karten pro Hebel — Akzente Plum/Teal/Berry über Surfaces */
.bg-case-neues-verkaufen {
  background:
    radial-gradient(ellipse 70% 60% at 20% 25%, rgba(107, 74,148,0.55), transparent 60%),
    radial-gradient(ellipse 60% 50% at 80% 85%, rgba(196,177,220,0.65), transparent 55%),
    var(--surface-mauve);
}
.bg-case-besser-verkaufen {
  background:
    radial-gradient(ellipse 70% 60% at 80% 25%, rgba( 29,107,102,0.50), transparent 60%),
    radial-gradient(ellipse 60% 50% at 15% 80%, rgba(168,184,154,0.50), transparent 60%),
    var(--surface-sage);
}
.bg-case-besser-arbeiten {
  background:
    radial-gradient(ellipse 70% 60% at 50% 25%, rgba(138, 48, 80,0.45), transparent 60%),
    radial-gradient(ellipse 60% 60% at 25% 85%, rgba(212,128,154,0.55), transparent 55%),
    var(--surface-sand);
}

/* Stimmen-/Zitat-Karten — satte dunkle Verläufe (mit grain-photo-screen) */
.bg-stimme-plum {
  background:
    radial-gradient(ellipse 85% 70% at  5%  5%, rgba(180,148,210,0.75), transparent 55%),
    radial-gradient(ellipse 75% 70% at 95% 95%, rgba(158, 72,104,0.65), transparent 50%),
    radial-gradient(ellipse 55% 55% at 60% 40%, rgba(100, 72,138,0.40), transparent 55%),
    #4A3570;
}
.bg-stimme-teal {
  background:
    radial-gradient(ellipse 85% 70% at 95%  5%, rgba( 72,178,168,0.70), transparent 55%),
    radial-gradient(ellipse 75% 70% at  5% 95%, rgba( 96,124, 82,0.65), transparent 50%),
    radial-gradient(ellipse 55% 55% at 40% 50%, rgba( 32,100, 94,0.35), transparent 55%),
    #1E5E58;
}

/* Media-Thumbs auf dunklen Karten — leise Verläufe als Platzhalter */
.bg-youtube-preview {
  background:
    radial-gradient(ellipse 70% 60% at 30% 30%, rgba(196,177,220,0.25), transparent 60%),
    radial-gradient(ellipse 60% 50% at 80% 80%, rgba(212,128,154,0.18), transparent 50%),
    #232325;
}
.bg-yt-thumb-featured {
  background:
    radial-gradient(ellipse 70% 60% at 30% 30%, rgba(196,177,220,0.25), transparent 60%),
    radial-gradient(ellipse 60% 50% at 80% 80%, rgba(212,128,154,0.18), transparent 50%),
    rgba(255,255,255,0.04);
}
.bg-yt-thumb-tile {
  background:
    radial-gradient(ellipse 70% 60% at 25% 30%, rgba(196,177,220,0.18), transparent 60%),
    radial-gradient(ellipse 60% 60% at 80% 70%, rgba(126,196,190,0.14), transparent 50%),
    rgba(255,255,255,0.04);
}

/* Grafische Platzhalter — diagonale Streifen-Textur (Stone-Töne) */
.bg-stripes-diagonal {
  background: repeating-linear-gradient(135deg, var(--surface-stone) 0 12px, #DDD9D2 12px 24px);
}

/* ============================================================
   Buttons — Pill. Immer. (guidelines/07 §7.3)
   Hover = Füllungswechsel innerhalb der Markenfamilie, nie Schwarz.
   ============================================================ */
.bm-btn {
  display: inline-flex; align-items: center; justify-content: center;
  height: 44px; padding: 0 28px;
  border: none; border-radius: var(--radius-pill);
  font-family: var(--font-sans); font-size: 15px; font-weight: 500;
  cursor: pointer; white-space: nowrap;
  transition: background var(--duration-fast) var(--ease-out),
              color var(--duration-fast) var(--ease-out),
              box-shadow var(--duration-fast) var(--ease-out);
}
.bm-btn-sm { height: 36px; padding: 0 20px; font-size: 13px; }
.bm-btn-lg { height: 52px; padding: 0 36px; font-size: 16px; }

.bm-btn-primary { background: var(--charcoal); color: var(--off-white); }
.bm-btn-primary:hover { background: var(--bm-deep-plum); }

.bm-btn-secondary {
  background: transparent; color: var(--bm-purple);
  box-shadow: inset 0 0 0 1.5px var(--bm-purple);
}
.bm-btn-secondary:hover { background: var(--bm-purple-tint); }

.bm-btn-ghost { background: transparent; color: var(--charcoal); }
.bm-btn-ghost:hover { background: var(--surface-stone); }

/* On-Dark-Varianten */
.bm-on-dark .bm-btn-primary { background: var(--off-white); color: var(--charcoal); }
.bm-on-dark .bm-btn-primary:hover { background: var(--bm-soft-purple); }
.bm-on-dark .bm-btn-secondary {
  color: var(--bm-lavender-dark);
  box-shadow: inset 0 0 0 1.5px var(--bm-lavender-dark);
  background: transparent;
}
.bm-on-dark a, .bm-on-dark .bm-link { color: var(--bm-lavender-dark); }

/* ============================================================
   Badges / Tags — kleine Pills (guidelines/07 §7.6)
   ============================================================ */
.bm-badge {
  display: inline-flex; align-items: center;
  height: 24px; padding: 0 10px;
  border-radius: var(--radius-pill);
  font-family: var(--font-sans); font-size: 12px; font-weight: 500; line-height: 1.4;
  background: var(--surface-stone); color: var(--charcoal);
}
.bm-badge-purple { background: var(--bm-purple-tint); color: var(--bm-deep-plum); }
.bm-badge-berry  { background: var(--bm-rose-tint);   color: var(--bm-deep-berry); }
.bm-badge-teal   { background: var(--bm-teal-tint);   color: var(--bm-deep-teal); }

/* ============================================================
   Formulare (guidelines/07 §7.4) — radius-md, nie Pill.
   Labels über den Feldern.
   ============================================================ */
.bm-input, .bm-textarea, .bm-select {
  width: 100%;
  height: 44px;
  padding: 0 var(--space-4);
  border: var(--border-subtle);
  border-radius: var(--radius-md);
  background: transparent; /* Outline-only im Ruhezustand (Nils, 2026-07-14) */
  font: 400 16px/1.6 var(--font-sans);
  color: var(--charcoal);
  transition: border-color var(--duration-fast) var(--ease-out),
              background-color var(--duration-fast) var(--ease-out),
              box-shadow var(--duration-fast) var(--ease-out);
}
.bm-textarea { height: auto; padding: 12px var(--space-4); min-height: 120px; }
/* Select: eigenes Chevron, IM Rezept erzwungen (Nils, 2026-07-24 —
   ein Mitarbeiter-Dashboard zeigte das native Browser-Chevron hart
   an der rechten Kante): appearance: none schaltet das native
   Dreieck ab, das SVG-Chevron (Charcoal, 12×8) sitzt 16px vom
   Rand — symmetrisch zum linken Padding. */
.bm-select {
  appearance: none;
  -webkit-appearance: none;
  padding-right: 44px;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1.5 6 6.5 11 1.5' fill='none' stroke='%231C1C1E' stroke-width='1.5'/%3E%3C/svg%3E");
  background-repeat: no-repeat;
  background-position: right 16px center;
}
.bm-input:focus, .bm-textarea:focus, .bm-select:focus {
  outline: none;
  /* background-color statt background-Shorthand — das Shorthand
     würde das Chevron-background-image des Selects löschen. */
  background-color: var(--white); /* füllt erst bei Fokus */
  border-color: var(--bm-purple);
  box-shadow: 0 0 0 3px rgba(107,74,148,0.12);
}
.bm-label { font: 500 14px/1.5 var(--font-sans); color: var(--charcoal); display: block; margin-bottom: 6px; }
.bm-help  { font: 400 12px/1.4 var(--font-sans); color: var(--mid); margin-top: 6px; }

/* ============================================================
   Container & Eyebrow-Utility
   ============================================================ */
.bm-container { max-width: var(--container-max); margin: 0 auto; padding: 0 var(--container-pad); }
@media (min-width: 768px) { .bm-container { padding: 0 32px; } }
.bm-eyebrow { font-size: 12px; font-weight: 500; line-height: 1.4; letter-spacing: 0.10em; text-transform: uppercase; color: var(--light); }

/* ============================================================
   Reduced Motion — Pflicht (guidelines/05 §5.1)
   ============================================================ */
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}

</style>
<!-- Fonts per Google-Link — NUR fürs interne Entwerfen erlaubt
     (Ausnahme Nils, 2026-07-20). Weitergabe ausschließlich als
     PDF über das Quality-Gate, nie diese HTML. -->
<link rel="preconnect" href="https://fonts.googleapis.com" />
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&display=swap" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,300,0,0" />

<style>
  /* ----------------------------------------------------------
     Deck-Layer: pinnt die fluiden type-*-Stufen auf ihre festen
     Desktop-Werte (clamp() rechnet gegen den Viewport — auf der
     festen Stage und im PDF-Druck wäre das falsch).
     ---------------------------------------------------------- */
  /* Cover-Kopf: Logo-Brücke nur für Kundendecks — interne Decks
     setzen .cover-head-intern auf den Kopf-Container, dann bleibt
     allein die Wortmarke (Nils, 2026-07-22). */
  .cover-head-intern .cover-bridge,
  .cover-head-intern .cover-client { display: none; }

  .type-display-xl { font-size: 128px; }
  .type-display-l  { font-size: 96px; }
  .type-display    { font-size: 64px; }
  .type-h1         { font-size: 48px; }
  .type-h2         { font-size: 32px; }
  .type-stat       { font-size: 36px; }

  :root {
    --deck-pad-x: 120px;   /* 1440 − 2×120 = 1200px Contentbreite wie im Web */
    --deck-head-y: 48px;   /* Oberkante Kopfzeile */
    --deck-foot-y: 24px;   /* Unterkante Fußzeilen-Textbox */
    --deck-title-y: 96px;  /* Oberkante Headline — FIX auf jeder Content-Slide */
    --deck-pad-b: 72px;    /* Fußzeilen-Metrik: Mindestluft über der Fußzeilen-Typo
                              = Abstand Unterkante→Baseline (~28px) */
  }

  /* Material Symbols — einzige erlaubte Icon-Quelle. */
  .msym {
    font-family: 'Material Symbols Outlined';
    font-weight: normal; font-style: normal;
    font-size: 32px; line-height: 1;
    display: inline-block;
    font-variation-settings: 'opsz' 48, 'wght' 300, 'FILL' 0, 'GRAD' 0;
    -webkit-font-smoothing: antialiased;
  }

  /* ---------- Slide-Grundgerüst ----------
     Content-Slides: Headline beginnt IMMER bei --deck-title-y.
     Der .deck-body darunter bekommt den Rest der Höhe und
     verteilt seinen Inhalt — so besetzt der Inhalt die Fläche,
     ohne dass die Headline je wandert. */
  .dslide {
    display: flex; flex-direction: column;
    padding: var(--deck-title-y) var(--deck-pad-x) var(--deck-pad-b);
    background: var(--off-white); color: var(--charcoal);
    font-family: var(--font-sans);
    counter-increment: slide;
  }
  .dslide > .dslide-content { display: flex; flex-direction: column; flex: 1; min-height: 0; }
  .deck-title { margin: 0; }
  .deck-lead { color: var(--dark); max-width: 672px; margin: var(--space-4) 0 0; }
  .deck-body {
    flex: 1; min-height: 0; margin-top: var(--space-10);
    display: flex; flex-direction: column; justify-content: safe center;
  }
  .deck-body-end { justify-content: flex-end; }

  /* Moment-Slides (Cover, Trenner, Zitat, Schluss) haben eigene
     Konzepte und heben die feste Kopfzone bewusst auf. */
  .dslide-moment { justify-content: center; padding: 96px var(--deck-pad-x); }
  .dslide-moment > .dslide-content { flex: 0 0 auto; }

  .dslide-dark { background: var(--charcoal); color: var(--off-white); }
  .kasane-layer { position: absolute; inset: 0; z-index: 0; }
  .grain-layer  { position: absolute; inset: 0; z-index: 1; pointer-events: none; }
  .dslide-content { position: relative; z-index: 2; }

  /* ---------- Kopfzeile — konstantes System ---------- */
  .slide-head {
    position: absolute; z-index: 2;
    top: var(--deck-head-y); left: var(--deck-pad-x); right: var(--deck-pad-x);
    display: flex; justify-content: space-between; align-items: baseline;
    color: var(--mid);
  }
  .dslide-dark .slide-head { color: var(--soft); }

  /* ---------- Fußzeile — konstantes System ----------
     Wortmarke (14px) + Kunde/Projekt links, Seitenzahl rechts —
     jede Slide außer den Moment-Slides, immer an derselben
     Position. Der 4px-Gap (halbe Rasterstufe) gleicht den
     Geviertstrich-Innenabstand der Wortmarke optisch aus. Der
     Kundenname steht im Wortmarken-Schwarz und semi-bold —
     Kunde und Bridgemaker sind gleichwertig, kein helleres
     Grau, das den Kunden zurückstuft. */
  .slide-foot {
    position: absolute; z-index: 2;
    bottom: var(--deck-foot-y); left: var(--deck-pad-x); right: var(--deck-pad-x);
    display: flex; justify-content: space-between; align-items: baseline;
    color: var(--mid); font: 400 12px/1.4 var(--font-sans);
  }
  .slide-foot .pagenum::after { content: counter(slide, decimal-leading-zero); }
  .slide-foot .foot-brand { display: flex; align-items: center; gap: 4px; }
  .slide-foot .foot-brand span { color: var(--charcoal); font-weight: 600; }
  .slide-foot .foot-brand img { height: 14px; width: auto; display: block; }
  .dslide-dark .slide-foot { color: var(--soft); }
  .dslide-dark .slide-foot .foot-brand span { color: var(--off-white); }

  /* Quellen-/Fußnoten-Register: 12px rechtsbündig in --mid — die
     dritte und letzte Textgröße einer Seite (Meta). In Karten:
     --light und per margin-top:auto am Boxboden; Sternchen
     verknüpft Label* ↔ * Fußnote. Grafik-Fußnoten mittelachsig. */
  .source-note { font: 400 12px/1.4 var(--font-sans); color: var(--mid); text-align: right; }

  .type-display-xl, .type-display-l, .type-display, .type-h1, .type-h2 { text-wrap: balance; }
  .dslide p, .hl-col, .meta-row { text-wrap: pretty; }

  /* ---------- PATTERN: Hairline-Kolumnen ----------
     DAS Standard-Layout für gleichrangige Punkte (Referenz:
     was-wir-bauen-01-hairline-kolumnen.png). Hairline eröffnet
     die Spalte, darunter Index + Titel, darunter gestapelte
     Kurzabsätze — Abstand trennt, keine weiteren Linien. */
  .hl-cols { display: grid; gap: var(--space-12); }
  .hl-cols-2 { grid-template-columns: 1fr 1fr; }
  .hl-cols-3 { grid-template-columns: repeat(3, 1fr); }
  .hl-cols-4 { grid-template-columns: repeat(4, 1fr); }
  .hl-col { border-top: var(--border-subtle); padding-top: var(--space-4); }
  .hl-col .hl-index {
    display: flex; justify-content: space-between; align-items: center;
    color: var(--mid); margin-bottom: var(--space-4);
  }
  .hl-col .hl-title { margin: 0 0 var(--space-4); }
  .hl-col p { color: var(--dark); margin: 0 0 var(--space-4); }
  .hl-col p:last-child { margin-bottom: 0; }
  .hl-sublabel { color: var(--mid); margin: var(--space-6) 0 var(--space-3); }

  /* ---------- PATTERN: Meta-Zeile ----------
     Für Werte, Ziele, Quellen, Fakten: Label links, Wert rechts
     (Referenz: frontpage-06-case-karten-meta-zeilen.png).
     Werte NIE als Badge oder Chip. */
  .meta-rows { border-top: var(--border-subtle); }
  .meta-row {
    display: flex; justify-content: space-between; align-items: baseline;
    gap: var(--space-8); padding: var(--space-4) 0;
    border-bottom: var(--border-subtle);
  }
  .meta-row .value { color: var(--bm-deep-plum); white-space: nowrap; }

  /* ---------- PATTERN: freie Zahlen ----------
     Stats stehen frei zwischen vertikalen Hairlines — nie in
     KPI-Kacheln (Referenz: frontpage-05-stats-vertikale-hairlines.png). */
  .stat-strip { display: grid; grid-template-columns: repeat(3, 1fr); }
  .stat-cell { padding: var(--space-2) var(--space-10); border-left: var(--border-subtle); }
  .stat-cell:first-child { border-left: none; padding-left: 0; }
  .stat-cell .num { font-weight: 300; letter-spacing: -0.03em; } /* große Ziffern immer light */
  .stat-cell .label { color: var(--mid); margin-top: var(--space-4); }
  .stat-cell p { color: var(--dark); margin: var(--space-3) 0 0; }

  /* ---------- PATTERN: Principle-Zeile ----------
     Werte/Prinzipien/Aspekte mit Icon: Hairline oben, Titel LINKS,
     Icon rechtsbündig auf derselben Zeile, Copy darunter
     (Nils, 2026-07-23 — ersetzt die frühere Website-Anordnung
     Icon links/Titel rechts, Referenz karriere-01-principle-zeilen.png). */
  .principle-grid {
    display: grid; grid-template-columns: 1fr 1fr;
    column-gap: var(--space-16); row-gap: var(--space-12);
  }
  .principle { border-top: var(--border-subtle); padding-top: var(--space-4); }
  .principle .p-head { display: flex; justify-content: space-between; align-items: center; }
  .principle .p-head .msym { color: var(--charcoal); font-size: 24px; }
  .principle p { color: var(--dark); margin: var(--space-4) 0 0; }

  /* ---------- PATTERN: Resultat-Band ----------
     Für Summen/Basis/Ergebnis unter einer gleichrangigen Reihe:
     bewusst ANDERS exponiert (Rolle = Behandlung) — Mauve-Tint,
     Eyebrow und Satz in Deep-Plum, Satz als type-body bold (nie
     type-h4, nie Charcoal-Kachel). Nie dieselbe Surface wie die
     Reihe darüber. */
  .result-band {
    background: var(--surface-mauve); color: var(--charcoal);
    border-radius: var(--radius-xl);
    padding: var(--space-6) var(--space-8);
    display: flex; justify-content: space-between; align-items: baseline;
    gap: var(--space-10); margin-top: var(--space-10);
  }
  .result-band .type-eyebrow { color: var(--bm-deep-plum); flex-shrink: 0; }
  .result-band .type-body { color: var(--bm-deep-plum); font-weight: 600; }

  /* ---------- Karten — nur für benannte Dinge, Zitate, Bühnen ---------- */
  .deck-card { background: var(--white); border-radius: var(--radius-xl); padding: var(--space-8); }
  .object-grid { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-6); }
  .object-card {
    border-radius: var(--radius-xl); padding: var(--space-8);
    min-height: 200px; display: flex; flex-direction: column;
    justify-content: space-between;
  }
  .object-card .o-name { display: flex; justify-content: flex-end; align-items: center; gap: var(--space-2); color: var(--dark); }

  /* Nummerierte Objekt-Karten: Display-Ziffer light im
     Familien-Deep-Ton, Karten-Reihen mit gemeinsamer Unterkante
     und gleicher Höhe (min-height im 8px-Raster). */
  .num-card { border-radius: var(--radius-xl); padding: var(--space-6); display: flex; flex-direction: column; }
  .num-card .o-num { font-weight: 300; letter-spacing: -0.03em; }
  .num-card h3 { margin: var(--space-4) 0 var(--space-3); }
  .num-card p { color: var(--dark); margin: 0 0 var(--space-3); }
  .num-card p:last-child { margin-bottom: 0; }

  .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-6); }
  .split-23 { display: grid; grid-template-columns: 2fr 1fr; gap: var(--space-12); align-items: center; }

  /* Agenda: Hairline-Zeilen, Inter-Ziffern (Mono existiert nicht
     mehr). Zeilen gleich hoch (min-height 96px) und vertikal
     zentriert — bei parallelen Spalten laufen die Hairlines so
     konstant über beide Spalten (Nils, 2026-07-23). */
  .agenda-grid {
    display: grid; grid-template-columns: 1fr 1fr;
    column-gap: var(--space-16); row-gap: 0;
    align-content: center;
  }
  .agenda-row { display: flex; align-items: center; min-height: 96px; gap: var(--space-6); padding: var(--space-5) 0; border-top: var(--border-subtle); }
  .agenda-num { color: var(--charcoal); width: var(--space-10); flex-shrink: 0; } /* = Titelfarbe */

  /* table-layout: fixed — Spalten folgen exakt den th-Breiten und
     stehen auf jeder Seite identisch. Das Auto-Layout des Browsers
     verteilt Spalten pro Slide nach Inhalt: Serien-Tabellen
     springen dann beim Blättern (Nils, 2026-07-24). EINE th-Breite
     offen lassen (Rest-Spalte); Breiten am breitesten Inhalt der
     ganzen Serie bemessen. */
  .deck-table { width: 100%; border-collapse: collapse; table-layout: fixed; }
  .deck-table th { text-align: left; padding: var(--space-3) var(--space-4) var(--space-3) 0; border-bottom: var(--border-subtle); color: var(--mid); }
  .deck-table td { padding: var(--space-4) var(--space-4) var(--space-4) 0; border-bottom: var(--border-subtle); vertical-align: top; }
  .deck-table .value { color: var(--bm-deep-plum); }

  /* Platzhalter — NUR für Bild-Assets (Fotos, CD-Bildwelt, Logos).
     Informationsgrafiken werden gebaut (§7.11), nie angekündigt. */
  .placeholder-frame {
    border-radius: var(--radius-xl); overflow: hidden;
    display: flex; align-items: flex-end;
    min-height: 320px;
  }
  .placeholder-caption {
    background: rgba(255,255,255,0.85);
    padding: var(--space-4) var(--space-5);
    margin: var(--space-5); border-radius: var(--radius-md);
    color: var(--dark); max-width: 90%;
    font: 500 14px/1.5 var(--font-mono);
  }

  /* Kapiteltrenner: große Ziffer in Inter als stilles Element —
     große Ziffern laufen IMMER light. */
  .chapter-num {
    font: 300 200px/0.85 var(--font-sans);
    color: var(--surface-mid-stone);
    letter-spacing: -0.04em;
  }

  /* Infografik-Grundstil: Beschriftung Inter, eine Baseline,
     keine Gitter (§7.11) */
  .chart-label { font: 500 14px/1.4 var(--font-sans); }
  .chart-label-soft { font: 400 13px/1.4 var(--font-sans); fill: var(--mid); }

  .wordmark { height: 24px; width: auto; display: block; }

  /* ---------- Print/PDF-Layer ----------
     PDF kennt keine weichen Schatten und keine Blend-Modes: Der
     Browser übersetzt beide in Soft-Masks und Transparenz-
     Gruppen — Viewer (v. a. macOS Preview) rendern die quälend
     langsam und zeichnen graue Kästen um Karten. Im PDF deshalb:
     nur die Inset-Haarlinie statt Schatten, kein Grain. Am
     Bildschirm ändert sich nichts. */
  @media print {
    .card-clean, .card-elevated, .shadow-pop {
      box-shadow: inset 0 0 0 1px rgba(28,28,30,0.08) !important;
    }
    .grain-layer { display: none !important; }
  }
</style>
</head>
<body>

<deck-stage width="1440" height="810">

  <!-- ========================================================
       ROLLE „COVER" — Pflicht als erste Slide.
       Gedecktes dunkles Kasane (statisch) + topografische
       Konturen: rechts dicht, links offen zum Text (wie der
       Website-Hero). Neues Linienbild bei Bedarf:
       node deck-topo-konturen.js cover <seed>
       Wortmarke links oben; ihr Geviertstrich läuft als Linie
       ÜBER DIE GANZE BREITE weiter bis zum Kundenlogo rechts —
       die Verbindung zweier Welten, wörtlich. Die Linie setzt
       nahtlos an (Maße aus der SVG-Geometrie: bei 24px Höhe
       top 10.96px, Stärke 2.58px, Weiß wie die Wortmarke).
       Kundenlogo = Bild-Asset: echtes Logo einsetzen, bis dahin
       bleibt der Mono-Platzhalter. Darunter Eyebrow,
       Display-Titel, Arbeitsstand
       unten — Datum IMMER tagesgenau („17. Juli 2026", nie nur
       Monat/Jahr). Sonst NICHTS — kein Fließtext, keine
       Kopfzeile, keine Seitenzahl, keine Fußzeile.
       ======================================================== -->
  <section class="dslide dslide-dark dslide-moment" data-label="Cover">
    <div class="kasane-layer bg-kasane-cta"></div>
    <svg class="kasane-layer" viewBox="0 0 1440 810" preserveAspectRatio="xMidYMid slice" style="z-index: 1; width: 100%; height: 100%;" aria-hidden="true"><g fill="none" stroke="#F5F1EB" stroke-width="1" opacity="0.10"><path d="M0.0,458.7 L13.1,416.0 L16.8,408.0 L28.2,392.0 L36.3,384.0 L46.3,376.0 L64.0,364.6 L136.0,326.3 L159.5,312.0 L179.2,296.0 L200.4,272.0 L208.0,260.4 L216.0,243.6 L222.8,224.0 L227.0,208.0 L230.7,184.0 L231.8,144.0 L235.0,112.0 L240.4,88.0 L246.5,72.0 L264.0,44.0 L280.0,25.1 L296.0,13.9 L325.9,0.0" /><path d="M0.0,664.0 L3.9,672.0 L11.9,680.0 L32.0,692.3 L56.0,701.9 L96.0,710.4 L104.0,713.2 L112.0,717.0 L128.0,728.1 L144.0,744.0 L152.0,754.9 L159.5,768.0 L168.7,792.0 L173.1,816.0" /><path d="M330.2,816.0 L344.9,800.0 L355.8,784.0 L359.0,776.0 L359.9,768.0 L358.3,760.0 L353.9,752.0 L346.5,744.0 L336.2,736.0 L288.8,704.0 L280.3,696.0 L273.8,688.0 L268.9,680.0 L263.0,664.0 L261.8,656.0 L261.7,640.0 L264.0,626.4 L267.2,616.0 L275.7,600.0 L288.0,586.2 L320.0,560.5 L328.0,549.5 L330.0,544.0 L332.6,520.0 L338.6,496.0 L358.1,440.0 L359.6,432.0 L358.9,424.0 L355.9,416.0 L348.7,408.0 L336.2,400.0 L312.0,390.9 L296.0,388.3 L280.0,387.4 L272.0,387.9 L264.0,391.7 L261.9,400.0 L263.0,432.0 L262.4,448.0 L259.3,464.0 L256.2,472.0 L251.2,480.0 L242.3,488.0 L232.0,492.4 L224.0,493.3 L216.0,492.6 L203.3,488.0 L189.6,480.0 L181.0,472.0 L176.2,464.0 L173.7,456.0 L172.2,440.0 L172.8,432.0 L177.8,416.0 L183.3,408.0 L192.0,400.0 L208.0,392.0 L224.0,388.1 L248.0,384.0 L256.0,379.5 L258.4,368.0 L261.4,304.0 L264.4,280.0 L285.3,200.0 L287.3,184.0 L287.8,160.0 L290.3,144.0 L298.4,120.0 L307.5,104.0 L320.5,88.0 L336.7,72.0 L362.5,48.0 L382.4,32.0 L395.2,24.0 L411.7,16.0 L458.8,0.0" /><path d="M469.3,816.0 L487.5,760.0 L491.7,736.0 L492.2,720.0 L488.7,680.0 L486.9,640.0 L482.4,624.0 L478.2,616.0 L472.0,608.4 L460.7,600.0 L432.0,584.4 L423.1,576.0 L418.2,568.0 L415.2,560.0 L413.1,544.0 L413.6,536.0 L416.0,525.6 L422.2,512.0 L427.9,504.0 L440.0,492.7 L461.1,480.0 L471.2,472.0 L480.0,460.3 L484.9,448.0 L487.7,432.0 L487.3,416.0 L483.9,400.0 L480.6,392.0 L474.5,384.0 L464.0,376.8 L424.0,363.6 L400.0,354.3 L360.0,334.4 L337.9,320.0 L328.0,309.7 L324.2,304.0 L320.9,296.0 L319.4,288.0 L320.1,272.0 L337.2,208.0 L339.3,192.0 L340.0,160.0 L343.5,144.0 L354.0,120.0 L364.4,104.0 L376.0,89.8 L400.0,67.2 L415.7,56.0 L424.0,51.5 L440.0,45.5 L504.0,33.2 L528.0,26.4 L547.7,16.0 L557.4,8.0 L564.6,0.0" /><path d="M640.9,0.0 L648.0,13.9 L655.1,24.0 L684.5,56.0 L696.0,66.1 L720.0,82.9 L728.0,90.6 L736.0,103.0 L739.3,112.0 L743.8,136.0 L745.1,160.0 L744.9,184.0 L740.7,216.0 L734.9,240.0 L715.5,304.0 L706.0,328.0 L696.0,344.7 L688.0,355.4 L664.0,380.3 L640.0,397.7 L603.8,416.0 L599.3,424.0 L602.4,432.0 L624.0,454.7 L632.0,466.4 L638.7,480.0 L648.0,509.4 L653.2,544.0 L657.7,560.0 L666.4,576.0 L688.0,603.6 L700.5,624.0 L704.1,632.0 L708.7,648.0 L710.1,664.0 L709.1,672.0 L704.0,686.7 L696.0,699.4 L684.3,712.0 L672.0,720.9 L656.0,728.7 L640.0,734.0 L584.0,743.7 L568.0,748.8 L560.0,753.0 L552.0,760.6 L536.2,784.0 L530.0,800.0 L526.0,816.0" /><path d="M626.9,816.0 L669.6,776.0 L704.0,748.3 L720.0,733.4 L728.0,723.7 L736.0,710.7 L742.1,696.0 L746.2,680.0 L747.6,664.0 L747.1,656.0 L742.3,624.0 L735.7,600.0 L720.0,560.0 L715.2,544.0 L705.1,472.0 L702.8,440.0 L703.1,424.0 L705.6,408.0 L708.0,400.0 L732.1,344.0 L742.2,312.0 L762.8,216.0 L765.7,192.0 L767.2,160.0 L770.2,136.0 L776.0,111.1 L792.4,64.0 L800.0,0.0" /><path d="M846.5,0.0 L825.2,72.0 L799.3,128.0 L791.2,152.0 L788.5,168.0 L784.8,216.0 L768.1,312.0 L760.9,344.0 L747.5,392.0 L743.1,416.0 L743.1,440.0 L746.6,464.0 L766.1,536.0 L774.3,584.0 L782.6,664.0 L782.5,680.0 L780.4,696.0 L773.7,720.0 L766.7,736.0 L760.0,747.9 L728.0,792.5 L706.2,816.0" /><path d="M876.5,0.0 L849.8,72.0 L821.4,136.0 L814.2,160.0 L808.4,224.0 L793.2,320.0 L781.1,384.0 L777.6,408.0 L776.9,432.0 L779.0,448.0 L785.4,472.0 L800.4,512.0 L807.8,536.0 L818.6,600.0 L823.8,624.0 L832.0,645.9 L846.4,672.0 L849.0,680.0 L849.9,688.0 L847.7,696.0 L842.9,704.0 L832.0,716.5 L824.0,728.0 L816.0,742.1 L808.0,760.8 L803.7,776.0 L800.9,792.0 L801.5,816.0" /><path d="M849.9,816.0 L858.7,800.0 L872.0,770.7 L880.0,756.9 L888.0,750.2 L896.0,750.1 L904.0,755.1 L912.0,764.7 L920.0,779.7 L926.5,800.0 L930.0,816.0" /><path d="M908.7,0.0 L888.0,39.3 L853.3,112.0 L843.2,136.0 L838.2,152.0 L835.3,168.0 L832.5,224.0 L823.6,312.0 L811.7,400.0 L810.5,416.0 L810.8,432.0 L815.3,456.0 L833.8,512.0 L846.2,560.0 L856.0,582.9 L864.0,594.3 L872.0,602.3 L888.0,613.4 L920.0,631.6 L928.0,638.4 L935.8,648.0 L939.6,656.0 L946.6,688.0 L951.3,728.0 L962.1,784.0 L965.8,816.0" /><path d="M995.6,816.0 L995.5,792.0 L993.9,776.0 L986.5,728.0 L981.8,688.0 L975.6,656.0 L972.8,648.0 L963.3,632.0 L952.0,620.1 L936.2,608.0 L899.1,584.0 L888.0,573.6 L880.0,562.8 L871.5,544.0 L852.5,464.0 L848.5,440.0 L847.7,416.0 L853.6,296.0 L856.3,168.0 L859.1,152.0 L864.1,136.0 L880.0,101.5 L904.0,61.9 L920.0,41.6 L928.0,33.9 L944.0,22.5 L960.0,16.4 L976.0,14.1 L1008.0,13.3 L1024.0,11.5 L1040.0,6.3 L1050.4,0.0" /><path d="M1031.3,816.0 L1040.8,784.0 L1041.8,776.0 L1041.3,760.0 L1038.4,744.0 L1028.3,704.0 L1011.2,648.0 L1003.2,632.0 L997.9,624.0 L983.4,608.0 L968.0,595.9 L928.0,570.8 L912.0,556.7 L903.7,544.0 L896.7,520.0 L892.5,496.0 L889.3,464.0 L889.6,408.0 L885.2,336.0 L883.4,280.0 L878.2,208.0 L877.9,168.0 L880.0,155.2 L883.2,144.0 L888.0,131.6 L896.0,115.9 L912.0,93.0 L920.0,84.7 L928.0,78.3 L944.0,69.0 L968.0,61.3 L984.0,59.1 L1024.0,56.1 L1040.0,52.2 L1048.0,48.4 L1064.0,36.1 L1100.3,0.0" /><path d="M1095.0,816.0 L1116.6,776.0 L1128.0,760.7 L1144.0,746.0 L1177.8,720.0 L1185.8,712.0 L1191.7,704.0 L1195.8,696.0 L1200.7,680.0 L1201.1,664.0 L1197.3,648.0 L1190.3,632.0 L1178.9,616.0 L1160.0,597.6 L1144.0,587.8 L1128.0,582.7 L1112.0,581.2 L1064.0,586.3 L1048.0,585.6 L1040.0,583.6 L984.0,560.4 L968.0,552.6 L955.7,544.0 L948.9,536.0 L940.7,520.0 L936.0,504.5 L934.6,496.0 L933.2,472.0 L937.6,424.0 L937.0,408.0 L933.9,384.0 L924.0,328.0 L919.0,280.0 L908.5,232.0 L904.4,208.0 L902.5,184.0 L902.9,168.0 L906.3,152.0 L912.0,138.8 L920.0,126.8 L928.0,118.8 L936.0,113.6 L944.0,110.2 L952.0,108.4 L968.0,108.6 L976.0,110.9 L984.0,115.3 L989.4,120.0 L995.1,128.0 L998.5,136.0 L1001.5,152.0 L1001.3,184.0 L1002.7,192.0 L1008.0,204.8 L1016.0,214.8 L1024.0,220.6 L1032.0,224.2 L1040.0,225.9 L1056.0,225.2 L1064.0,223.0 L1072.0,218.9 L1081.7,208.0 L1085.0,200.0 L1087.9,184.0 L1087.4,168.0 L1082.7,128.0 L1081.9,112.0 L1084.0,88.0 L1088.4,72.0 L1098.8,48.0 L1109.7,32.0 L1124.2,16.0 L1142.8,0.0" /><path d="M1149.0,816.0 L1162.5,792.0 L1176.0,776.5 L1216.0,748.3 L1229.4,736.0 L1235.2,728.0 L1239.4,720.0 L1242.0,712.0 L1244.3,696.0 L1244.4,680.0 L1242.6,664.0 L1237.0,640.0 L1229.1,616.0 L1216.0,588.4 L1185.5,544.0 L1181.1,536.0 L1179.3,528.0 L1180.1,520.0 L1182.9,512.0 L1200.0,479.5 L1206.0,464.0 L1210.4,448.0 L1213.2,432.0 L1214.0,416.0 L1213.0,384.0 L1207.0,296.0 L1205.7,288.0 L1198.7,272.0 L1193.0,264.0 L1185.3,256.0 L1175.2,248.0 L1149.6,232.0 L1140.0,224.0 L1136.0,219.3 L1128.0,202.9 L1124.8,184.0 L1123.7,136.0 L1124.2,112.0 L1127.9,80.0 L1133.3,56.0 L1136.8,48.0 L1142.0,40.0 L1149.0,32.0 L1188.4,0.0" /><path d="M1223.4,0.0 L1214.4,16.0 L1189.5,48.0 L1185.5,56.0 L1181.2,80.0 L1177.6,112.0 L1175.9,144.0 L1176.1,176.0 L1176.8,184.0 L1180.3,192.0 L1186.3,200.0 L1216.0,231.7 L1228.3,248.0 L1236.5,264.0 L1241.3,280.0 L1242.7,296.0 L1238.6,368.0 L1237.0,432.0 L1234.0,480.0 L1234.3,512.0 L1239.3,536.0 L1256.0,584.5 L1272.0,641.2 L1280.8,680.0 L1282.9,704.0 L1282.1,720.0 L1280.0,731.0 L1275.9,744.0 L1268.2,760.0 L1256.0,776.9 L1217.0,816.0" /><path d="M1255.3,0.0 L1252.3,24.0 L1245.4,64.0 L1243.5,88.0 L1243.6,120.0 L1246.7,184.0 L1250.4,200.0 L1267.1,248.0 L1271.6,272.0 L1272.2,288.0 L1258.9,392.0 L1257.4,440.0 L1258.4,472.0 L1261.4,496.0 L1266.6,520.0 L1306.9,664.0 L1311.3,688.0 L1312.4,704.0 L1310.5,728.0 L1304.4,752.0 L1296.0,773.1 L1276.2,816.0" /><path d="M1288.0,0.0 L1288.8,40.0 L1286.2,96.0 L1288.9,184.0 L1291.0,208.0 L1298.1,256.0 L1298.8,280.0 L1297.2,296.0 L1283.9,360.0 L1279.0,392.0 L1276.8,424.0 L1277.6,456.0 L1281.9,488.0 L1289.0,520.0 L1308.5,592.0 L1331.5,664.0 L1336.3,688.0 L1337.5,704.0 L1336.7,720.0 L1332.1,744.0 L1327.2,760.0 L1306.0,816.0" /><path d="M1320.6,0.0 L1322.6,40.0 L1318.1,112.0 L1317.0,184.0 L1318.4,208.0 L1323.3,248.0 L1324.0,272.0 L1320.8,296.0 L1305.9,352.0 L1299.4,384.0 L1295.9,416.0 L1295.7,448.0 L1300.2,488.0 L1310.3,536.0 L1324.3,584.0 L1354.7,664.0 L1360.3,688.0 L1361.7,704.0 L1360.8,720.0 L1356.0,744.0 L1330.3,816.0" /><path d="M1351.7,0.0 L1355.3,32.0 L1355.4,56.0 L1344.2,136.0 L1341.6,184.0 L1342.9,208.0 L1347.7,248.0 L1348.1,272.0 L1343.6,296.0 L1327.5,344.0 L1319.0,376.0 L1313.9,408.0 L1312.6,440.0 L1313.5,464.0 L1317.3,496.0 L1323.6,528.0 L1330.1,552.0 L1344.5,592.0 L1371.7,648.0 L1378.4,664.0 L1383.5,680.0 L1386.5,696.0 L1386.8,712.0 L1382.7,736.0 L1374.9,760.0 L1353.1,816.0" /><path d="M1382.4,0.0 L1387.3,32.0 L1388.0,56.0 L1384.3,80.0 L1373.9,120.0 L1368.9,144.0 L1365.5,184.0 L1366.9,208.0 L1372.0,248.0 L1371.9,272.0 L1366.1,296.0 L1346.6,344.0 L1336.6,376.0 L1330.6,408.0 L1328.6,448.0 L1329.4,472.0 L1333.2,504.0 L1340.0,536.0 L1347.7,560.0 L1357.8,584.0 L1366.0,600.0 L1405.1,664.0 L1412.1,680.0 L1416.0,696.0 L1416.1,712.0 L1411.0,736.0 L1405.2,752.0 L1386.1,792.0 L1376.2,816.0" /><path d="M1413.7,0.0 L1420.3,32.0 L1421.6,56.0 L1417.0,80.0 L1400.0,130.4 L1393.1,160.0 L1391.1,192.0 L1397.5,248.0 L1396.4,272.0 L1392.2,288.0 L1365.6,344.0 L1356.3,368.0 L1351.5,384.0 L1345.9,416.0 L1344.0,448.0 L1344.1,472.0 L1347.2,504.0 L1351.9,528.0 L1359.6,552.0 L1368.0,571.1 L1379.8,592.0 L1392.0,609.2 L1426.1,648.0 L1440.0,665.6" /><path d="M1440.0,628.2 L1416.0,607.9 L1400.0,591.5 L1388.3,576.0 L1376.0,554.4 L1368.5,536.0 L1362.5,512.0 L1359.5,488.0 L1358.8,464.0 L1363.0,408.0 L1366.3,392.0 L1371.1,376.0 L1384.9,344.0 L1417.1,288.0 L1425.6,264.0 L1429.2,240.0 L1428.2,200.0 L1429.2,184.0 L1435.1,160.0 L1440.0,148.1" /><path d="M1440.0,601.8 L1424.0,589.6 L1408.0,574.1 L1396.9,560.0 L1387.6,544.0 L1381.1,528.0 L1377.1,512.0 L1374.8,496.0 L1373.8,472.0 L1375.0,448.0 L1378.4,416.0 L1381.2,400.0 L1386.0,384.0 L1392.4,368.0 L1405.3,344.0 L1416.0,327.6 L1440.0,295.6" /><path d="M1440.0,577.5 L1428.1,568.0 L1416.0,556.0 L1401.9,536.0 L1398.2,528.0 L1393.2,512.0 L1390.5,496.0 L1389.6,480.0 L1390.6,456.0 L1395.6,416.0 L1401.5,392.0 L1408.1,376.0 L1416.0,361.6 L1428.1,344.0 L1440.0,329.2" /><path d="M1440.0,552.0 L1424.7,536.0 L1415.4,520.0 L1410.3,504.0 L1407.5,480.0 L1408.5,456.0 L1416.1,408.0 L1425.6,384.0 L1440.0,361.7" /><path d="M1440.0,517.5 L1433.7,504.0 L1431.3,496.0 L1428.8,472.0 L1429.7,456.0 L1432.0,440.0 L1436.8,416.0 L1440.0,405.6" /></g></svg>
    <div class="grain-layer grain-screen"></div>
    <div class="dslide-content" style="display: flex; flex-direction: column; align-items: flex-start; height: 100%; justify-content: space-between;">
      <!-- Kopf: Logo-Brücke (Wortmarke, Linie, Kundenlogo) — nur für
           Kundendecks. Interne Decks: diesem Container zusätzlich
           class="cover-head-intern" geben, dann bleibt allein die
           Wortmarke (Nils, 2026-07-22). -->
      <div class="cover-head" style="display: flex; align-items: center; width: 100%;">
        <img class="wordmark" src="data:," data-wm="w" alt="Bridgemaker" style="flex-shrink: 0;" />
        <!-- Brücken-Container fest 24px hoch und zentriert wie die
             Wortmarke — NIE align-self: stretch: ein Kundenlogo
             über 24px streckt den Container sonst mit und hebt die
             Linie vom Wortmarken-Strich ab (Nils, 2026-07-24;
             deck-lint prüft Naht und Höhe). -->
        <div class="cover-bridge" style="flex: 1; align-self: center; height: 24px; position: relative;">
          <div style="position: absolute; left: -2px; right: 0; top: 10.96px; height: 2.58px; background: #fff;"></div>
        </div>
        <span class="cover-client" style="flex-shrink: 0; margin-left: var(--space-6); font: 500 14px/1 var(--font-mono); color: var(--soft);">[ Kundenlogo ]</span>
      </div>
      <div>
        <div class="type-eyebrow" style="color: var(--soft); margin-bottom: var(--space-6);">Kunde × Bridgemaker — Anlass</div>
        <h1 class="type-display-l" style="margin: 0; max-width: 1080px; color: var(--off-white);">Titel des Decks über<br />maximal zwei Zeilen</h1>
      </div>
      <div class="type-small" style="color: var(--soft);">Gemeinsamer Arbeitsstand, 17. Juli 2026</div>
    </div>
  </section>

  <!-- ========================================================
       LAYOUT „AGENDA" — offene Hairline-Zeilen, KEINE Boxen.
       Ab vier Punkten zweispaltig (1–3 links, 4–6 rechts).
       Ziffern in Inter. Hairline über JEDER Zeile (die Linie
       eröffnet — ein Job, eine Ebene).
       ======================================================== -->
  <section class="dslide" data-label="Agenda">
    <header class="slide-head"><span class="type-eyebrow">Agenda</span></header>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content">
      <h2 class="type-h1 deck-title">Der Ablauf für heute</h2>
      <div class="deck-body">
        <div class="agenda-grid">
          <div class="agenda-row">
            <span class="agenda-num type-body">01</span>
            <div><div class="type-h4">Erster Punkt</div><div class="type-small" style="color: var(--dark); margin-top: var(--space-1);">Ein halber Satz dazu</div></div>
          </div>
          <div class="agenda-row">
            <span class="agenda-num type-body">04</span>
            <div><div class="type-h4">Vierter Punkt</div><div class="type-small" style="color: var(--dark); margin-top: var(--space-1);">Ein halber Satz dazu</div></div>
          </div>
          <div class="agenda-row">
            <span class="agenda-num type-body">02</span>
            <div><div class="type-h4">Zweiter Punkt</div><div class="type-small" style="color: var(--dark); margin-top: var(--space-1);">Ein halber Satz dazu</div></div>
          </div>
          <div class="agenda-row">
            <span class="agenda-num type-body">05</span>
            <div><div class="type-h4">Fünfter Punkt</div><div class="type-small" style="color: var(--dark); margin-top: var(--space-1);">Ein halber Satz dazu</div></div>
          </div>
          <div class="agenda-row">
            <span class="agenda-num type-body">03</span>
            <div><div class="type-h4">Dritter Punkt</div><div class="type-small" style="color: var(--dark); margin-top: var(--space-1);">Ein halber Satz dazu</div></div>
          </div>
          <div class="agenda-row">
            <span class="agenda-num type-body">06</span>
            <div><div class="type-h4">Sechster Punkt</div><div class="type-small" style="color: var(--dark); margin-top: var(--space-1);">Ein halber Satz dazu</div></div>
          </div>
        </div>
      </div>
    </div>
  </section>


  <!-- ========================================================
       LAYOUT „ZIEL UND AGENDA" — der Meeting-Opener, wenn die
       Session ENTSCHEIDUNGEN braucht (statt reiner Agenda):
       links die Entscheidungspunkte (das Ziel), rechts der
       Ablauf in Kapiteln mit halbem Erklärsatz. Beide Spalten
       als Hairline-Zeilen mit Inter-Ziffern — gleiche Anatomie
       wie die Agenda. Headline nennt die Entscheidung, nicht
       den Termin. Quelle: examples/beispiel-kundendeck.html.
       ======================================================== -->
  <section class="dslide" data-label="Ziel und Agenda">
    <header class="slide-head"><span class="type-eyebrow">Ziel und Agenda</span></header>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content">
      <h2 class="type-h1 deck-title" style="max-width: 1000px;">Heute priorisieren wir A und entscheiden über B</h2>
      <div class="deck-body">
        <div style="display: grid; grid-template-columns: 1fr 1fr; column-gap: var(--space-16);">
          <div>
            <div class="type-eyebrow" style="color: var(--mid); margin-bottom: var(--space-4);">Ihr entscheidet heute über drei Punkte</div>
            <div class="agenda-row"><span class="agenda-num type-body">01</span><div class="type-h4">Erster Entscheidungspunkt</div></div>
            <div class="agenda-row"><span class="agenda-num type-body">02</span><div class="type-h4">Zweiter Entscheidungspunkt</div></div>
            <div class="agenda-row"><span class="agenda-num type-body">03</span><div class="type-h4">Dritter Entscheidungspunkt</div></div>
          </div>
          <div>
            <div class="type-eyebrow" style="color: var(--mid); margin-bottom: var(--space-4);">Ablauf in vier Kapiteln</div>
            <div class="agenda-row"><span class="agenda-num type-body">01</span><div><div class="type-h4">Erstes Kapitel</div><div class="type-small" style="color: var(--mid); margin-top: var(--space-1);">Halber Satz, was hier passiert</div></div></div>
            <div class="agenda-row"><span class="agenda-num type-body">02</span><div><div class="type-h4">Zweites Kapitel</div><div class="type-small" style="color: var(--mid); margin-top: var(--space-1);">Halber Satz, was hier passiert</div></div></div>
            <div class="agenda-row"><span class="agenda-num type-body">03</span><div><div class="type-h4">Drittes Kapitel</div><div class="type-small" style="color: var(--mid); margin-top: var(--space-1);">Halber Satz, was hier passiert</div></div></div>
            <div class="agenda-row"><span class="agenda-num type-body">04</span><div><div class="type-h4">Viertes Kapitel</div><div class="type-small" style="color: var(--mid); margin-top: var(--space-1);">Halber Satz, was hier passiert</div></div></div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- ========================================================
       ROLLE „KAPITELTRENNER" — weiches Kapitelband
       (bg-kasane-band-*, EINE Farbwelt pro Kapitel, die das
       Kapitel dann durchhält) + große Inter-Kapitelziffer
       (light) + topografische Konturen in Hellgrau
       (node deck-topo-konturen.js cover <seed> "#C5C0B8" 0.6).
       Der Trenner sagt: hier beginnt ein neues Thema.
       ======================================================== -->
  <section class="dslide dslide-moment" data-label="Kapiteltrenner">
    <div class="kasane-layer bg-kasane-band-mauve"></div>
    <svg class="kasane-layer" viewBox="0 0 1440 810" preserveAspectRatio="xMidYMid slice" style="z-index: 1; width: 100%; height: 100%;" aria-hidden="true"><g fill="none" stroke="#C5C0B8" stroke-width="1" opacity="0.6"><path d="M0.0,132.8 L20.1,120.0 L41.3,104.0 L96.0,54.3 L120.0,34.5 L152.0,14.2 L183.0,0.0" /><path d="M1138.8,816.0 L1280.0,793.7 L1336.0,783.3 L1384.0,772.1 L1440.0,753.3" /><path d="M0.0,184.8 L50.3,160.0 L128.0,115.1 L160.0,99.1 L200.0,84.9 L296.0,60.6 L337.0,48.0 L360.0,38.8 L384.0,27.2 L428.7,0.0" /><path d="M793.1,816.0 L824.0,801.4 L848.0,791.5 L872.0,783.3 L896.0,777.2 L920.0,773.0 L952.0,769.5 L984.0,767.8 L1072.0,765.8 L1120.0,761.1 L1192.0,747.5 L1256.0,733.3 L1440.0,684.4" /><path d="M0.0,224.7 L40.5,208.0 L136.0,164.3 L168.0,151.8 L216.0,137.7 L328.0,111.0 L352.0,103.9 L384.0,92.2 L408.0,81.2 L424.8,72.0 L504.0,20.0 L539.8,0.0" /><path d="M697.2,816.0 L728.0,803.5 L825.5,760.0 L856.0,748.7 L888.0,739.6 L920.0,733.5 L952.0,729.8 L1080.0,723.5 L1112.0,720.1 L1136.0,716.1 L1216.0,698.3 L1352.0,659.0 L1440.0,636.0" /><path d="M0.0,259.5 L136.0,205.6 L168.0,194.3 L216.0,181.2 L328.0,155.5 L360.0,145.9 L392.0,134.0 L422.8,120.0 L448.0,106.1 L528.0,53.1 L560.0,34.2 L600.0,15.1 L641.0,0.0" /><path d="M483.6,816.0 L584.0,803.5 L632.0,795.3 L664.0,788.3 L712.0,772.4 L832.0,722.8 L864.0,712.0 L888.0,705.6 L912.0,700.9 L944.0,696.6 L976.0,694.0 L1080.0,688.7 L1112.0,685.2 L1136.0,681.1 L1176.0,672.4 L1216.0,662.0 L1344.0,622.8 L1440.0,597.0" /><path d="M0.0,292.3 L128.0,244.0 L176.0,228.0 L216.0,218.0 L320.0,196.4 L352.0,187.8 L384.0,176.9 L416.0,163.2 L448.0,146.0 L480.0,126.1 L560.0,73.2 L584.0,59.4 L608.0,47.5 L640.0,34.3 L680.0,21.5 L720.0,11.1 L770.9,0.0" /><path d="M0.0,760.4 L64.0,782.0 L112.0,794.6 L152.0,801.4 L200.0,804.4 L256.0,804.1 L328.0,799.5 L472.0,784.8 L560.0,774.1 L632.0,762.2 L656.0,757.0 L680.0,750.4 L720.0,736.3 L824.0,694.5 L856.0,683.5 L880.0,676.8 L912.0,670.2 L944.0,666.0 L1080.0,657.8 L1112.0,654.2 L1136.0,650.0 L1176.0,641.0 L1216.0,630.1 L1336.0,592.3 L1440.0,562.1" /><path d="M0.0,324.8 L104.0,284.8 L176.0,260.7 L216.0,251.0 L304.0,234.7 L336.0,227.8 L368.0,218.9 L400.0,207.3 L424.0,196.4 L456.0,178.6 L560.0,109.7 L592.0,90.1 L624.0,73.6 L656.0,60.5 L696.0,47.7 L744.0,35.4 L916.3,0.0" /><path d="M0.0,727.1 L56.0,748.0 L112.0,764.0 L152.0,771.2 L200.0,774.8 L256.0,774.7 L320.0,770.7 L480.0,753.6 L560.0,743.9 L624.0,733.5 L672.0,722.3 L720.0,706.0 L827.3,664.0 L856.0,654.6 L888.0,646.2 L920.0,640.4 L952.0,636.8 L1056.0,631.2 L1096.0,627.8 L1128.0,623.0 L1168.0,614.2 L1240.0,593.6 L1440.0,528.5" /><path d="M0.0,359.1 L40.0,341.0 L88.0,321.8 L136.0,304.4 L176.0,291.6 L224.0,280.4 L312.0,265.7 L344.0,259.2 L376.0,250.6 L405.3,240.0 L432.0,227.7 L464.0,209.5 L568.0,139.5 L608.0,114.8 L640.0,98.4 L680.0,82.7 L728.0,68.1 L800.0,50.9 L976.0,13.6 L1024.0,5.0 L1059.4,0.0" /><path d="M1210.5,0.0 L1256.0,7.3 L1312.0,20.4 L1384.0,40.7 L1440.0,61.3" /><path d="M0.0,692.8 L56.0,716.6 L104.0,732.1 L128.0,737.9 L152.0,742.2 L200.0,746.4 L256.0,746.5 L312.0,743.1 L560.0,715.2 L624.0,704.8 L672.0,693.4 L720.0,677.1 L824.0,637.0 L856.0,626.7 L888.0,618.6 L920.0,613.0 L952.0,609.6 L1056.0,604.2 L1096.0,600.7 L1128.0,595.9 L1168.0,586.9 L1216.0,573.5 L1264.0,558.0 L1392.0,513.9 L1440.0,495.5" /><path d="M0.0,398.1 L39.2,376.0 L73.0,360.0 L120.0,340.9 L168.0,324.2 L192.0,317.4 L224.0,310.6 L319.8,296.0 L352.0,289.9 L384.0,281.4 L416.0,269.6 L440.0,258.1 L472.0,239.6 L576.0,168.6 L615.2,144.0 L648.0,126.8 L688.0,110.2 L728.0,96.9 L776.0,83.8 L960.0,41.4 L1032.0,28.2 L1088.0,21.6 L1136.0,19.8 L1184.0,22.5 L1232.0,29.7 L1288.0,43.1 L1384.0,72.7 L1440.0,94.2" /><path d="M0.0,654.8 L24.0,668.5 L48.0,680.4 L80.0,693.6 L104.0,701.8 L128.0,708.4 L152.0,713.3 L200.0,718.3 L248.0,719.0 L304.0,715.8 L568.0,686.1 L624.0,676.9 L672.0,665.2 L712.0,651.8 L824.0,609.3 L856.0,599.3 L888.0,591.4 L912.0,587.3 L944.0,583.8 L1048.0,578.6 L1088.0,575.5 L1128.0,569.6 L1168.0,560.6 L1216.0,546.9 L1280.0,525.1 L1392.0,483.1 L1440.0,462.0" /><path d="M0.0,448.9 L9.1,440.0 L28.4,424.0 L65.5,400.0 L112.0,376.9 L160.0,358.0 L192.0,348.0 L224.0,341.0 L328.0,326.5 L360.0,320.7 L392.0,312.4 L424.0,300.4 L448.0,288.6 L480.0,269.9 L512.0,248.5 L584.0,197.6 L616.0,176.9 L648.0,159.1 L688.0,141.1 L728.0,126.3 L776.0,111.5 L952.0,67.3 L1024.0,53.2 L1080.0,46.0 L1136.0,43.5 L1184.0,46.9 L1232.0,55.4 L1288.0,70.7 L1392.0,106.2 L1440.0,126.7" /><path d="M0.0,604.3 L11.8,616.0 L32.0,632.0 L56.0,647.1 L80.0,659.4 L111.3,672.0 L136.0,679.5 L160.0,684.7 L184.0,688.1 L208.0,690.0 L240.0,690.7 L296.0,688.1 L432.0,672.0 L560.0,658.8 L616.0,650.3 L664.0,639.3 L710.4,624.0 L816.0,584.1 L848.0,574.2 L880.0,566.5 L904.0,562.4 L936.0,558.9 L1048.0,553.2 L1088.0,549.9 L1128.0,543.9 L1168.0,534.8 L1224.0,518.1 L1296.0,491.5 L1384.0,455.1 L1415.7,440.0 L1440.0,426.7" /><path d="M1440.0,386.9 L1416.0,403.4 L1384.0,421.9 L1296.0,463.3 L1256.0,479.8 L1224.0,491.7 L1186.1,504.0 L1152.0,513.2 L1120.0,519.9 L1080.0,525.4 L1040.0,528.6 L936.0,533.7 L904.0,536.8 L880.0,540.3 L848.0,547.1 L816.0,556.1 L780.8,568.0 L688.0,602.4 L656.0,612.2 L624.0,619.5 L560.0,629.2 L424.0,642.0 L312.0,656.3 L280.0,659.0 L248.0,660.3 L200.0,658.4 L160.0,652.0 L144.0,647.7 L120.0,639.0 L104.0,631.6 L80.0,617.4 L64.0,605.1 L50.7,592.0 L38.4,576.0 L29.8,560.0 L24.5,544.0 L22.5,528.0 L23.8,512.0 L28.3,496.0 L36.4,480.0 L48.1,464.0 L63.9,448.0 L84.2,432.0 L109.7,416.0 L136.0,402.5 L176.0,385.9 L210.7,376.0 L248.0,369.2 L328.0,359.7 L360.0,354.8 L392.0,347.4 L416.0,339.3 L448.0,324.8 L480.0,306.4 L512.0,285.2 L609.0,216.0 L640.0,197.0 L680.0,176.6 L720.0,159.6 L768.0,142.6 L824.0,125.9 L928.0,97.4 L1000.0,81.0 L1064.0,71.0 L1096.0,68.1 L1128.0,66.9 L1152.0,67.6 L1176.0,69.8 L1200.0,73.5 L1232.0,80.6 L1264.0,89.7 L1296.0,100.5 L1389.3,136.0 L1416.0,149.0 L1440.0,163.4" /><path d="M1440.0,334.5 L1424.4,352.0 L1400.0,372.8 L1376.0,389.3 L1344.2,408.0 L1298.9,432.0 L1264.0,448.3 L1224.0,464.7 L1184.0,478.4 L1136.0,490.9 L1088.0,498.9 L1040.0,503.2 L920.0,509.5 L888.0,512.8 L856.0,518.0 L824.0,525.4 L792.0,534.6 L696.0,568.2 L664.0,578.3 L632.0,586.2 L592.0,593.1 L544.0,598.3 L424.0,607.3 L328.0,620.0 L288.0,624.1 L248.0,625.5 L208.0,623.1 L184.0,618.9 L160.0,611.9 L136.0,600.8 L122.4,592.0 L104.6,576.0 L93.0,560.0 L86.2,544.0 L83.7,528.0 L85.2,512.0 L90.7,496.0 L96.0,486.7 L107.3,472.0 L120.0,459.8 L135.3,448.0 L152.0,437.6 L176.0,425.3 L201.2,416.0 L232.0,408.3 L264.0,403.3 L336.0,395.7 L368.0,391.1 L400.0,383.7 L424.0,375.4 L448.0,364.5 L480.0,346.4 L512.0,325.0 L592.0,265.4 L624.0,243.1 L656.0,223.7 L696.0,203.0 L744.0,182.0 L805.4,160.0 L909.4,128.0 L976.0,110.3 L1040.0,97.8 L1072.0,93.6 L1104.0,91.1 L1128.0,90.4 L1152.0,91.2 L1176.0,93.8 L1208.0,99.8 L1240.0,108.2 L1280.0,121.6 L1315.7,136.0 L1367.5,160.0 L1392.0,173.5 L1407.8,184.0 L1427.0,200.0 L1440.0,214.2" /></g></svg>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content" style="display: flex; flex-direction: row; align-items: flex-end; justify-content: space-between; gap: var(--space-16); margin-top: auto;">
      <div style="padding-bottom: var(--space-4);">
        <div class="type-eyebrow" style="color: var(--dark); margin-bottom: var(--space-6);">Kapitel 01</div>
        <h2 class="type-display" style="margin: 0; max-width: 880px;">Eine Zeile, die das Kapitel trägt</h2>
      </div>
      <div class="chapter-num">01</div>
    </div>
  </section>

  <!-- Zweiter Trenner als Beispiel fuer die Variation: naechste
       Band-Farbwelt (sage) + eigenes Linienbild (Seed 20260719).
       Muster: Kapitel N = Band-Variante N + Seed Basis+N. -->
  <section class="dslide dslide-moment" data-label="Kapiteltrenner 02">
    <div class="kasane-layer bg-kasane-band-sage"></div>
    <svg class="kasane-layer" viewBox="0 0 1440 810" preserveAspectRatio="xMidYMid slice" style="z-index: 1; width: 100%; height: 100%;" aria-hidden="true"><g fill="none" stroke="#C5C0B8" stroke-width="1" opacity="0.6"><path d="M1167.8,0.0 L1208.0,11.3 L1240.0,22.8 L1272.0,36.8 L1327.7,64.0 L1352.0,74.1 L1398.5,88.0 L1440.0,97.9" /><path d="M0.0,743.0 L32.0,749.0 L80.0,755.9 L368.0,790.1 L529.4,816.0" /><path d="M946.4,0.0 L1104.0,34.6 L1160.0,49.0 L1208.0,66.4 L1290.3,104.0 L1329.3,120.0 L1368.0,131.8 L1440.0,148.2" /><path d="M0.0,684.9 L40.0,697.2 L72.0,705.6 L136.0,718.4 L200.0,727.5 L336.0,740.8 L392.0,747.8 L648.0,792.8 L688.0,802.2 L725.8,816.0" /><path d="M796.7,0.0 L920.0,31.5 L1136.0,83.8 L1184.0,100.0 L1269.7,136.0 L1312.6,152.0 L1360.0,166.0 L1440.0,185.1" /><path d="M0.0,642.7 L72.0,667.4 L104.0,676.1 L144.0,684.8 L208.0,694.2 L336.0,705.7 L400.0,713.4 L440.0,720.3 L576.0,748.3 L672.0,765.4 L704.0,773.4 L736.0,783.5 L818.0,816.0" /><path d="M663.8,0.0 L752.0,24.0 L872.0,52.0 L1128.0,118.5 L1168.0,131.1 L1267.7,168.0 L1312.0,182.7 L1344.0,192.0 L1440.0,216.5" /><path d="M0.0,608.0 L80.0,637.4 L112.0,646.8 L144.0,654.4 L176.0,660.3 L208.0,664.5 L360.0,678.3 L400.0,683.3 L432.0,688.7 L584.0,722.1 L672.0,738.0 L704.0,744.9 L758.1,760.0 L848.0,789.6 L872.0,795.8 L896.0,800.0 L920.0,801.9 L952.0,801.6 L1072.0,790.5 L1120.0,788.8 L1168.0,791.0 L1272.0,799.5 L1328.0,800.9 L1360.0,799.2 L1440.0,789.6" /><path d="M532.0,0.0 L680.0,40.0 L736.0,52.8 L840.0,74.2 L880.0,83.8 L1008.0,119.3 L1144.0,155.3 L1304.0,207.7 L1400.0,233.3 L1440.0,245.2" /><path d="M0.0,577.9 L88.0,611.0 L120.0,620.8 L152.0,628.6 L184.0,634.5 L216.0,638.7 L360.0,651.7 L400.0,656.6 L432.0,662.0 L592.0,698.9 L720.0,723.1 L768.0,734.9 L856.0,759.2 L880.0,764.6 L904.0,768.2 L928.0,770.1 L960.0,770.3 L1072.0,763.6 L1120.0,762.5 L1160.0,764.2 L1272.0,772.3 L1320.0,773.2 L1368.0,769.9 L1440.0,758.8" /><path d="M0.0,42.4 L48.0,36.5 L168.0,25.7 L288.0,11.6 L336.0,7.6 L368.0,6.4 L400.0,6.9 L432.0,9.3 L464.0,13.7 L496.0,19.7 L528.0,27.4 L624.7,56.0 L672.0,68.2 L727.2,80.0 L824.0,98.6 L864.0,107.9 L989.6,144.0 L1152.0,186.1 L1273.7,224.0 L1392.0,256.9 L1440.0,272.5" /><path d="M0.0,551.0 L96.0,586.7 L128.0,596.7 L160.0,604.6 L192.0,610.4 L224.0,614.8 L360.0,627.3 L424.0,636.0 L472.0,646.2 L600.0,677.5 L736.0,702.4 L864.0,731.7 L904.0,738.8 L936.0,741.7 L968.0,742.4 L1080.0,738.6 L1128.0,738.4 L1264.0,747.1 L1312.0,748.1 L1344.0,746.7 L1368.0,744.1 L1408.0,737.4 L1440.0,730.4" /><path d="M0.0,68.4 L56.0,60.6 L160.0,50.0 L272.0,36.4 L320.0,32.1 L360.0,30.2 L392.0,30.4 L424.0,32.5 L456.0,36.7 L488.0,42.9 L520.0,50.9 L616.0,80.1 L656.0,90.9 L704.0,101.5 L808.0,121.7 L856.0,132.9 L976.1,168.0 L1160.0,214.5 L1280.0,250.2 L1384.0,279.6 L1409.6,288.0 L1440.0,299.7" /><path d="M0.0,525.8 L104.0,563.8 L136.0,573.7 L168.0,581.6 L200.0,587.5 L232.0,592.0 L368.0,605.2 L424.0,612.9 L472.0,623.1 L568.0,647.8 L616.0,658.8 L752.0,682.2 L872.0,706.2 L912.0,712.7 L944.0,715.6 L976.0,716.7 L1096.0,715.1 L1136.0,715.6 L1256.0,723.3 L1312.0,724.4 L1344.0,722.6 L1368.0,719.6 L1408.0,711.6 L1440.0,702.9" /><path d="M0.0,94.6 L64.0,84.1 L256.0,60.2 L304.0,55.3 L344.0,52.9 L384.0,52.5 L416.0,54.2 L448.0,58.1 L480.0,64.3 L512.0,72.3 L643.8,112.0 L832.0,152.9 L864.0,161.4 L928.0,181.1 L976.0,194.4 L1152.0,237.1 L1376.0,302.2 L1408.0,313.7 L1440.0,327.9" /><path d="M0.0,501.2 L112.0,541.7 L152.0,553.6 L184.0,561.0 L248.0,571.1 L374.7,584.0 L424.0,590.9 L472.0,600.9 L584.0,630.0 L632.0,640.6 L780.1,664.0 L896.0,684.8 L920.0,688.1 L952.0,691.0 L992.0,692.6 L1136.0,693.0 L1256.0,700.5 L1304.0,701.4 L1336.0,699.8 L1368.0,695.5 L1408.0,686.1 L1440.0,675.3" /><path d="M0.0,122.0 L40.0,113.0 L80.0,106.4 L232.0,84.8 L296.0,77.4 L336.0,74.6 L376.0,73.8 L416.0,75.7 L448.0,79.9 L480.0,86.3 L512.0,94.7 L648.0,135.9 L822.2,176.0 L864.0,187.4 L920.0,204.9 L960.0,216.1 L1112.0,251.1 L1192.0,272.3 L1301.3,304.0 L1368.0,325.4 L1408.0,341.7 L1440.0,358.9" /><path d="M0.0,476.4 L72.0,503.2 L120.0,519.8 L160.0,531.7 L200.0,540.9 L264.0,551.2 L384.0,564.4 L432.0,571.3 L480.0,581.2 L592.0,610.3 L640.0,620.7 L808.0,645.1 L928.0,664.4 L992.0,669.0 L1136.0,670.5 L1256.0,677.7 L1304.0,678.3 L1344.0,675.2 L1376.0,669.3 L1408.0,659.8 L1440.0,646.3" /><path d="M0.0,151.1 L40.0,139.9 L88.0,130.1 L216.0,108.8 L280.0,100.0 L328.0,95.9 L368.0,94.7 L408.0,96.1 L448.0,101.1 L480.0,107.8 L512.0,116.3 L648.0,158.8 L832.0,204.2 L944.0,237.8 L992.0,249.5 L1120.0,277.1 L1246.3,312.0 L1320.0,335.5 L1368.0,353.7 L1408.0,373.4 L1440.0,394.2" /><path d="M0.0,450.4 L56.0,472.1 L128.0,497.5 L168.0,509.6 L216.0,521.1 L280.0,532.1 L400.0,546.6 L448.0,553.9 L504.0,565.7 L608.0,592.1 L656.0,601.6 L824.0,623.9 L936.0,641.1 L1008.0,646.0 L1136.0,647.5 L1256.0,654.3 L1288.0,654.8 L1312.0,653.9 L1352.0,649.1 L1384.0,640.8 L1416.0,627.5 L1440.0,613.5" /><path d="M0.0,183.4 L40.0,168.9 L88.0,156.4 L200.0,133.9 L264.0,123.4 L320.0,117.4 L368.0,115.6 L408.0,117.0 L448.0,122.1 L472.0,127.0 L504.0,135.4 L640.0,179.7 L816.0,226.0 L936.0,262.3 L984.0,273.7 L1112.0,299.8 L1176.0,316.7 L1241.0,336.0 L1309.2,360.0 L1347.3,376.0 L1376.0,389.9 L1393.4,400.0 L1415.7,416.0 L1425.0,424.0 L1440.0,439.7" /><path d="M0.0,421.4 L63.4,448.0 L136.0,474.4 L192.0,491.7 L242.7,504.0 L304.0,514.8 L416.0,529.2 L464.0,536.7 L520.0,548.0 L616.0,570.9 L656.0,578.7 L712.0,586.7 L832.0,601.0 L912.0,613.4 L944.0,617.4 L1008.0,621.8 L1144.0,623.2 L1256.0,629.2 L1288.0,629.3 L1312.0,627.9 L1336.0,624.8 L1352.0,621.4 L1368.0,616.8 L1384.0,610.5 L1400.0,602.4 L1416.1,592.0 L1426.0,584.0 L1440.0,570.0" /><path d="M0.0,223.5 L16.0,213.9 L40.0,202.4 L64.0,193.3 L88.0,185.6 L184.0,161.3 L248.0,148.1 L304.0,140.2 L360.0,136.7 L408.0,138.0 L432.0,140.6 L456.0,144.8 L488.0,152.4 L520.0,161.9 L648.0,206.5 L823.9,256.0 L920.0,286.1 L968.0,297.7 L1080.0,318.6 L1120.0,327.6 L1192.0,348.2 L1250.3,368.0 L1290.3,384.0 L1325.1,400.0 L1354.5,416.0 L1378.1,432.0 L1395.3,448.0 L1407.5,464.0 L1416.0,481.8 L1419.4,496.0 L1420.0,504.0 L1418.5,520.0 L1412.9,536.0 L1402.9,552.0 L1392.0,563.6 L1376.0,575.9 L1360.0,584.5 L1339.2,592.0 L1320.0,596.4 L1288.0,600.1 L1256.0,600.7 L1152.0,596.1 L1032.0,596.7 L960.0,593.4 L920.0,589.1 L824.0,574.8 L712.0,561.9 L664.0,555.2 L624.0,548.0 L544.0,530.8 L496.0,521.6 L448.0,514.1 L336.0,499.2 L272.0,487.8 L210.0,472.0 L139.4,448.0 L56.0,414.4 L25.6,400.0 L0.0,385.2" /></g></svg>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content" style="display: flex; flex-direction: row; align-items: flex-end; justify-content: space-between; gap: var(--space-16); margin-top: auto;">
      <div style="padding-bottom: var(--space-4);">
        <div class="type-eyebrow" style="color: var(--dark); margin-bottom: var(--space-6);">Kapitel 02</div>
        <h2 class="type-display" style="margin: 0; max-width: 880px;">Eine Zeile, die das Kapitel trägt</h2>
      </div>
      <div class="chapter-num">02</div>
    </div>
  </section>

  <!-- Der Trenner-Katalog, komplett: fünf Farbwelten — mauve,
       sage, teal, rose, sand (die stille Variante für Kapitel
       ohne Farbanspruch). Ein Kapitelthema = eine Farbwelt, die
       das Kapitel dann durchhält. Linienbild je Trenner eigen:
       node deck-topo-konturen.js band-<name> <seed> "#C5C0B8" 0.6
       Muster: Kapitel N = Band-Variante N + Seed Basis+N.
       Nicht gebrauchte Trenner löschen — nie zwei Kapitel in
       derselben Farbwelt. -->
  <section class="dslide dslide-moment" data-label="Kapiteltrenner 03">
    <div class="kasane-layer bg-kasane-band-teal"></div>
    <svg class="kasane-layer" style="z-index: 1; width: 100%; height: 100%;" class="kasane-layer" viewBox="0 0 1440 810" preserveAspectRatio="xMidYMid slice" style="z-index: 1; width: 100%; height: 100%;" aria-hidden="true"><g fill="none" stroke="#C5C0B8" stroke-width="1" opacity="0.6"><path d="M0.0,691.9 L16.0,701.6 L36.8,712.0 L56.0,719.7 L80.0,727.3 L216.0,762.3 L384.0,799.8 L416.0,808.3 L438.1,816.0" /><path d="M885.3,0.0 L920.0,4.1 L952.0,6.4 L1088.0,10.7 L1144.0,16.5 L1176.0,21.8 L1216.0,30.3 L1360.0,67.7 L1440.0,82.4" /><path d="M0.0,609.5 L40.0,637.4 L69.9,656.0 L96.0,669.6 L128.0,683.1 L160.0,694.2 L208.0,708.4 L376.0,750.8 L424.0,764.1 L478.0,784.0 L547.1,816.0" /><path d="M0.0,19.3 L104.0,19.0 L144.0,17.5 L192.0,11.8 L250.3,0.0" /><path d="M673.0,0.0 L824.0,31.3 L896.0,42.7 L952.0,46.8 L1088.0,49.3 L1120.0,52.0 L1152.0,56.7 L1216.0,70.5 L1360.0,110.3 L1440.0,127.5" /><path d="M0.0,554.6 L64.0,598.2 L96.0,618.4 L128.0,635.4 L160.0,649.0 L240.0,674.9 L427.3,728.0 L488.0,749.6 L576.0,785.9 L608.0,798.0 L640.0,807.6 L680.0,816.0" /><path d="M0.0,67.2 L32.0,63.5 L120.0,57.0 L160.0,52.6 L208.0,44.6 L320.0,22.1 L360.0,16.0 L400.0,13.1 L456.0,15.2 L520.0,21.3 L672.0,41.3 L816.0,64.7 L896.0,75.9 L952.0,79.6 L1080.0,81.6 L1112.0,84.1 L1136.0,87.3 L1168.0,93.1 L1208.0,102.5 L1352.0,143.9 L1440.0,166.6" /><path d="M0.0,504.7 L64.0,550.3 L104.0,576.7 L144.0,599.4 L176.0,613.5 L256.0,642.0 L452.8,704.0 L616.0,764.0 L648.0,773.1 L704.0,785.0 L768.0,795.8 L832.0,803.9 L896.0,810.4 L944.0,812.2 L992.0,811.1 L1112.0,803.9 L1152.0,802.6 L1200.0,804.1 L1288.0,809.9 L1328.0,810.0 L1352.0,807.8 L1368.0,804.9 L1400.0,797.1 L1440.0,785.6" /><path d="M0.0,114.8 L48.0,105.0 L160.0,88.2 L288.0,62.2 L336.0,54.0 L368.0,50.3 L392.0,48.7 L448.0,49.6 L504.0,54.4 L688.0,76.7 L896.0,104.4 L952.0,107.9 L1072.0,110.3 L1128.0,115.7 L1176.0,125.0 L1224.0,137.2 L1440.0,202.0" /><path d="M0.0,453.3 L56.0,498.0 L112.0,537.6 L152.0,561.2 L208.0,586.8 L288.0,617.6 L469.3,680.0 L600.0,727.0 L648.0,741.4 L720.0,757.8 L792.0,770.4 L872.0,780.4 L928.0,784.8 L984.0,785.2 L1144.0,778.0 L1264.0,777.8 L1312.0,775.7 L1336.0,772.8 L1360.0,768.1 L1440.0,744.5" /><path d="M0.0,173.9 L27.4,160.0 L64.0,147.9 L280.0,96.2 L328.0,87.4 L368.0,82.4 L400.0,80.5 L440.0,80.8 L512.0,86.3 L616.0,98.3 L712.0,107.8 L904.0,130.4 L952.0,133.2 L1064.0,136.5 L1096.0,138.9 L1128.0,143.0 L1184.0,154.4 L1240.0,169.7 L1392.0,218.3 L1440.0,235.0" /><path d="M0.0,389.7 L15.3,408.0 L38.5,432.0 L64.9,456.0 L96.0,481.3 L127.5,504.0 L152.0,519.5 L208.0,548.3 L264.0,573.1 L336.0,602.1 L424.0,635.3 L560.0,684.4 L632.0,708.3 L720.0,730.7 L760.0,738.9 L808.0,747.2 L896.0,758.2 L960.0,761.6 L1032.0,760.9 L1224.0,752.5 L1288.0,747.3 L1320.0,742.2 L1346.7,736.0 L1440.0,706.5" /><path d="M1440.0,670.7 L1336.0,706.8 L1304.0,715.7 L1272.0,722.4 L1232.0,728.2 L1192.0,732.1 L1056.0,739.4 L1008.0,740.3 L960.0,739.7 L920.0,737.6 L872.0,732.9 L824.0,726.3 L776.0,717.8 L728.0,707.5 L680.0,695.3 L632.0,681.7 L584.0,665.9 L496.0,634.2 L424.0,606.4 L320.0,562.6 L264.0,537.5 L213.3,512.0 L171.4,488.0 L144.0,469.8 L112.0,444.3 L82.5,416.0 L62.0,392.0 L45.9,368.0 L34.4,344.0 L28.9,328.0 L24.7,312.0 L21.8,288.0 L22.4,272.0 L25.6,256.0 L32.0,240.6 L37.3,232.0 L48.0,219.4 L61.2,208.0 L73.3,200.0 L96.0,188.3 L126.6,176.0 L192.0,154.1 L240.0,139.5 L280.0,128.8 L320.0,120.2 L352.0,115.0 L384.0,111.5 L416.0,110.1 L456.0,110.8 L512.0,114.7 L608.0,124.2 L712.0,133.0 L904.0,153.4 L1056.0,160.5 L1088.0,163.1 L1120.0,167.1 L1176.0,178.2 L1248.0,198.2 L1376.0,241.9 L1440.0,267.0" /><path d="M1440.0,635.9 L1326.7,680.0 L1280.0,694.9 L1248.0,702.4 L1216.0,708.0 L1144.0,715.7 L1080.0,719.0 L1024.0,720.2 L976.0,719.6 L928.0,717.1 L880.0,712.4 L832.0,705.6 L784.0,696.8 L736.0,685.8 L680.0,670.7 L616.0,651.0 L552.0,628.5 L488.0,603.9 L422.3,576.0 L334.4,536.0 L285.7,512.0 L242.2,488.0 L204.3,464.0 L171.3,440.0 L152.0,423.7 L128.9,400.0 L110.7,376.0 L97.7,352.0 L89.8,328.0 L87.1,304.0 L88.7,288.0 L93.5,272.0 L102.4,256.0 L108.6,248.0 L120.0,236.8 L136.9,224.0 L152.0,214.9 L181.4,200.0 L218.7,184.0 L248.0,173.1 L288.0,160.5 L320.0,152.3 L352.0,146.0 L384.0,141.6 L408.0,139.8 L440.0,139.0 L504.0,141.3 L688.0,154.4 L896.0,174.2 L1048.0,182.9 L1088.0,186.5 L1120.0,190.9 L1152.0,196.9 L1184.0,204.4 L1224.0,215.6 L1264.0,228.4 L1312.0,245.4 L1376.0,270.1 L1408.0,283.7 L1440.0,299.1" /><path d="M1440.0,600.8 L1392.0,621.3 L1320.0,654.1 L1280.0,669.6 L1256.0,677.1 L1224.0,685.1 L1168.0,694.2 L1128.0,697.9 L1072.0,700.5 L1016.0,701.0 L968.0,699.6 L928.0,696.9 L880.0,691.9 L832.0,684.6 L792.0,676.7 L739.4,664.0 L683.8,648.0 L624.0,628.8 L560.0,605.5 L504.0,582.8 L448.0,557.9 L369.8,520.0 L324.3,496.0 L288.0,474.7 L259.7,456.0 L228.4,432.0 L202.3,408.0 L181.4,384.0 L165.7,360.0 L160.0,347.4 L156.4,336.0 L154.1,320.0 L155.4,304.0 L160.5,288.0 L168.0,275.2 L176.8,264.0 L193.9,248.0 L208.0,237.6 L229.9,224.0 L256.0,210.8 L281.4,200.0 L312.0,189.4 L336.0,182.6 L366.1,176.0 L392.0,172.0 L416.0,169.7 L480.0,168.0 L544.0,170.1 L712.0,178.8 L896.0,194.8 L1048.0,204.7 L1088.0,209.0 L1120.0,213.8 L1152.0,220.0 L1192.0,229.9 L1232.0,242.0 L1280.0,258.7 L1328.0,277.7 L1376.0,298.7 L1408.0,314.4 L1440.0,332.8" /><path d="M1440.0,562.2 L1415.9,576.0 L1323.9,624.0 L1280.0,644.4 L1256.0,653.6 L1232.0,661.2 L1208.0,667.4 L1176.0,673.7 L1144.0,677.8 L1104.0,680.8 L1056.0,682.4 L1008.0,682.0 L968.0,680.3 L920.0,676.4 L872.0,670.6 L832.0,663.9 L784.0,653.5 L733.6,640.0 L680.0,623.2 L613.2,600.0 L552.6,576.0 L504.0,554.7 L449.0,528.0 L403.8,504.0 L361.9,480.0 L324.7,456.0 L293.1,432.0 L275.4,416.0 L253.7,392.0 L237.9,368.0 L230.9,352.0 L228.5,344.0 L226.3,328.0 L227.9,312.0 L233.6,296.0 L243.8,280.0 L259.2,264.0 L280.6,248.0 L304.0,234.8 L328.4,224.0 L360.0,213.5 L384.0,207.5 L408.0,203.3 L440.0,199.6 L472.0,197.5 L544.0,196.2 L672.0,198.7 L744.0,202.8 L1032.0,224.4 L1096.0,232.0 L1152.0,242.5 L1192.0,252.9 L1227.3,264.0 L1271.0,280.0 L1309.3,296.0 L1352.0,316.1 L1389.2,336.0 L1414.7,352.0 L1440.0,371.1" /><path d="M1440.0,500.2 L1432.9,512.0 L1426.7,520.0 L1410.7,536.0 L1379.3,560.0 L1342.3,584.0 L1300.7,608.0 L1268.8,624.0 L1232.0,638.8 L1201.8,648.0 L1168.0,655.4 L1136.0,659.8 L1096.0,662.7 L1056.0,663.8 L1016.0,663.5 L968.0,661.1 L928.0,657.6 L880.0,651.7 L832.0,643.3 L784.0,632.1 L736.0,618.2 L688.0,602.2 L632.0,581.8 L578.2,560.0 L525.7,536.0 L479.4,512.0 L438.1,488.0 L388.8,456.0 L357.5,432.0 L340.0,416.0 L319.2,392.0 L309.0,376.0 L302.1,360.0 L300.0,352.0 L298.3,336.0 L300.6,320.0 L303.4,312.0 L312.7,296.0 L327.9,280.0 L350.9,264.0 L376.0,252.1 L400.0,243.8 L432.0,236.2 L472.0,229.7 L512.0,225.5 L560.0,222.7 L624.0,221.3 L680.0,221.6 L768.0,225.7 L1000.0,242.0 L1080.0,251.2 L1144.0,263.0 L1176.0,271.2 L1208.0,281.0 L1268.3,304.0 L1303.0,320.0 L1333.7,336.0 L1360.9,352.0 L1384.4,368.0 L1403.6,384.0 L1419.0,400.0 L1431.0,416.0 L1440.0,432.5" /></g></svg>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content" style="display: flex; flex-direction: row; align-items: flex-end; justify-content: space-between; gap: var(--space-16); margin-top: auto;">
      <div style="padding-bottom: var(--space-4);">
        <div class="type-eyebrow" style="color: var(--dark); margin-bottom: var(--space-6);">Kapitel 03</div>
        <h2 class="type-display" style="margin: 0; max-width: 880px;">Eine Zeile, die das Kapitel trägt</h2>
      </div>
      <div class="chapter-num">03</div>
    </div>
  </section>

  <section class="dslide dslide-moment" data-label="Kapiteltrenner 04">
    <div class="kasane-layer bg-kasane-band-rose"></div>
    <svg class="kasane-layer" style="z-index: 1; width: 100%; height: 100%;" class="kasane-layer" viewBox="0 0 1440 810" preserveAspectRatio="xMidYMid slice" style="z-index: 1; width: 100%; height: 100%;" aria-hidden="true"><g fill="none" stroke="#C5C0B8" stroke-width="1" opacity="0.6"><path d="M1097.2,816.0 L1115.9,808.0 L1136.0,801.3 L1177.5,792.0 L1224.0,786.9 L1312.0,782.2 L1344.0,777.8 L1368.0,772.0 L1440.0,748.8" /><path d="M0.0,93.2 L112.0,79.4 L176.0,68.8 L224.6,56.0 L336.0,20.8 L368.0,13.0 L400.0,7.2 L424.0,4.2 L456.0,2.1 L584.0,2.2 L637.1,0.0" /><path d="M990.8,816.0 L1045.6,784.0 L1080.0,765.6 L1112.0,750.9 L1144.0,739.5 L1168.0,732.9 L1200.0,726.3 L1304.0,713.1 L1336.0,707.5 L1360.0,701.1 L1440.0,673.9" /><path d="M0.0,138.8 L184.0,109.6 L239.8,96.0 L344.0,66.9 L376.0,59.9 L408.0,54.8 L472.0,48.8 L616.0,40.9 L728.0,32.1 L896.0,23.4 L976.0,21.5 L1048.0,22.5 L1136.0,27.4 L1232.0,34.7 L1288.0,40.8 L1328.0,47.0 L1352.0,51.8 L1440.0,72.9" /><path d="M864.6,816.0 L904.0,806.0 L936.0,793.7 L968.0,778.3 L1072.0,722.8 L1104.0,707.7 L1136.0,694.6 L1168.0,684.3 L1200.0,676.4 L1296.0,659.7 L1336.0,650.7 L1360.0,642.8 L1440.0,609.8" /><path d="M0.0,177.6 L56.0,165.1 L184.0,141.9 L344.0,102.5 L400.0,92.3 L480.0,84.3 L720.0,66.2 L896.0,56.2 L944.0,56.3 L992.0,59.3 L1120.0,75.2 L1232.0,84.4 L1288.0,90.8 L1320.0,96.3 L1352.0,103.9 L1440.0,132.5" /><path d="M618.1,816.0 L720.0,802.9 L792.0,791.5 L848.0,779.6 L904.0,764.0 L928.0,754.8 L960.0,740.2 L1077.0,680.0 L1136.0,653.1 L1160.0,644.1 L1192.0,634.3 L1296.0,610.4 L1336.0,598.4 L1368.0,584.3 L1440.0,544.9" /><path d="M0.0,212.3 L32.0,203.0 L72.0,193.1 L193.8,168.0 L336.0,133.6 L392.0,123.3 L480.0,114.5 L720.0,96.9 L824.0,90.4 L904.0,87.3 L944.0,88.7 L984.0,92.9 L1104.0,112.9 L1232.0,127.5 L1288.0,136.5 L1328.0,146.1 L1360.0,156.9 L1408.0,178.3 L1440.0,196.8" /><path d="M0.0,740.8 L64.0,764.8 L96.0,775.1 L128.0,783.8 L152.0,789.1 L184.0,794.3 L240.0,798.9 L296.0,799.7 L448.0,797.5 L544.0,794.3 L592.0,790.8 L632.0,786.5 L688.0,778.7 L744.0,769.3 L792.0,759.4 L832.0,749.4 L888.0,732.8 L912.0,724.4 L968.0,699.4 L1088.0,637.5 L1144.0,610.8 L1192.0,592.9 L1288.0,564.8 L1328.0,550.1 L1360.0,533.8 L1392.0,512.8 L1416.0,494.5 L1440.0,471.9" /><path d="M0.0,244.6 L48.0,228.5 L104.0,213.6 L200.0,192.1 L320.0,162.9 L360.0,154.7 L392.0,149.6 L496.0,139.8 L728.0,125.1 L856.0,119.2 L896.0,118.3 L920.0,118.9 L952.0,121.5 L984.0,125.9 L1112.0,149.6 L1229.3,168.0 L1280.0,179.4 L1304.0,186.6 L1328.0,195.5 L1354.4,208.0 L1380.4,224.0 L1400.2,240.0 L1414.9,256.0 L1425.3,272.0 L1432.4,288.0 L1436.8,304.0 L1439.1,328.0 L1436.9,352.0 L1431.0,376.0 L1421.5,400.0 L1408.0,423.4 L1392.0,443.9 L1372.0,464.0 L1352.0,480.5 L1329.0,496.0 L1304.0,509.6 L1280.0,520.4 L1184.0,555.9 L1144.0,572.7 L1112.0,588.9 L992.0,653.5 L928.0,684.5 L904.0,694.4 L864.0,708.4 L824.0,721.4 L784.0,732.8 L736.0,744.1 L680.0,754.6 L624.0,762.8 L576.0,767.7 L520.0,771.4 L456.0,773.5 L352.0,774.3 L288.0,773.3 L248.0,771.2 L208.0,767.3 L176.0,762.5 L144.0,755.9 L112.0,747.5 L72.0,734.6 L40.0,722.7 L0.0,706.1" /><path d="M0.0,275.6 L50.2,256.0 L112.0,237.3 L304.0,190.1 L344.0,181.5 L384.0,174.6 L424.0,169.9 L488.0,164.6 L664.0,154.7 L800.0,149.3 L904.0,148.4 L928.0,149.9 L960.0,153.5 L1024.0,165.0 L1200.0,203.1 L1240.0,214.1 L1268.1,224.0 L1288.0,232.6 L1312.0,245.7 L1328.0,256.8 L1344.9,272.0 L1357.7,288.0 L1366.4,304.0 L1371.4,320.0 L1373.1,336.0 L1371.7,352.0 L1367.5,368.0 L1356.7,392.0 L1346.5,408.0 L1333.6,424.0 L1317.6,440.0 L1297.9,456.0 L1273.7,472.0 L1240.0,490.2 L1136.0,539.7 L1000.0,617.0 L960.0,638.1 L928.0,653.4 L896.0,666.9 L824.0,693.3 L776.0,708.8 L736.0,719.5 L688.0,729.9 L640.0,738.0 L592.0,743.9 L544.0,747.9 L480.0,751.0 L408.0,752.2 L344.0,751.5 L296.0,749.4 L256.0,746.1 L216.0,740.9 L176.0,733.7 L144.0,726.4 L112.0,717.2 L72.0,703.5 L33.4,688.0 L0.0,672.8" /><path d="M0.0,306.7 L32.0,291.3 L59.4,280.0 L96.0,267.1 L128.0,257.4 L296.0,214.1 L344.0,203.6 L384.0,196.8 L424.0,192.3 L480.0,187.7 L616.0,180.5 L768.0,176.1 L888.0,176.6 L912.0,177.9 L944.0,181.3 L1008.0,193.3 L1066.3,208.0 L1136.0,227.6 L1168.0,237.5 L1197.0,248.0 L1232.0,264.5 L1248.0,274.5 L1265.0,288.0 L1272.8,296.0 L1284.1,312.0 L1290.5,328.0 L1292.7,344.0 L1292.3,352.0 L1288.8,368.0 L1282.2,384.0 L1277.7,392.0 L1259.1,416.0 L1242.2,432.0 L1221.7,448.0 L1197.8,464.0 L1041.5,560.0 L968.0,603.0 L936.0,619.6 L904.0,634.4 L792.0,678.5 L752.0,691.6 L704.0,704.3 L664.0,712.5 L616.0,720.0 L568.0,725.2 L520.0,728.7 L464.0,730.9 L400.0,731.6 L352.0,730.5 L304.0,727.4 L264.0,722.9 L224.0,716.5 L184.0,708.2 L144.0,698.3 L104.0,685.6 L72.0,673.5 L32.0,656.0 L0.0,639.8" /><path d="M0.0,339.1 L24.0,325.0 L56.0,309.0 L86.7,296.0 L120.0,284.0 L159.6,272.0 L272.0,241.4 L320.0,229.8 L360.0,221.8 L392.0,216.9 L424.0,213.5 L528.0,206.2 L656.0,201.8 L776.0,201.1 L872.0,203.9 L904.0,206.0 L928.0,208.9 L960.0,214.4 L992.0,221.7 L1056.0,240.9 L1096.6,256.0 L1133.1,272.0 L1152.0,282.0 L1173.3,296.0 L1184.0,305.1 L1197.0,320.0 L1205.3,336.0 L1208.6,352.0 L1207.2,368.0 L1201.7,384.0 L1192.4,400.0 L1171.9,424.0 L1145.2,448.0 L1104.5,480.0 L1049.0,520.0 L1000.7,552.0 L960.0,576.5 L920.0,597.8 L816.0,644.0 L776.0,659.9 L744.0,671.0 L712.0,680.4 L672.0,690.0 L632.0,697.3 L592.0,702.7 L544.0,707.3 L496.0,710.1 L440.0,711.7 L384.0,711.6 L344.0,709.7 L304.0,705.8 L264.0,699.9 L224.0,691.9 L168.0,677.9 L136.0,668.4 L101.2,656.0 L64.0,640.2 L31.5,624.0 L0.0,605.5" /><path d="M0.0,375.8 L20.5,360.0 L48.0,342.6 L75.6,328.0 L112.0,312.0 L152.0,297.7 L210.3,280.0 L266.0,264.0 L312.0,252.3 L376.0,239.6 L440.0,232.6 L536.0,226.7 L648.0,224.2 L760.0,225.4 L856.0,230.5 L896.0,234.4 L920.0,238.0 L944.0,242.8 L976.0,251.2 L1013.5,264.0 L1040.0,275.3 L1065.0,288.0 L1089.8,304.0 L1108.1,320.0 L1120.4,336.0 L1127.3,352.0 L1129.1,368.0 L1126.3,384.0 L1123.4,392.0 L1115.0,408.0 L1103.7,424.0 L1082.5,448.0 L1057.2,472.0 L1028.4,496.0 L996.5,520.0 L960.8,544.0 L934.2,560.0 L904.0,576.2 L820.8,616.0 L776.0,635.8 L744.0,648.2 L712.0,658.7 L680.0,667.4 L640.0,675.8 L600.0,681.9 L552.0,687.2 L504.0,690.5 L456.0,692.2 L400.0,692.7 L368.0,691.5 L328.2,688.0 L296.0,683.5 L256.0,675.6 L216.0,665.6 L160.0,649.2 L120.0,635.1 L80.0,617.6 L48.0,600.6 L21.7,584.0 L0.0,567.2" /><path d="M0.0,433.6 L4.9,424.0 L16.0,407.9 L30.5,392.0 L49.1,376.0 L72.4,360.0 L96.0,346.7 L120.0,335.1 L152.0,322.0 L256.0,288.0 L296.0,276.8 L336.0,267.3 L368.0,261.1 L400.0,256.5 L488.0,249.4 L544.0,247.0 L608.0,245.9 L672.0,246.5 L728.0,248.4 L784.0,251.7 L832.0,256.2 L880.0,262.6 L912.0,268.7 L944.0,277.6 L971.9,288.0 L992.0,297.5 L1016.3,312.0 L1035.8,328.0 L1049.0,344.0 L1056.7,360.0 L1059.3,376.0 L1057.6,392.0 L1052.2,408.0 L1043.7,424.0 L1026.0,448.0 L1003.4,472.0 L976.2,496.0 L944.3,520.0 L919.8,536.0 L891.8,552.0 L808.0,595.8 L768.0,614.9 L736.0,628.2 L702.1,640.0 L664.0,650.5 L624.0,658.5 L584.0,664.4 L544.0,668.6 L496.0,671.8 L440.0,673.5 L392.0,673.4 L360.0,671.5 L328.0,667.7 L296.0,662.2 L256.0,652.9 L212.2,640.0 L152.0,619.6 L112.0,602.8 L80.0,586.1 L52.2,568.0 L32.0,551.1 L11.6,528.0 L0.0,508.0" /></g></svg>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content" style="display: flex; flex-direction: row; align-items: flex-end; justify-content: space-between; gap: var(--space-16); margin-top: auto;">
      <div style="padding-bottom: var(--space-4);">
        <div class="type-eyebrow" style="color: var(--dark); margin-bottom: var(--space-6);">Kapitel 04</div>
        <h2 class="type-display" style="margin: 0; max-width: 880px;">Eine Zeile, die das Kapitel trägt</h2>
      </div>
      <div class="chapter-num">04</div>
    </div>
  </section>

  <section class="dslide dslide-moment" data-label="Kapiteltrenner 05">
    <div class="kasane-layer bg-kasane-band-sand"></div>
    <svg class="kasane-layer" style="z-index: 1; width: 100%; height: 100%;" class="kasane-layer" viewBox="0 0 1440 810" preserveAspectRatio="xMidYMid slice" style="z-index: 1; width: 100%; height: 100%;" aria-hidden="true"><g fill="none" stroke="#C5C0B8" stroke-width="1" opacity="0.6"><path d="M0.0,48.3 L80.0,52.2 L104.0,50.9 L128.0,47.1 L151.8,40.0 L168.0,33.2 L231.1,0.0" /><path d="M1378.9,816.0 L1392.0,811.3 L1408.0,803.4 L1440.0,782.8" /><path d="M930.9,816.0 L1056.0,801.4 L1136.0,789.7 L1160.0,788.0 L1184.0,788.8 L1216.0,793.2 L1247.3,800.0 L1309.9,816.0" /><path d="M0.0,134.1 L88.0,126.7 L120.0,120.7 L144.0,113.5 L168.0,103.4 L214.4,80.0 L365.3,0.0" /><path d="M726.4,816.0 L816.0,785.1 L848.0,776.7 L880.0,770.5 L1040.0,749.7 L1136.0,734.8 L1160.0,732.3 L1208.0,732.1 L1312.0,739.6 L1336.0,739.2 L1352.0,737.8 L1376.0,733.1 L1392.0,728.0 L1416.0,717.8 L1440.0,705.0" /><path d="M0.0,761.7 L40.0,779.2 L88.0,796.0 L128.0,806.4 L176.0,814.2 L208.0,815.7 L240.0,814.6 L360.0,802.8 L416.0,800.6 L440.0,802.0 L464.0,805.0 L518.0,816.0" /><path d="M0.0,206.7 L32.0,197.2 L104.0,178.7 L144.0,165.5 L191.2,144.0 L336.0,70.6 L400.0,40.3 L432.0,27.2 L456.0,18.8 L522.1,0.0" /><path d="M0.0,698.3 L40.0,722.5 L64.0,734.3 L87.5,744.0 L128.0,756.8 L152.0,762.2 L176.0,766.0 L208.0,768.5 L240.0,768.8 L368.0,761.7 L424.0,761.2 L480.0,765.8 L584.0,780.0 L608.0,781.9 L632.0,782.1 L656.0,780.1 L688.0,774.4 L792.0,748.0 L848.8,736.0 L1040.0,709.9 L1144.0,693.3 L1168.0,690.9 L1200.0,689.6 L1304.0,690.2 L1328.0,688.8 L1352.0,685.8 L1368.0,682.5 L1392.0,675.2 L1416.0,665.1 L1440.0,652.8" /><path d="M0.0,272.6 L24.0,259.9 L48.0,248.8 L128.0,216.6 L160.0,202.4 L344.0,110.0 L424.0,73.7 L464.0,58.7 L512.0,43.4 L679.8,0.0" /><path d="M0.0,633.3 L16.0,648.5 L40.0,668.0 L57.4,680.0 L80.0,693.1 L96.0,701.0 L120.0,710.7 L144.0,718.1 L168.0,723.4 L200.0,727.7 L240.0,729.7 L280.0,729.4 L368.0,726.6 L416.0,726.7 L464.0,729.0 L568.0,736.4 L616.0,737.5 L648.0,735.7 L680.0,731.8 L832.0,705.2 L1008.0,682.1 L1152.0,659.2 L1200.0,655.3 L1296.0,652.2 L1336.0,648.1 L1360.0,643.5 L1384.0,636.5 L1408.0,627.0 L1440.0,610.7" /><path d="M0.0,343.1 L17.9,328.0 L39.3,312.0 L63.8,296.0 L91.4,280.0 L192.0,226.7 L344.0,148.2 L416.0,113.6 L464.0,94.5 L520.0,75.6 L576.0,59.3 L664.0,35.8 L744.0,11.7 L787.2,0.0" /><path d="M1072.1,0.0 L1120.0,6.4 L1152.0,9.2 L1280.0,12.4 L1328.0,16.9 L1352.0,21.5 L1376.0,28.4 L1408.0,39.9 L1440.0,53.9" /><path d="M0.0,551.7 L16.2,576.0 L34.0,600.0 L56.0,623.7 L72.0,637.6 L88.0,649.4 L112.9,664.0 L136.0,674.2 L160.0,682.0 L200.0,689.6 L248.0,693.6 L392.0,694.2 L552.0,700.0 L624.0,699.2 L688.0,693.9 L976.0,658.5 L1056.0,646.6 L1160.0,629.4 L1200.0,625.7 L1280.0,620.8 L1320.0,616.5 L1352.0,610.5 L1384.0,600.8 L1408.0,590.6 L1440.0,573.2" /><path d="M1440.0,536.0 L1408.0,555.6 L1384.0,567.4 L1360.0,576.3 L1328.0,584.5 L1280.0,591.8 L1160.0,603.4 L1016.0,627.4 L952.0,636.2 L888.0,643.6 L696.0,661.5 L584.0,667.2 L480.0,667.2 L264.0,658.6 L232.0,655.8 L208.0,652.4 L168.0,643.1 L152.0,637.3 L136.0,629.7 L120.0,620.0 L104.0,607.9 L87.5,592.0 L72.0,573.0 L57.9,552.0 L44.9,528.0 L34.7,504.0 L29.6,488.0 L24.9,464.0 L24.0,448.0 L26.9,424.0 L36.0,400.0 L45.8,384.0 L66.1,360.0 L92.0,336.0 L123.2,312.0 L171.1,280.0 L212.1,256.0 L390.7,160.0 L424.0,143.6 L464.0,126.5 L504.0,111.8 L552.0,96.1 L664.0,63.9 L752.0,36.3 L792.0,25.1 L840.0,14.7 L888.0,8.7 L928.0,7.8 L976.0,11.0 L1128.0,32.0 L1168.0,35.4 L1272.0,41.0 L1320.0,46.8 L1352.0,53.9 L1376.0,61.6 L1408.0,74.5 L1440.0,90.0" /><path d="M1440.0,497.6 L1408.0,519.7 L1378.5,536.0 L1352.0,547.0 L1320.0,556.5 L1272.0,565.5 L1152.0,580.5 L1072.0,594.9 L1008.0,605.1 L896.0,619.0 L760.0,629.8 L680.0,633.9 L592.0,636.7 L528.0,637.9 L480.0,637.4 L424.0,634.5 L264.0,620.9 L240.0,617.3 L216.0,612.3 L200.0,607.9 L176.0,599.0 L160.0,590.9 L139.7,576.0 L124.2,560.0 L112.6,544.0 L103.6,528.0 L94.4,504.0 L89.6,480.0 L88.9,464.0 L92.1,440.0 L100.7,416.0 L114.9,392.0 L133.8,368.0 L155.9,344.0 L182.9,320.0 L208.0,302.1 L243.9,280.0 L410.4,184.0 L441.3,168.0 L480.0,150.6 L520.0,135.1 L564.2,120.0 L669.9,88.0 L760.0,58.6 L800.0,47.2 L840.0,38.4 L872.0,33.6 L904.0,31.2 L944.0,31.6 L1000.0,36.7 L1136.0,56.2 L1272.0,68.0 L1320.0,75.7 L1360.0,86.8 L1400.0,103.4 L1440.0,124.8" /><path d="M1440.0,455.7 L1420.6,472.0 L1398.9,488.0 L1376.0,502.4 L1360.0,510.7 L1338.7,520.0 L1320.0,526.6 L1272.0,538.9 L1152.0,558.1 L1040.0,578.1 L944.0,591.3 L880.0,597.9 L816.0,602.5 L744.0,605.9 L672.0,607.6 L528.0,608.6 L456.0,605.8 L424.0,602.6 L328.0,588.7 L296.0,583.4 L262.6,576.0 L237.0,568.0 L218.1,560.0 L200.0,549.6 L183.0,536.0 L169.8,520.0 L161.6,504.0 L157.0,488.0 L155.4,472.0 L158.0,448.0 L162.7,432.0 L169.5,416.0 L178.4,400.0 L189.4,384.0 L202.5,368.0 L217.6,352.0 L235.6,336.0 L268.2,312.0 L415.6,216.0 L443.0,200.0 L473.7,184.0 L508.9,168.0 L544.0,154.0 L592.0,137.1 L672.0,111.7 L760.0,81.9 L816.0,66.0 L856.0,58.0 L888.0,54.1 L920.0,52.9 L952.0,53.9 L1008.0,59.5 L1136.0,78.7 L1272.0,94.0 L1320.0,103.6 L1360.0,116.4 L1384.0,127.3 L1400.4,136.0 L1424.0,150.8 L1440.0,162.5" /><path d="M1440.0,404.5 L1422.9,424.0 L1406.5,440.0 L1387.5,456.0 L1365.0,472.0 L1344.0,484.3 L1320.0,495.8 L1296.0,504.9 L1272.9,512.0 L1216.0,524.9 L1080.0,550.5 L1016.0,561.0 L912.0,573.5 L808.0,580.5 L696.0,582.6 L552.0,580.0 L480.0,575.6 L448.0,571.5 L424.0,567.2 L337.1,544.0 L304.0,531.9 L280.1,520.0 L268.2,512.0 L258.9,504.0 L248.0,490.9 L242.0,480.0 L239.3,472.0 L237.1,456.0 L237.5,448.0 L240.7,432.0 L251.1,408.0 L267.3,384.0 L288.1,360.0 L312.9,336.0 L361.3,296.0 L412.9,256.0 L456.0,226.8 L488.5,208.0 L520.0,192.3 L584.0,165.6 L768.0,101.8 L808.0,89.9 L840.0,82.3 L872.0,77.0 L904.0,74.3 L936.0,74.2 L968.0,76.0 L1016.0,81.6 L1128.0,99.7 L1232.0,113.2 L1280.0,121.3 L1304.0,126.9 L1328.0,134.1 L1352.0,143.6 L1368.0,151.7 L1384.0,161.2 L1405.1,176.0 L1423.8,192.0 L1440.0,208.8" /></g></svg>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content" style="display: flex; flex-direction: row; align-items: flex-end; justify-content: space-between; gap: var(--space-16); margin-top: auto;">
      <div style="padding-bottom: var(--space-4);">
        <div class="type-eyebrow" style="color: var(--dark); margin-bottom: var(--space-6);">Kapitel 05</div>
        <h2 class="type-display" style="margin: 0; max-width: 880px;">Eine Zeile, die das Kapitel trägt</h2>
      </div>
      <div class="chapter-num">05</div>
    </div>
  </section>

  <!-- ========================================================
       LAYOUT „HAIRLINE-KOLUMNEN" — DAS Standard-Layout für
       gleichrangige Punkte (3–4 Spalten). Keine Karten: Hairline
       eröffnet die Spalte, Index + Titel, gestapelte Kurzabsätze
       (Abstand trennt). Optional darunter das RESULTAT-BAND für
       „und die Summe ist" — bewusst anders exponiert.
       ======================================================== -->
  <section class="dslide" data-label="Hairline-Kolumnen">
    <header class="slide-head"><span class="type-eyebrow">01 / Kapitel</span></header>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content">
      <h2 class="type-h1 deck-title" style="max-width: 980px;">Aussage der Slide als ganzer Satz</h2>
      <div class="deck-body">
        <div class="hl-cols hl-cols-3">
          <div class="hl-col">
            <div class="hl-index"><span class="type-small">01</span><span class="msym" style="font-size: 18px;">arrow_forward</span></div>
            <h3 class="type-h4 hl-title">Erster Punkt</h3>
            <p class="type-body">Zwei bis drei Sätze, die den Punkt tragen: als Fließtext, nicht als Halbzeilen.</p>
            <p class="type-body">Weiterer Absatz nur, wenn er etwas Neues sagt.</p>
          </div>
          <div class="hl-col">
            <div class="hl-index"><span class="type-small">02</span><span class="msym" style="font-size: 18px;">arrow_forward</span></div>
            <h3 class="type-h4 hl-title">Zweiter Punkt</h3>
            <p class="type-body">Zwei bis drei Sätze, die den Punkt tragen.</p>
          </div>
          <div class="hl-col">
            <div class="hl-index"><span class="type-small">03</span><span class="msym" style="font-size: 18px;">arrow_forward</span></div>
            <h3 class="type-h4 hl-title">Dritter Punkt</h3>
            <p class="type-body">Zwei bis drei Sätze, die den Punkt tragen.</p>
          </div>
        </div>
        <div class="result-band">
          <span class="type-eyebrow">Das Ergebnis</span>
          <span class="type-body">Der Satz, der aus den drei Punkten folgt</span>
        </div>
      </div>
    </div>
  </section>

  <!-- ========================================================
       LAYOUT „CONTENT 2/3 + 1/3 MIT INFOGRAFIK" — Text links,
       GEBAUTE Grafik rechts (§7.11): eine Farbfamilie als
       Datenreihe, Direktbeschriftung, eine Baseline, keine
       Gitter, Beschriftung Inter. Das SVG hier ist das
       Grundmuster — an die echten Daten anpassen.
       Der gestreifte Platzhalter ist NUR noch für Bild-Assets
       erlaubt (CSS .placeholder-frame bleibt dafür erhalten).
       ======================================================== -->
  <section class="dslide" data-label="Content-Infografik">
    <header class="slide-head"><span class="type-eyebrow">01 / Kapitel</span></header>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content">
      <h2 class="type-h1 deck-title" style="max-width: 800px;">Aussage der Slide als ganzer Satz</h2>
      <div class="deck-body">
        <div class="split-23">
          <div>
            <p class="type-body-l deck-lead" style="margin: 0;">
              Lead-Absatz: die eine Botschaft dieser Slide, in zwei bis drei Sätzen.
              Aktive Verben, belastbare Zahlen oder keine.
            </p>
            <div class="meta-rows" style="margin-top: var(--space-10); max-width: 560px;">
              <div class="meta-row"><span class="type-body">Erste Messgröße</span><span class="type-body value">Wert</span></div>
              <div class="meta-row"><span class="type-body">Zweite Messgröße</span><span class="type-body value">Wert</span></div>
              <div class="meta-row"><span class="type-body">Dritte Messgröße</span><span class="type-body value">Wert</span></div>
            </div>
          </div>
          <!-- Konstruktion (§7.11): schlanke Balken (Breite 36),
               scharfkantig, Mitten äquidistant 45/165/285;
               Höhen PROPORTIONAL zu den Werten (12/18/27 →
               98/147/220 bei Skala 27 ≙ 220) — die Geometrie
               lügt nie über die Daten; Werte mittig über dem
               Balken; EINE Farbe (Abstufung nur mit benannter
               Bedeutung); 4px Lücke zwischen Balken und Baseline. -->
          <svg viewBox="0 0 330 300" preserveAspectRatio="xMinYMin meet" style="width: 100%;" role="img" aria-label="Beispiel-Infografik: drei Werte im Vergleich">
            <text x="0" y="18" class="chart-label" style="fill: var(--charcoal);">Direktes Label der Reihe</text>
            <rect x="27"  y="158" width="36" height="98"  style="fill: var(--bm-teal);" />
            <rect x="147" y="109" width="36" height="147" style="fill: var(--bm-teal);" />
            <rect x="267" y="36"  width="36" height="220" style="fill: var(--bm-teal);" />
            <text x="45"  y="143" text-anchor="middle" class="chart-label" style="fill: var(--bm-deep-teal, #2A7E78);">12</text>
            <text x="165" y="94"  text-anchor="middle" class="chart-label" style="fill: var(--bm-deep-teal, #2A7E78);">18</text>
            <text x="285" y="21"  text-anchor="middle" class="chart-label" style="fill: var(--bm-deep-teal, #2A7E78);">27</text>
            <line x1="0" y1="260" x2="330" y2="260" stroke="#C5C0B8" stroke-width="1" />
            <text x="45"  y="282" text-anchor="middle" class="chart-label-soft">2024</text>
            <text x="165" y="282" text-anchor="middle" class="chart-label-soft">2025</text>
            <text x="285" y="282" text-anchor="middle" class="chart-label-soft">2026</text>
          </svg>
        </div>
      </div>
    </div>
  </section>


  <!-- ========================================================
       LAYOUT „CONTENT MIT DEVICE-MOCKUP" — wenn ein Produkt/
       System gezeigt wird: Bausteine links als Bold-Lead-Absätze
       in einer Hairline-Spalte, rechts das konstruierte
       MacBook-Schema (freigestellt, Stone-Neutrals). Der Screen
       zeigt den neutralen Default (Kasane + Wortmarke); im
       echten Deck ersetzt das freigegebene Produkt-Visual NUR
       die Screen-Fläche — Rahmen und Basis bleiben. BU zentriert
       im Meta-Register. Quelle: examples/beispiel-kundendeck.html.
       ======================================================== -->
  <section class="dslide" data-label="Device-Mockup">
    <header class="slide-head"><span class="type-eyebrow">01 / Kapitel</span></header>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content">
      <h2 class="type-h1 deck-title" style="max-width: 980px;">Aussage der Slide als ganzer Satz</h2>
      <div class="deck-body">
        <div style="display: grid; grid-template-columns: 2fr 3fr; column-gap: var(--space-16); align-items: center;">
          <div class="hl-col">
            <div class="hl-index"><span class="type-eyebrow" style="color: var(--mid);">Vier Bausteine</span></div>
            <p class="type-body"><strong>Erster Baustein.</strong> Halber Satz, was er leistet.</p>
            <p class="type-body"><strong>Zweiter Baustein.</strong> Halber Satz, was er leistet.</p>
            <p class="type-body"><strong>Dritter Baustein.</strong> Halber Satz, was er leistet.</p>
            <p class="type-body"><strong>Vierter Baustein.</strong> Halber Satz, was er leistet.</p>
          </div>
          <div>
            <div style="width: 86%; margin: 0 auto;">
              <div style="background: var(--charcoal); border-radius: 16px 16px 0 0; padding: 12px 12px 16px;">
                <div style="aspect-ratio: 16 / 10; border-radius: 6px; overflow: hidden; position: relative; background: var(--charcoal);">
                  <div class="bg-kasane-cta" style="position: absolute; inset: 0;"></div>
                  <img src="data:," data-wm="w" alt="Bridgemaker" style="position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%); height: 18px; width: auto; opacity: 0.9;" />
                </div>
              </div>
              <div style="position: relative; margin: 0 -5.5%; height: 14px; background: linear-gradient(180deg, var(--surface-stone), var(--surface-mid-stone)); border-radius: 0 0 12px 12px;">
                <div style="position: absolute; left: 50%; top: 0; transform: translateX(-50%); width: 17%; height: 5px; background: var(--surface-mid-stone); border-radius: 0 0 6px 6px;"></div>
              </div>
            </div>
            <p class="source-note" style="margin: var(--space-4) 0 0; text-align: center;">Bildunterschrift mit Inhalt, nicht mit Meta</p>
          </div>
        </div>
      </div>
    </div>
  </section>
  <!-- ========================================================
       LAYOUT „ZAHLEN" — freie Stats zwischen vertikalen
       Hairlines. KEINE KPI-Kacheln. Ziffern groß, in Inter,
       Charcoal; Caps-Label; ein Erklärsatz. Quelle als Zeile.
       ======================================================== -->
  <section class="dslide" data-label="Zahlen">
    <header class="slide-head"><span class="type-eyebrow">01 / Kapitel</span></header>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content">
      <h2 class="type-h1 deck-title">Die drei Zahlen, die zählen</h2>
      <div class="deck-body">
        <div class="stat-strip">
          <div class="stat-cell">
            <div class="type-display num">27,3 Mio. €</div>
            <div class="type-eyebrow label">Kennzahl A</div>
            <p class="type-body">Ein Satz, der die Zahl einordnet.</p>
          </div>
          <div class="stat-cell">
            <div class="type-display num">+8,2 %</div>
            <div class="type-eyebrow label">Kennzahl B</div>
            <p class="type-body">Ein Satz, der die Zahl einordnet.</p>
          </div>
          <div class="stat-cell">
            <div class="type-display num">56 %</div>
            <div class="type-eyebrow label">Kennzahl C</div>
            <p class="type-body">Ein Satz, der die Zahl einordnet.</p>
          </div>
        </div>
        <p class="source-note" style="margin: var(--space-12) 0 0;">Quelle: … in einem Satz</p>
      </div>
    </div>
  </section>

  <!-- ========================================================
       LAYOUT „PRINCIPLE-ZEILEN" — Aspekte/Werte mit Icon:
       Hairline oben, Titel links, Icon rechtsbündig auf der
       Zeile, Copy darunter. 2×2 oder 2×3. Ersetzt Icon-Karten.
       ======================================================== -->
  <section class="dslide" data-label="Principle-Zeilen">
    <header class="slide-head"><span class="type-eyebrow">01 / Kapitel</span></header>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content">
      <h2 class="type-h1 deck-title">Vier Aspekte, ein System</h2>
      <div class="deck-body">
        <div class="principle-grid">
          <div class="principle">
            <div class="p-head"><span class="type-h4">Erster Aspekt</span><span class="msym">insights</span></div>
            <p class="type-body">Ein bis zwei Sätze, was das konkret heißt.</p>
          </div>
          <div class="principle">
            <div class="p-head"><span class="type-h4">Zweiter Aspekt</span><span class="msym">hub</span></div>
            <p class="type-body">Ein bis zwei Sätze, was das konkret heißt.</p>
          </div>
          <div class="principle">
            <div class="p-head"><span class="type-h4">Dritter Aspekt</span><span class="msym">query_stats</span></div>
            <p class="type-body">Ein bis zwei Sätze, was das konkret heißt.</p>
          </div>
          <div class="principle">
            <div class="p-head"><span class="type-h4">Vierter Aspekt</span><span class="msym">rocket_launch</span></div>
            <p class="type-body">Ein bis zwei Sätze, was das konkret heißt.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ========================================================
       LAYOUT „GEGENÜBERSTELLUNG" — Kontrast als zwei OFFENE
       Hairline-Spalten (keine Karten). Bedeutung darf ein Icon
       tragen (z. B. Stärke/Engpass) — übers Symbol, nicht über
       Farbe: Icons laufen einfarbig Charcoal.
       ======================================================== -->
  <section class="dslide" data-label="Gegenüberstellung">
    <header class="slide-head"><span class="type-eyebrow">01 / Kapitel</span></header>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content">
      <h2 class="type-h1 deck-title" style="max-width: 980px;">Zwei Seiten derselben Sache</h2>
      <div class="deck-body">
        <div class="hl-cols hl-cols-2">
          <div class="hl-col">
            <div class="hl-index"><span class="type-eyebrow" style="color: var(--mid);">Blickwinkel A</span><span class="msym" style="font-size: 20px; color: var(--charcoal);">verified</span></div>
            <p class="type-body">Erster Punkt als ganzer Satz.</p>
            <p class="type-body">Zweiter Punkt als ganzer Satz.</p>
            <p class="type-body">Dritter Punkt als ganzer Satz.</p>
          </div>
          <div class="hl-col">
            <div class="hl-index"><span class="type-eyebrow" style="color: var(--mid);">Blickwinkel B</span><span class="msym" style="font-size: 20px; color: var(--charcoal);">pending</span></div>
            <p class="type-body">Erster Punkt als ganzer Satz.</p>
            <p class="type-body">Zweiter Punkt als ganzer Satz.</p>
            <p class="type-body">Dritter Punkt als ganzer Satz.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ========================================================
       LAYOUT „OBJEKT-KARTEN" — die legitime Karten-Slide:
       BENANNTE DINGE (Produkte, Angebote, Cases). Jede Karte
       trägt Identität: Statement + Name. Standard: alle Karten
       WEISS (card-clean — reduziert, die Karte sitzt über die
       Haarlinie). Tönung nur, wenn sie etwas sagt: uniform oder
       eine je Identität (wie die Tautiom-Karten der Website) —
       nie zufällig gemischt, nie Schachbrett.
       ======================================================== -->
  <section class="dslide" data-label="Objekt-Karten">
    <header class="slide-head"><span class="type-eyebrow">01 / Kapitel</span></header>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content">
      <h2 class="type-h1 deck-title">Vier Werkzeuge, ein System</h2>
      <div class="deck-body">
        <div class="object-grid">
          <div class="object-card card-clean" style="background: var(--white);">
            <div class="type-h3" style="max-width: 400px;">Statement des ersten Dings in einer Zeile.</div>
            <div class="o-name type-small">Produktname A</div>
          </div>
          <div class="object-card card-clean" style="background: var(--white);">
            <div class="type-h3" style="max-width: 400px;">Statement des zweiten Dings in einer Zeile.</div>
            <div class="o-name type-small">Produktname B</div>
          </div>
          <div class="object-card card-clean" style="background: var(--white);">
            <div class="type-h3" style="max-width: 400px;">Statement des dritten Dings in einer Zeile.</div>
            <div class="o-name type-small">Produktname C</div>
          </div>
          <div class="object-card card-clean" style="background: var(--white);">
            <div class="type-h3" style="max-width: 400px;">Statement des vierten Dings in einer Zeile.</div>
            <div class="o-name type-small">Produktname D</div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ========================================================
       LAYOUT „NUMMERIERTE OBJEKT-KARTEN" — für ZÄHLBARE
       Handlungsaufträge (Risiken, Handlungsfelder, Hebel).
       Musterpaar: Hairline-Kolumnen = Beobachtungen, nummerierte
       Karten = zählbare Handlungsaufträge. Display-Ziffer light,
       Surface-Farbcode EINE je Identität (mauve/sage/sand/stone),
       Ziffer im Familien-Deep-Ton (Neutrals: Charcoal). Sand und
       Stone sind HIER erlaubt: die card-clean-Anatomie (Inset-
       Haarlinie) trennt sie vom Off-White-Grund. Karten aber nur,
       wenn die Punkte eine Bühne verdienen — ruhige zählbare
       Punkte (offene Fragen, Klärungen) laufen als nummerierte
       Hairline-Zeilen in Agenda-Anatomie (Nils, 2026-07-23).
       ======================================================== -->
  <section class="dslide" data-label="Nummerierte Objekt-Karten">
    <header class="slide-head"><span class="type-eyebrow">01 / Kapitel</span></header>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content">
      <h2 class="type-h1 deck-title" style="max-width: 1000px;">Vier Punkte, die jetzt aktiv gesteuert werden müssen</h2>
      <div class="deck-body">
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: var(--space-6);">
          <div class="card-clean num-card" style="background: var(--surface-mauve);">
            <div class="type-display o-num" style="color: var(--bm-deep-plum);">1</div>
            <h3 class="type-h4">Erster Punkt als ganzer Satz</h3>
            <p class="type-small">Zwei bis drei Sätze, die den Punkt tragen und belegen.</p>
            <p class="type-small" style="color: var(--mid);">Indikator oder Beleg in einem Satz.</p>
          </div>
          <div class="card-clean num-card" style="background: var(--surface-sage);">
            <div class="type-display o-num" style="color: var(--bm-deep-teal, #2A7E78);">2</div>
            <h3 class="type-h4">Zweiter Punkt als ganzer Satz</h3>
            <p class="type-small">Zwei bis drei Sätze, die den Punkt tragen.</p>
            <p class="type-small" style="font-style: italic;">„Wörtliches Zitat als Beleg." — Rolle, Kontext</p>
          </div>
          <div class="card-clean num-card" style="background: var(--surface-sand);">
            <div class="type-display o-num" style="color: var(--charcoal);">3</div>
            <h3 class="type-h4">Dritter Punkt als ganzer Satz</h3>
            <p class="type-small">Zwei bis drei Sätze, die den Punkt tragen.</p>
          </div>
          <div class="card-clean num-card" style="background: var(--surface-stone);">
            <div class="type-display o-num" style="color: var(--charcoal);">4</div>
            <h3 class="type-h4">Vierter Punkt als ganzer Satz</h3>
            <p class="type-small">Zwei bis drei Sätze, die den Punkt tragen.</p>
          </div>
        </div>
        <p class="source-note" style="margin: var(--space-10) 0 0;">Quellen: … in einem Satz</p>
      </div>
    </div>
  </section>

  <!-- ========================================================
       LAYOUT „TABELLE" — für KPIs, Vergleiche, Roadmap-Stände.
       Offene Hairline-Zeilen, kein Rahmen, keine Zebra-Streifen.
       Zielwerte in Deep-Plum (Werte-Spalte statt Chips).
       Max. 8 Zeilen pro Slide — sonst auf zwei Slides teilen.
       SERIE über mehrere Slides (Nils, 2026-07-24): EINE
       konstante, einzeilige Headline auf jeder Seite der Serie
       (kein „Fortsetzung"-Wechsel), identische th-Breiten auf
       allen Seiten (bemessen am breitesten Inhalt der Serie)
       und der .deck-body auf justify-content: flex-start —
       beim Blättern stehen Headline, Tabellen-Oberkante und
       Spaltenraster. deck-lint prüft alle drei.
       ======================================================== -->
  <section class="dslide" data-label="Tabelle">
    <header class="slide-head"><span class="type-eyebrow">02 / KPIs</span></header>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content">
      <h2 class="type-h1 deck-title">Woran ihr uns messt</h2>
      <div class="deck-body">
        <table class="deck-table type-body">
          <thead>
            <tr>
              <!-- Feste Breiten (table-layout: fixed): die letzte
                   Spalte ohne width nimmt den Rest. -->
              <th class="type-eyebrow" style="width: 200px;">Dimension</th>
              <th class="type-eyebrow">Messgröße</th>
              <th class="type-eyebrow" style="width: 180px;">Heute</th>
              <th class="type-eyebrow" style="width: 180px;">Ziel</th>
            </tr>
          </thead>
          <tbody>
            <tr><td style="color: var(--mid);">Dimension A</td><td>Messgröße als ganzer Ausdruck</td><td style="color: var(--dark);">Ausgangswert</td><td class="value">Zielwert</td></tr>
            <tr><td style="color: var(--mid);">Dimension B</td><td>Messgröße</td><td style="color: var(--dark);">Ausgangswert</td><td class="value">Zielwert</td></tr>
            <tr><td style="color: var(--mid);">Dimension C</td><td>Messgröße</td><td style="color: var(--dark);">Ausgangswert</td><td class="value">Zielwert</td></tr>
          </tbody>
        </table>
        <!-- Offene Zielwerte in EINEM Satz im Lead erklären („werden in
             der Setup-Phase festgelegt") — nie als Chip je Zeile. -->
        <p class="source-note" style="margin: var(--space-8) 0 0;">Quelle: … in einem Satz</p>
      </div>
    </div>
  </section>


  <!-- ========================================================
       LAYOUT „ROADMAP (GANTT)" — Struktur-Diagramm (§7.11):
       Familienfarben als Kategorien-Code (eine Farbe je
       Werkstrom, konsistent durchs Deck), kräftige Balken =
       beschlossen, helle (opacity 0.4) = nach Priorisierung.
       Konstruktion: Label-Zone links, Chart ab x=260 (ein Monat
       = 128), Zeilenpitch 30, Balken 20 hoch (rx 10), Marker
       als Vertikale („Heute" Charcoal, Gates Berry gestrichelt),
       Bar-Label am Balkenende + 10. Abhängigkeiten gehören in
       die Bar-Labels, nicht in Fußnoten.
       Quelle: examples/beispiel-kundendeck.html.
       ======================================================== -->
  <section class="dslide" data-label="Roadmap">
    <header class="slide-head"><span class="type-eyebrow">01 / Kapitel</span></header>
    <footer class="slide-foot"><span class="foot-brand"><img src="data:," data-wm="b" alt="Bridgemaker" /><span>Kunde Projekttitel</span></span><span class="pagenum"></span></footer>
    <div class="dslide-content">
      <h2 class="type-h1 deck-title" style="max-width: 1000px;">Erst die Setup-Phase, dann die priorisierten Wellen</h2>
      <div class="deck-body">
        <svg viewBox="0 0 1200 330" preserveAspectRatio="xMinYMin meet" style="width: 100%; max-height: 448px;" role="img" aria-label="Beispiel-Roadmap über sechs Monate mit Setup-Phase, Decision Gate und zwei Werkströmen">
            <g class="chart-label-soft">
              <text x="260" y="14">Monat 1</text><text x="388" y="14">Monat 2</text>
              <text x="516" y="14">Monat 3</text><text x="644" y="14">Monat 4</text>
              <text x="772" y="14">Monat 5</text><text x="900" y="14">Monat 6</text>
            </g>
            <line x1="260" y1="26" x2="1156" y2="26" stroke="#C5C0B8" stroke-width="1" />
            <line x1="324" y1="26" x2="324" y2="322" stroke="var(--charcoal)" stroke-width="1.5" />
            <text x="332" y="46" class="chart-label" fill="var(--charcoal)">Heute</text>
            <line x1="452" y1="26" x2="452" y2="322" stroke="var(--bm-deep-berry, #8A3050)" stroke-width="1.5" stroke-dasharray="4 4" />
            <text x="460" y="46" class="chart-label" fill="var(--bm-deep-berry, #8A3050)">Decision Gate</text>

            <text x="0" y="76" class="chart-label" fill="var(--charcoal)">Setup-Phase</text>
            <rect x="328" y="62" width="120" height="20" rx="10" fill="var(--surface-mid-stone)" />
            <text x="460" y="76" class="chart-label-soft">Halber Satz, was hier passiert</text>

            <text x="0" y="136" class="chart-label" fill="var(--bm-deep-teal, #1D6B66)">Erster Werkstrom</text>
            <rect x="456" y="122" width="188" height="20" rx="10" fill="var(--bm-teal)" />
            <text x="654" y="136" class="chart-label-soft" style="fill: var(--bm-deep-teal, #1D6B66);">Initiative eins</text>
            <rect x="516" y="152" width="256" height="20" rx="10" fill="var(--bm-teal)" />
            <text x="782" y="166" class="chart-label-soft" style="fill: var(--bm-deep-teal, #1D6B66);">Initiative zwei</text>
            <rect x="644" y="182" width="192" height="20" rx="10" fill="var(--bm-teal)" opacity="0.4" />
            <text x="846" y="196" class="chart-label-soft" style="fill: var(--bm-deep-teal, #1D6B66);">Initiative drei, nach Priorisierung</text>

            <text x="0" y="256" class="chart-label" fill="var(--bm-deep-plum)">Zweiter Werkstrom</text>
            <rect x="516" y="242" width="256" height="20" rx="10" fill="var(--bm-purple)" />
            <text x="782" y="256" class="chart-label-soft" style="fill: var(--bm-deep-plum);">Initiative vier, nach dem Gate</text>
            <rect x="644" y="272" width="320" height="20" rx="10" fill="var(--bm-purple)" />
            <text x="974" y="286" class="chart-label-soft" style="fill: var(--bm-deep-plum);">Initiative fünf</text>
            <rect x="900" y="302" width="192" height="20" rx="10" fill="var(--bm-purple)" opacity="0.4" />
            <text x="890" y="316" text-anchor="end" class="chart-label-soft" style="fill: var(--bm-deep-plum);">Initiative sechs, nach Priorisierung</text>
        </svg>
      </div>
    </div>
  </section>
  <!-- ========================================================
       ROLLE „ZITAT" — die eine erlaubte Moment-Slide.
       Dunkle Stimmen-Fläche bg-stimme-teal (statisch) — Teal,
       damit die Stimme des Kunden ihre eigene Farbwelt hat und
       nicht dieselbe Purple-Geschichte erzählt wie der
       Schluss-CTA (Beschluss Nils, 2026-07-24; vorher
       bg-stimme-plum). Großes kursives Zitat, Attribution im
       Eyebrow-Stil. Ein Zitat pro Slide.
       Wie Cover und Schluss: KEINE Kopf- und Fußzeile.
       ======================================================== -->
  <section class="dslide dslide-dark dslide-moment" data-label="Zitat">
    <div class="kasane-layer bg-stimme-teal"></div>
    <div class="grain-layer grain-photo-screen"></div>
    <div class="dslide-content" style="max-width: 1080px;">
      <p class="type-display" style="margin: 0; color: var(--off-white); font-style: italic; font-weight: 500;">„Ein Satz aus einem echten Gespräch, der die Slide trägt — wörtlich, nicht geglättet."</p>
      <div class="type-eyebrow" style="color: var(--soft); margin-top: var(--space-10);">Vorname, Rolle — Kontext</div>
    </div>
  </section>

  <!-- ========================================================
       ROLLE „SCHLUSS" — Pflicht als letzte Slide, und sie ist
       ein STATEMENT, keine Content-Seite: EIN Satz in direkter
       Anrede („ihr"), bold und fast leer. Footer-Verlauf =
       Token bg-contact-cta-static (die statische Hälfte des
       contact-cta-Paars in tokens.css; das rohe bg-contact-cta
       bleibt als Fläche tabu) + konzentrische Konturen als
       Blickführung um den Content (node deck-topo-konturen.js
       schluss).
       Ansprechpartner klein und dezent als Textzeilen, OHNE
       Eyebrow (verifizierte E-Mail!). Keine Glass-Karte, kein
       Foto, keine To-do-Listen — nächste Schritte gehören auf
       eine eigene Content-Slide davor.
       ======================================================== -->
  <section class="dslide dslide-dark dslide-moment" data-label="Schluss" style="align-items: center; text-align: center; justify-content: center;">
    <div class="kasane-layer bg-contact-cta-static"></div>
    <svg class="kasane-layer" viewBox="0 0 1440 810" preserveAspectRatio="xMidYMid slice" style="z-index: 1; width: 100%; height: 100%;" aria-hidden="true"><g fill="none" stroke="#F5F1EB" stroke-width="1" opacity="0.12"><path d="M1294,405 L1292,420 L1289,434 L1283,449 L1275,463 L1265,476 L1255,489 L1243,502 L1231,514 L1219,527 L1208,539 L1197,551 L1187,563 L1177,576 L1166,589 L1156,602 L1144,614 L1132,627 L1118,639 L1103,651 L1088,663 L1070,674 L1052,684 L1032,693 L1011,702 L989,709 L967,716 L943,722 L919,727 L895,731 L870,735 L845,737 L820,739 L795,741 L770,742 L745,742 L720,742 L695,742 L670,741 L645,740 L620,738 L595,736 L571,733 L546,730 L522,725 L498,721 L474,715 L452,708 L430,700 L411,691 L392,680 L375,669 L359,658 L344,646 L330,635 L315,623 L301,612 L287,600 L274,589 L261,577 L248,565 L237,553 L226,540 L216,528 L206,515 L197,502 L189,489 L182,475 L176,461 L172,447 L168,433 L166,419 L166,405 L166,391 L166,376 L166,362 L167,348 L169,333 L171,319 L175,304 L181,290 L188,275 L197,262 L208,248 L221,236 L236,224 L253,213 L271,202 L289,192 L308,183 L328,174 L348,166 L368,158 L388,150 L408,143 L428,136 L449,129 L470,123 L491,116 L512,110 L534,104 L555,98 L577,92 L600,87 L623,82 L647,78 L671,76 L695,74 L720,73 L745,74 L769,76 L793,79 L817,83 L840,87 L862,92 L884,98 L906,104 L927,110 L949,117 L970,123 L991,129 L1011,136 L1032,143 L1052,151 L1071,159 L1091,167 L1110,176 L1128,185 L1146,195 L1162,205 L1178,216 L1193,228 L1207,240 L1219,252 L1231,265 L1241,278 L1251,291 L1261,305 L1269,318 L1277,332 L1283,347 L1287,361 L1291,376 L1293,390 L1294,405 Z" /><path d="M1462,405 L1462,424 L1460,443 L1457,462 L1452,481 L1445,500 L1437,518 L1428,536 L1418,554 L1407,572 L1396,590 L1383,608 L1369,625 L1354,643 L1337,659 L1318,675 L1296,690 L1273,703 L1248,716 L1221,727 L1194,737 L1165,746 L1136,754 L1107,762 L1078,770 L1049,777 L1021,784 L992,791 L963,798 L934,805 L905,811 L875,816 L845,821 L814,825 L783,828 L752,830 L720,831 L688,831 L657,829 L626,827 L595,822 L565,817 L535,811 L506,804 L478,796 L450,788 L423,780 L396,771 L369,762 L342,754 L315,745 L288,736 L261,727 L234,717 L208,706 L183,695 L159,682 L137,668 L117,653 L100,638 L85,621 L72,603 L61,586 L52,568 L44,550 L36,532 L29,514 L22,496 L16,478 L11,460 L8,442 L7,423 L7,405 L8,387 L10,368 L14,350 L19,332 L25,314 L31,296 L39,279 L47,261 L57,243 L67,226 L79,209 L93,192 L108,176 L125,160 L144,145 L164,131 L185,117 L208,104 L231,91 L254,78 L278,66 L302,54 L327,42 L353,31 L381,21 L409,12 L438,4 L467,-3 L498,-10 L528,-16 L560,-20 L591,-24 L623,-27 L655,-29 L688,-30 L720,-31 L752,-30 L784,-28 L816,-25 L848,-22 L879,-17 L910,-12 L940,-6 L971,0 L1000,7 L1029,15 L1058,24 L1084,34 L1110,45 L1134,57 L1157,70 L1179,83 L1200,97 L1220,111 L1239,125 L1258,140 L1277,154 L1296,168 L1317,181 L1338,195 L1359,209 L1380,224 L1398,240 L1415,256 L1429,274 L1440,292 L1447,310 L1453,329 L1456,348 L1459,367 L1461,386 L1462,405 Z" /><path d="M1695,405 L1695,430 L1692,455 L1686,480 L1678,504 L1668,529 L1657,553 L1643,576 L1629,600 L1613,623 L1597,645 L1579,668 L1560,690 L1539,712 L1515,733 L1489,752 L1460,770 L1431,788 L1400,805 L1368,821 L1335,836 L1302,851 L1268,866 L1234,879 L1198,892 L1162,904 L1125,915 L1087,926 L1048,934 L1008,943 L968,950 L928,957 L887,963 L846,968 L804,972 L762,975 L720,977 L678,977 L635,976 L593,974 L551,970 L508,967 L466,962 L424,956 L383,950 L342,942 L302,932 L263,921 L226,908 L191,894 L157,878 L125,861 L95,843 L65,825 L36,807 L8,789 L-20,770 L-48,751 L-75,732 L-101,713 L-126,692 L-149,671 L-167,648 L-181,625 L-191,600 L-197,575 L-199,550 L-200,525 L-200,500 L-199,476 L-199,452 L-200,429 L-202,405 L-202,381 L-202,358 L-200,334 L-197,310 L-192,286 L-185,262 L-177,239 L-166,215 L-152,192 L-137,170 L-122,147 L-106,125 L-88,102 L-68,81 L-45,60 L-20,40 L8,21 L38,4 L69,-13 L103,-28 L137,-42 L171,-56 L206,-69 L242,-82 L278,-95 L314,-107 L352,-118 L390,-128 L429,-137 L469,-145 L510,-152 L552,-157 L593,-161 L635,-163 L678,-164 L720,-162 L762,-158 L803,-153 L843,-146 L883,-138 L921,-129 L959,-119 L995,-109 L1032,-99 L1068,-89 L1104,-79 L1139,-69 L1174,-58 L1209,-46 L1243,-34 L1276,-22 L1310,-8 L1342,6 L1374,20 L1406,35 L1436,52 L1465,69 L1493,87 L1519,106 L1543,125 L1564,146 L1583,168 L1599,191 L1614,214 L1629,236 L1643,260 L1656,283 L1667,307 L1678,331 L1686,355 L1692,380 L1695,405 Z" /><path d="M1958,405 L1947,437 L1933,467 L1918,498 L1901,527 L1884,557 L1866,586 L1850,615 L1835,644 L1821,673 L1808,703 L1794,734 L1778,764 L1761,795 L1741,825 L1717,855 L1690,884 L1659,911 L1623,936 L1584,959 L1541,980 L1495,999 L1447,1016 L1398,1031 L1348,1044 L1297,1057 L1245,1068 L1194,1077 L1142,1086 L1090,1095 L1037,1102 L985,1107 L932,1111 L879,1114 L826,1115 L773,1116 L720,1115 L667,1113 L615,1110 L563,1107 L511,1103 L459,1098 L407,1093 L354,1087 L302,1080 L250,1072 L199,1062 L148,1051 L98,1038 L50,1024 L3,1007 L-42,989 L-85,969 L-127,948 L-166,926 L-203,903 L-238,878 L-272,853 L-304,827 L-336,801 L-366,774 L-394,746 L-421,718 L-447,689 L-470,660 L-490,629 L-507,598 L-521,567 L-531,535 L-537,502 L-541,470 L-542,437 L-540,405 L-536,373 L-531,341 L-524,309 L-515,277 L-502,246 L-487,215 L-468,185 L-448,155 L-426,126 L-403,97 L-378,69 L-352,41 L-325,13 L-296,-14 L-266,-40 L-233,-65 L-197,-89 L-158,-111 L-116,-132 L-73,-151 L-28,-168 L18,-185 L65,-200 L113,-214 L161,-226 L210,-238 L260,-248 L310,-258 L360,-266 L411,-273 L462,-279 L513,-284 L565,-289 L616,-293 L668,-299 L720,-303 L773,-308 L827,-311 L881,-313 L935,-312 L989,-309 L1043,-304 L1095,-295 L1147,-285 L1198,-273 L1248,-262 L1299,-249 L1348,-235 L1397,-220 L1445,-204 L1493,-187 L1539,-169 L1583,-149 L1626,-128 L1666,-105 L1703,-80 L1737,-54 L1768,-27 L1796,2 L1822,31 L1846,60 L1868,90 L1888,120 L1906,151 L1922,182 L1937,213 L1949,245 L1959,276 L1966,309 L1968,341 L1965,373 L1958,405 Z" /><path d="M2281,405 L2276,445 L2270,485 L2263,524 L2254,564 L2243,604 L2229,643 L2212,682 L2191,720 L2166,757 L2137,794 L2104,829 L2066,862 L2026,895 L1984,926 L1941,956 L1897,986 L1853,1016 L1808,1045 L1763,1075 L1716,1103 L1667,1131 L1616,1158 L1562,1182 L1505,1205 L1445,1225 L1384,1243 L1321,1259 L1257,1273 L1192,1286 L1126,1296 L1060,1306 L993,1315 L925,1322 L857,1328 L789,1333 L720,1336 L651,1337 L582,1336 L512,1333 L443,1328 L375,1320 L308,1309 L242,1296 L178,1281 L116,1263 L55,1244 L-4,1224 L-62,1202 L-118,1179 L-173,1155 L-226,1130 L-279,1105 L-331,1080 L-381,1053 L-428,1024 L-473,994 L-513,962 L-551,929 L-587,895 L-620,860 L-652,825 L-682,790 L-709,753 L-734,716 L-755,679 L-774,640 L-790,602 L-802,563 L-812,524 L-819,484 L-825,445 L-831,405 L-837,365 L-841,325 L-842,284 L-839,243 L-832,203 L-819,162 L-801,123 L-777,85 L-748,47 L-717,11 L-684,-25 L-650,-60 L-616,-95 L-580,-131 L-545,-166 L-508,-201 L-468,-235 L-426,-269 L-379,-301 L-329,-330 L-273,-356 L-212,-378 L-148,-397 L-82,-412 L-15,-425 L53,-436 L121,-446 L188,-455 L255,-463 L321,-471 L387,-478 L453,-487 L519,-495 L585,-503 L652,-510 L720,-516 L789,-521 L858,-523 L928,-524 L998,-521 L1067,-516 L1135,-507 L1203,-496 L1270,-485 L1337,-471 L1403,-456 L1467,-439 L1530,-420 L1591,-400 L1651,-377 L1709,-353 L1765,-327 L1817,-299 L1867,-270 L1912,-238 L1954,-204 L1993,-170 L2029,-134 L2064,-99 L2098,-63 L2130,-27 L2161,10 L2190,47 L2216,85 L2237,124 L2254,163 L2267,203 L2276,244 L2282,284 L2284,325 L2284,365 L2281,405 Z" /><path d="M2857,405 L2851,460 L2839,514 L2823,568 L2803,621 L2778,673 L2750,725 L2718,776 L2684,825 L2645,874 L2601,921 L2553,966 L2502,1010 L2451,1054 L2399,1097 L2347,1139 L2294,1182 L2239,1224 L2182,1265 L2120,1304 L2054,1340 L1985,1375 L1914,1408 L1842,1441 L1767,1472 L1690,1501 L1610,1528 L1527,1551 L1442,1571 L1354,1588 L1265,1602 L1175,1613 L1085,1622 L994,1629 L903,1635 L812,1639 L720,1642 L628,1642 L536,1640 L445,1635 L354,1626 L264,1614 L176,1600 L89,1582 L3,1563 L-81,1542 L-164,1521 L-247,1498 L-330,1475 L-411,1450 L-491,1423 L-568,1393 L-641,1359 L-710,1323 L-774,1284 L-833,1242 L-889,1199 L-942,1155 L-992,1110 L-1038,1064 L-1082,1017 L-1123,969 L-1162,921 L-1199,873 L-1235,824 L-1270,774 L-1302,724 L-1330,672 L-1355,620 L-1375,567 L-1391,514 L-1402,459 L-1408,405 L-1409,350 L-1405,296 L-1394,241 L-1373,188 L-1344,136 L-1307,85 L-1265,37 L-1219,-10 L-1171,-56 L-1121,-100 L-1071,-143 L-1021,-186 L-973,-230 L-926,-273 L-875,-315 L-820,-355 L-762,-394 L-699,-430 L-635,-465 L-570,-499 L-505,-534 L-439,-569 L-372,-604 L-304,-639 L-234,-673 L-161,-706 L-84,-737 L-4,-765 L80,-789 L168,-808 L258,-821 L349,-832 L441,-841 L534,-848 L627,-852 L720,-854 L813,-854 L907,-851 L1000,-845 L1092,-837 L1184,-827 L1275,-813 L1363,-795 L1450,-775 L1534,-751 L1616,-726 L1696,-698 L1773,-668 L1847,-636 L1919,-602 L1989,-568 L2057,-532 L2122,-495 L2184,-456 L2241,-415 L2295,-372 L2345,-328 L2392,-284 L2437,-238 L2481,-193 L2526,-148 L2571,-103 L2617,-57 L2663,-11 L2707,36 L2749,85 L2787,135 L2818,187 L2841,241 L2853,295 L2858,350 L2857,405 Z" /><path d="M3331,405 L3333,472 L3329,539 L3320,606 L3304,673 L3283,739 L3255,805 L3222,869 L3183,932 L3139,994 L3090,1055 L3036,1114 L2978,1172 L2917,1228 L2853,1284 L2788,1339 L2723,1394 L2657,1449 L2590,1505 L2520,1561 L2447,1615 L2368,1668 L2283,1718 L2193,1765 L2097,1808 L1997,1848 L1892,1883 L1783,1915 L1671,1942 L1556,1965 L1440,1985 L1322,2001 L1203,2015 L1083,2026 L962,2033 L841,2035 L720,2032 L600,2026 L480,2016 L362,2003 L245,1988 L130,1971 L15,1952 L-98,1931 L-209,1907 L-317,1877 L-421,1844 L-522,1808 L-620,1771 L-718,1732 L-814,1694 L-910,1654 L-1005,1614 L-1100,1573 L-1192,1530 L-1281,1484 L-1364,1434 L-1441,1381 L-1512,1324 L-1579,1267 L-1644,1208 L-1707,1148 L-1767,1087 L-1824,1025 L-1878,961 L-1927,896 L-1970,829 L-2007,761 L-2036,691 L-2055,620 L-2062,548 L-2058,476 L-2044,405 L-2023,335 L-1994,265 L-1962,197 L-1926,131 L-1890,65 L-1853,-1 L-1817,-66 L-1781,-130 L-1742,-195 L-1700,-259 L-1653,-322 L-1601,-383 L-1544,-444 L-1483,-502 L-1416,-559 L-1345,-614 L-1269,-667 L-1187,-717 L-1099,-762 L-1005,-804 L-908,-843 L-808,-879 L-706,-912 L-602,-942 L-497,-971 L-392,-997 L-285,-1022 L-178,-1047 L-71,-1070 L38,-1092 L149,-1111 L261,-1127 L374,-1140 L489,-1149 L604,-1155 L720,-1158 L836,-1157 L952,-1153 L1067,-1145 L1181,-1134 L1296,-1122 L1410,-1109 L1524,-1096 L1639,-1080 L1754,-1063 L1869,-1044 L1983,-1022 L2096,-997 L2206,-967 L2312,-932 L2412,-892 L2505,-846 L2591,-796 L2670,-742 L2745,-686 L2813,-628 L2877,-568 L2934,-507 L2987,-444 L3034,-381 L3076,-316 L3114,-252 L3148,-187 L3179,-121 L3207,-56 L3233,9 L3257,74 L3279,140 L3298,205 L3313,272 L3325,338 L3331,405 Z" /><path d="M4410,405 L4398,499 L4374,593 L4341,685 L4300,776 L4253,866 L4201,954 L4145,1040 L4088,1126 L4028,1211 L3967,1296 L3898,1378 L3821,1458 L3736,1535 L3642,1608 L3538,1677 L3427,1741 L3308,1800 L3184,1855 L3057,1905 L2927,1952 L2798,1998 L2670,2043 L2544,2090 L2421,2138 L2298,2188 L2173,2238 L2045,2287 L1915,2336 L1780,2382 L1640,2425 L1495,2462 L1346,2493 L1192,2515 L1036,2527 L878,2529 L720,2522 L564,2508 L410,2488 L259,2463 L112,2435 L-33,2404 L-176,2372 L-317,2340 L-458,2308 L-597,2276 L-735,2240 L-869,2201 L-1001,2158 L-1129,2112 L-1253,2063 L-1373,2010 L-1489,1953 L-1599,1894 L-1705,1831 L-1805,1766 L-1900,1698 L-1989,1628 L-2074,1556 L-2156,1483 L-2237,1409 L-2315,1334 L-2390,1258 L-2461,1180 L-2531,1101 L-2596,1020 L-2657,937 L-2709,852 L-2754,765 L-2789,677 L-2815,587 L-2832,496 L-2840,405 L-2839,314 L-2825,223 L-2797,133 L-2755,45 L-2702,-41 L-2641,-125 L-2573,-206 L-2501,-285 L-2427,-362 L-2351,-437 L-2275,-512 L-2201,-587 L-2126,-661 L-2049,-735 L-1968,-808 L-1885,-881 L-1800,-953 L-1710,-1025 L-1616,-1095 L-1516,-1162 L-1410,-1228 L-1297,-1289 L-1178,-1348 L-1053,-1402 L-923,-1451 L-787,-1496 L-647,-1536 L-502,-1570 L-354,-1598 L-203,-1621 L-51,-1639 L103,-1653 L257,-1662 L412,-1668 L566,-1669 L720,-1668 L873,-1663 L1026,-1655 L1179,-1646 L1332,-1637 L1486,-1629 L1642,-1618 L1798,-1606 L1954,-1589 L2109,-1567 L2260,-1538 L2408,-1502 L2548,-1458 L2681,-1406 L2805,-1347 L2922,-1283 L3032,-1215 L3134,-1145 L3231,-1072 L3321,-997 L3406,-921 L3486,-844 L3563,-766 L3639,-689 L3715,-612 L3792,-536 L3871,-459 L3952,-382 L4032,-304 L4112,-224 L4187,-141 L4256,-56 L4316,32 L4363,123 L4396,216 L4411,310 L4410,405 Z" /></g></svg>
    <div class="grain-layer grain-screen"></div>
    <div class="dslide-content" style="display: flex; flex-direction: column; align-items: center; gap: var(--space-16);">
      <img class="wordmark" src="data:," data-wm="w" alt="Bridgemaker" />
      <h2 class="type-display" style="margin: 0; max-width: 1000px; color: var(--off-white);">Startklar, sobald ihr das Go gebt</h2>
      <div>
        <div class="type-body" style="color: var(--off-white);">Vorname Nachname, Rolle</div>
        <div class="type-small" style="color: var(--bm-lavender-dark); margin-top: var(--space-1);">vorname.nachname@bridgemaker.com</div>
      </div>
    </div>
  </section>

</deck-stage>

<script>
/* ==== deck-stage.js (inline für Canvas) ==== */
/**
 * <deck-stage> — reusable web component for HTML decks.
 *
 * Handles:
 *  (a) speaker notes — reads <script type="application/json" id="speaker-notes">
 *      and posts {slideIndexChanged: N} to the parent window on nav.
 *  (b) keyboard navigation — ←/→, PgUp/PgDn, Space, Home/End, number keys.
 *  (c) press R to reset to slide 0 (with a tasteful keyboard hint).
 *  (d) bottom-center overlay showing slide count + hints, fades out on idle.
 *  (e) auto-scaling — inner canvas is a fixed design size (default 1920×1080)
 *      scaled with `transform: scale()` to fit the viewport, letterboxed.
 *      Set the `noscale` attribute to render at authored size (1:1) — the
 *      PPTX exporter sets this so its DOM capture sees unscaled geometry.
 *  (f) print — `@media print` lays every slide out as its own page at the
 *      design size, so the browser's Print → Save as PDF produces a clean
 *      one-page-per-slide PDF with no extra setup.
 *
 * Slides are HIDDEN, not unmounted. Non-active slides stay in the DOM with
 * `visibility: hidden` + `opacity: 0`, so their state (videos, iframes,
 * form inputs, React trees) is preserved across navigation.
 *
 * Lifecycle event — the component dispatches a `slidechange` CustomEvent on
 * itself whenever the active slide changes (including the initial mount).
 * The event bubbles and composes out of shadow DOM, so you can listen on
 * the <deck-stage> element or on document:
 *
 *   document.querySelector('deck-stage').addEventListener('slidechange', (e) => {
 *     e.detail.index         // new 0-based index
 *     e.detail.previousIndex // previous index, or -1 on init
 *     e.detail.total         // total slide count
 *     e.detail.slide         // the new active slide element
 *     e.detail.previousSlide // the prior slide element, or null on init
 *     e.detail.reason        // 'init' | 'keyboard' | 'click' | 'tap' | 'api'
 *   });
 *
 * Persistence: current slide index is saved to localStorage keyed by the
 * document path, so refresh returns you to the same place.
 *
 * Usage:
 *   <deck-stage width="1920" height="1080">
 *     <section data-label="Title">...</section>
 *     <section data-label="Agenda">...</section>
 *   </deck-stage>
 *
 * Slides are the direct element children of <deck-stage>. Each slide is
 * automatically tagged with:
 *   - data-screen-label="NN Label"   (1-indexed, for comment flow)
 *   - data-om-validate="no_overflowing_text,no_overlapping_text,slide_sized_text"
 */

(() => {
  const DESIGN_W_DEFAULT = 1920;
  const DESIGN_H_DEFAULT = 1080;
  const STORAGE_PREFIX = 'deck-stage:slide:';
  const OVERLAY_HIDE_MS = 1800;
  const VALIDATE_ATTR = 'no_overflowing_text,no_overlapping_text,slide_sized_text';

  const pad2 = (n) => String(n).padStart(2, '0');

  const stylesheet = `
    :host {
      position: fixed;
      inset: 0;
      display: block;
      background: #000;
      color: #fff;
      font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, Arial, sans-serif;
      overflow: hidden;
    }

    .stage {
      position: absolute;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .canvas {
      position: relative;
      transform-origin: center center;
      flex-shrink: 0;
      background: #fff;
      will-change: transform;
    }

    /* Slides live in light DOM (via <slot>) so authored CSS still applies.
       We absolutely position each slotted child to stack them. */
    ::slotted(*) {
      position: absolute !important;
      inset: 0 !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden;
      opacity: 0;
      pointer-events: none;
      visibility: hidden;
    }
    ::slotted([data-deck-active]) {
      opacity: 1;
      pointer-events: auto;
      visibility: visible;
    }

    /* Tap zones for mobile — back/forward thirds like Stories.
       Transparent, no visible UI, don't block the overlay. */
    .tapzones {
      position: fixed;
      inset: 0;
      display: flex;
      z-index: 2147482000;
      pointer-events: none;
    }
    .tapzone {
      flex: 1;
      pointer-events: auto;
      -webkit-tap-highlight-color: transparent;
    }
    /* Only activate tap zones on coarse pointers (touch devices). */
    @media (hover: hover) and (pointer: fine) {
      .tapzones { display: none; }
    }

    .overlay {
      position: fixed;
      left: 50%;
      bottom: 22px;
      transform: translate(-50%, 6px) scale(0.92);
      filter: blur(6px);
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 4px;
      background: #000;
      color: #fff;
      border-radius: 999px;
      font-size: 12px;
      font-feature-settings: "tnum" 1;
      letter-spacing: 0.01em;
      opacity: 0;
      pointer-events: none;
      transition: opacity 260ms ease, transform 260ms cubic-bezier(.2,.8,.2,1), filter 260ms ease;
      transform-origin: center bottom;
      z-index: 2147483000;
      user-select: none;
    }
    .overlay[data-visible] {
      opacity: 1;
      pointer-events: auto;
      transform: translate(-50%, 0) scale(1);
      filter: blur(0);
    }

    .btn {
      appearance: none;
      -webkit-appearance: none;
      background: transparent;
      border: 0;
      margin: 0;
      padding: 0;
      color: inherit;
      font: inherit;
      cursor: default;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      height: 28px;
      min-width: 28px;
      border-radius: 999px;
      color: rgba(255,255,255,0.72);
      transition: background 140ms ease, color 140ms ease;
      -webkit-tap-highlight-color: transparent;
    }
    .btn:hover { background: rgba(255,255,255,0.12); color: #fff; }
    .btn:active { background: rgba(255,255,255,0.18); }
    .btn:focus { outline: none; }
    .btn:focus-visible { outline: none; }
    .btn::-moz-focus-inner { border: 0; }
    .btn svg { width: 14px; height: 14px; display: block; }
    .btn.reset {
      font-size: 11px;
      font-weight: 500;
      letter-spacing: 0.02em;
      padding: 0 10px 0 12px;
      gap: 6px;
      color: rgba(255,255,255,0.72);
    }
    .btn.reset .kbd {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 16px;
      height: 16px;
      padding: 0 4px;
      font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
      font-size: 10px;
      line-height: 1;
      color: rgba(255,255,255,0.88);
      background: rgba(255,255,255,0.12);
      border-radius: 4px;
    }

    .count {
      font-variant-numeric: tabular-nums;
      color: #fff;
      font-weight: 500;
      padding: 0 8px;
      min-width: 42px;
      text-align: center;
      font-size: 12px;
    }
    .count .sep { color: rgba(255,255,255,0.45); margin: 0 3px; font-weight: 400; }
    .count .total { color: rgba(255,255,255,0.55); }

    .divider {
      width: 1px;
      height: 14px;
      background: rgba(255,255,255,0.18);
      margin: 0 2px;
    }

    /* ── Print: one page per slide, no chrome ────────────────────────────
       The screen layout stacks every slide at inset:0 inside a scaled
       canvas; for print we want them in document flow at the authored
       design size so the browser paginates one slide per sheet. The
       @page size is set from the width/height attributes via the inline
       <style id="deck-stage-print-page"> that connectedCallback injects
       into <head> (the @page at-rule has no effect inside shadow DOM). */
    @media print {
      :host {
        position: static;
        inset: auto;
        background: none;
        overflow: visible;
        color: inherit;
      }
      .stage { position: static; display: block; }
      .canvas {
        transform: none !important;
        width: auto !important;
        height: auto !important;
        background: none;
        will-change: auto;
      }
      ::slotted(*) {
        position: relative !important;
        inset: auto !important;
        width: var(--deck-design-w) !important;
        height: var(--deck-design-h) !important;
        box-sizing: border-box !important;
        opacity: 1 !important;
        visibility: visible !important;
        pointer-events: auto;
        break-after: page;
        page-break-after: always;
        break-inside: avoid;
        overflow: hidden;
      }
      ::slotted(*:last-child) {
        break-after: auto;
        page-break-after: auto;
      }
      .overlay, .tapzones { display: none !important; }
    }
  `;

  class DeckStage extends HTMLElement {
    static get observedAttributes() { return ['width', 'height', 'noscale']; }

    constructor() {
      super();
      this._root = this.attachShadow({ mode: 'open' });
      this._index = 0;
      this._slides = [];
      this._notes = [];
      this._hideTimer = null;
      this._mouseIdleTimer = null;
      this._storageKey = STORAGE_PREFIX + (location.pathname || '/');

      this._onKey = this._onKey.bind(this);
      this._onResize = this._onResize.bind(this);
      this._onSlotChange = this._onSlotChange.bind(this);
      this._onMouseMove = this._onMouseMove.bind(this);
      this._onTapBack = this._onTapBack.bind(this);
      this._onTapForward = this._onTapForward.bind(this);
    }

    get designWidth() {
      return parseInt(this.getAttribute('width'), 10) || DESIGN_W_DEFAULT;
    }
    get designHeight() {
      return parseInt(this.getAttribute('height'), 10) || DESIGN_H_DEFAULT;
    }

    connectedCallback() {
      this._render();
      this._loadNotes();
      this._syncPrintPageRule();
      window.addEventListener('keydown', this._onKey);
      window.addEventListener('resize', this._onResize);
      window.addEventListener('mousemove', this._onMouseMove, { passive: true });
      // Initial collection + layout happens via slotchange, which fires on mount.
    }

    disconnectedCallback() {
      window.removeEventListener('keydown', this._onKey);
      window.removeEventListener('resize', this._onResize);
      window.removeEventListener('mousemove', this._onMouseMove);
      if (this._hideTimer) clearTimeout(this._hideTimer);
      if (this._mouseIdleTimer) clearTimeout(this._mouseIdleTimer);
    }

    attributeChangedCallback() {
      if (this._canvas) {
        this._canvas.style.width = this.designWidth + 'px';
        this._canvas.style.height = this.designHeight + 'px';
        this._canvas.style.setProperty('--deck-design-w', this.designWidth + 'px');
        this._canvas.style.setProperty('--deck-design-h', this.designHeight + 'px');
        this._fit();
        this._syncPrintPageRule();
      }
    }

    _render() {
      const style = document.createElement('style');
      style.textContent = stylesheet;

      const stage = document.createElement('div');
      stage.className = 'stage';

      const canvas = document.createElement('div');
      canvas.className = 'canvas';
      canvas.style.width = this.designWidth + 'px';
      canvas.style.height = this.designHeight + 'px';
      canvas.style.setProperty('--deck-design-w', this.designWidth + 'px');
      canvas.style.setProperty('--deck-design-h', this.designHeight + 'px');

      const slot = document.createElement('slot');
      slot.addEventListener('slotchange', this._onSlotChange);
      canvas.appendChild(slot);
      stage.appendChild(canvas);

      // Tap zones (mobile): left third = back, right third = forward.
      const tapzones = document.createElement('div');
      tapzones.className = 'tapzones export-hidden';
      tapzones.setAttribute('aria-hidden', 'true');
      const tzBack = document.createElement('div');
      tzBack.className = 'tapzone tapzone--back';
      const tzMid = document.createElement('div');
      tzMid.className = 'tapzone tapzone--mid';
      tzMid.style.pointerEvents = 'none';
      const tzFwd = document.createElement('div');
      tzFwd.className = 'tapzone tapzone--fwd';
      tzBack.addEventListener('click', this._onTapBack);
      tzFwd.addEventListener('click', this._onTapForward);
      tapzones.append(tzBack, tzMid, tzFwd);

      // Overlay: compact, solid black, with clickable controls.
      const overlay = document.createElement('div');
      overlay.className = 'overlay export-hidden';
      overlay.setAttribute('role', 'toolbar');
      overlay.setAttribute('aria-label', 'Deck controls');
      overlay.innerHTML = `
        <button class="btn prev" type="button" aria-label="Previous slide" title="Previous (←)">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 3L5 8l5 5"/></svg>
        </button>
        <span class="count" aria-live="polite"><span class="current">1</span><span class="sep">/</span><span class="total">1</span></span>
        <button class="btn next" type="button" aria-label="Next slide" title="Next (→)">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 3l5 5-5 5"/></svg>
        </button>
        <span class="divider"></span>
        <button class="btn reset" type="button" aria-label="Reset to first slide" title="Reset (R)">Reset<span class="kbd">R</span></button>
      `;

      overlay.querySelector('.prev').addEventListener('click', () => this._go(this._index - 1, 'click'));
      overlay.querySelector('.next').addEventListener('click', () => this._go(this._index + 1, 'click'));
      overlay.querySelector('.reset').addEventListener('click', () => this._go(0, 'click'));

      this._root.append(style, stage, tapzones, overlay);
      this._canvas = canvas;
      this._slot = slot;
      this._overlay = overlay;
      this._countEl = overlay.querySelector('.current');
      this._totalEl = overlay.querySelector('.total');
    }

    /** @page must live in the document stylesheet — it's a no-op inside
     *  shadow DOM. Inject/update a single <head> style tag so the print
     *  sheet matches the design size and Save-as-PDF yields one slide per
     *  page with no margins. */
    _syncPrintPageRule() {
      const id = 'deck-stage-print-page';
      let tag = document.getElementById(id);
      if (!tag) {
        tag = document.createElement('style');
        tag.id = id;
        document.head.appendChild(tag);
      }
      tag.textContent =
        '@page { size: ' + this.designWidth + 'px ' + this.designHeight + 'px; margin: 0; } ' +
        '@media print { html, body { margin: 0 !important; padding: 0 !important; background: none !important; overflow: visible !important; height: auto !important; } ' +
        '* { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }';
    }

    _onSlotChange() {
      this._collectSlides();
      this._restoreIndex();
      this._applyIndex({ showOverlay: false, broadcast: true, reason: 'init' });
      this._fit();
    }

    _collectSlides() {
      const assigned = this._slot.assignedElements({ flatten: true });
      this._slides = assigned.filter((el) => {
        // Skip template/style/script nodes even if someone slots them.
        const tag = el.tagName;
        return tag !== 'TEMPLATE' && tag !== 'SCRIPT' && tag !== 'STYLE';
      });

      this._slides.forEach((slide, i) => {
        const n = i + 1;
        // Determine a label for comment flow: prefer explicit data-label,
        // then an existing data-screen-label, then first heading, else "Slide".
        let label = slide.getAttribute('data-label');
        if (!label) {
          const existing = slide.getAttribute('data-screen-label');
          if (existing) {
            // Strip any leading number the author may have included.
            label = existing.replace(/^\s*\d+\s*/, '').trim() || existing;
          }
        }
        if (!label) {
          const h = slide.querySelector('h1, h2, h3, [data-title]');
          if (h) label = (h.textContent || '').trim().slice(0, 40);
        }
        if (!label) label = 'Slide';
        slide.setAttribute('data-screen-label', `${pad2(n)} ${label}`);

        // Validation attribute for comment flow / auto-checks.
        if (!slide.hasAttribute('data-om-validate')) {
          slide.setAttribute('data-om-validate', VALIDATE_ATTR);
        }

        slide.setAttribute('data-deck-slide', String(i));
      });

      if (this._totalEl) this._totalEl.textContent = String(this._slides.length || 1);
      if (this._index >= this._slides.length) this._index = Math.max(0, this._slides.length - 1);
    }

    _loadNotes() {
      const tag = document.getElementById('speaker-notes');
      if (!tag) { this._notes = []; return; }
      try {
        const parsed = JSON.parse(tag.textContent || '[]');
        if (Array.isArray(parsed)) this._notes = parsed;
      } catch (e) {
        console.warn('[deck-stage] Failed to parse #speaker-notes JSON:', e);
        this._notes = [];
      }
    }

    _restoreIndex() {
      try {
        const raw = localStorage.getItem(this._storageKey);
        if (raw != null) {
          const n = parseInt(raw, 10);
          if (Number.isFinite(n) && n >= 0 && n < this._slides.length) {
            this._index = n;
          }
        }
      } catch (e) { /* ignore */ }
    }

    _persistIndex() {
      try { localStorage.setItem(this._storageKey, String(this._index)); }
      catch (e) { /* ignore */ }
    }

    _applyIndex({ showOverlay = true, broadcast = true, reason = 'init' } = {}) {
      if (!this._slides.length) return;
      const prev = this._prevIndex == null ? -1 : this._prevIndex;
      const curr = this._index;
      this._slides.forEach((s, i) => {
        if (i === curr) s.setAttribute('data-deck-active', '');
        else s.removeAttribute('data-deck-active');
      });
      if (this._countEl) this._countEl.textContent = String(curr + 1);
      this._persistIndex();

      if (broadcast) {
        // (1) Legacy: host-window postMessage for speaker-notes renderers.
        try { window.postMessage({ slideIndexChanged: curr }, '*'); } catch (e) {}

        // (2) In-page CustomEvent on the <deck-stage> element itself.
        //     Bubbles and composes out of shadow DOM so slide code can listen:
        //       document.querySelector('deck-stage').addEventListener('slidechange', e => {
        //         e.detail.index, e.detail.previousIndex, e.detail.total, e.detail.slide, e.detail.reason
        //       });
        const detail = {
          index: curr,
          previousIndex: prev,
          total: this._slides.length,
          slide: this._slides[curr] || null,
          previousSlide: prev >= 0 ? (this._slides[prev] || null) : null,
          reason: reason, // 'init' | 'keyboard' | 'click' | 'tap' | 'api'
        };
        this.dispatchEvent(new CustomEvent('slidechange', {
          detail,
          bubbles: true,
          composed: true,
        }));
      }

      this._prevIndex = curr;
      if (showOverlay) this._flashOverlay();
    }

    _flashOverlay() {
      if (!this._overlay) return;
      this._overlay.setAttribute('data-visible', '');
      if (this._hideTimer) clearTimeout(this._hideTimer);
      this._hideTimer = setTimeout(() => {
        this._overlay.removeAttribute('data-visible');
      }, OVERLAY_HIDE_MS);
    }

    _fit() {
      if (!this._canvas) return;
      // PPTX export sets noscale so the DOM capture sees authored-size
      // geometry — the scaled canvas is in shadow DOM, so the exporter's
      // resetTransformSelector can't reach .canvas.style.transform directly.
      if (this.hasAttribute('noscale')) {
        this._canvas.style.transform = 'none';
        return;
      }
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const s = Math.min(vw / this.designWidth, vh / this.designHeight);
      this._canvas.style.transform = `scale(${s})`;
    }

    _onResize() { this._fit(); }

    _onMouseMove() {
      // Keep overlay visible while mouse moves; hide after idle.
      this._flashOverlay();
    }

    _onTapBack(e) {
      e.preventDefault();
      this._go(this._index - 1, 'tap');
    }

    _onTapForward(e) {
      e.preventDefault();
      this._go(this._index + 1, 'tap');
    }

    _onKey(e) {
      // Ignore when the user is typing.
      const t = e.target;
      if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;

      const key = e.key;
      let handled = true;

      if (key === 'ArrowRight' || key === 'PageDown' || key === ' ' || key === 'Spacebar') {
        this._go(this._index + 1, 'keyboard');
      } else if (key === 'ArrowLeft' || key === 'PageUp') {
        this._go(this._index - 1, 'keyboard');
      } else if (key === 'Home') {
        this._go(0, 'keyboard');
      } else if (key === 'End') {
        this._go(this._slides.length - 1, 'keyboard');
      } else if (key === 'r' || key === 'R') {
        this._go(0, 'keyboard');
      } else if (/^[0-9]$/.test(key)) {
        // 1..9 jump to that slide; 0 jumps to 10.
        const n = key === '0' ? 9 : parseInt(key, 10) - 1;
        if (n < this._slides.length) this._go(n, 'keyboard');
      } else {
        handled = false;
      }

      if (handled) {
        e.preventDefault();
        this._flashOverlay();
      }
    }

    _go(i, reason = 'api') {
      if (!this._slides.length) return;
      const clamped = Math.max(0, Math.min(this._slides.length - 1, i));
      if (clamped === this._index) {
        this._flashOverlay();
        return;
      }
      this._index = clamped;
      this._applyIndex({ showOverlay: true, broadcast: true, reason });
    }

    // Public API ------------------------------------------------------------

    /** Current slide index (0-based). */
    get index() { return this._index; }
    /** Total slide count. */
    get length() { return this._slides.length; }
    /** Programmatically navigate. */
    goTo(i) { this._go(i, 'api'); }
    next() { this._go(this._index + 1, 'api'); }
    prev() { this._go(this._index - 1, 'api'); }
    reset() { this._go(0, 'api'); }
  }

  if (!customElements.get('deck-stage')) {
    customElements.define('deck-stage', DeckStage);
  }
})();

</script>
<script>
/* Wortmarke einmal definiert, an alle Stellen verteilt — niemals
   entfernen, sonst verlieren alle Fußzeilen das Logo. */
const BM_WM = { b: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzg2IiBoZWlnaHQ9IjQ4IiB2aWV3Qm94PSIwIDAgMzg2IDQ4IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8ZyBjbGlwLXBhdGg9InVybCgjY2xpcDBfOTM2Xzg5KSI+CjxwYXRoIGQ9Ik0xMi4yOTg3IDEuMjc3ODNDMTkuMTU4NCAxLjI3NzgzIDIzLjIyNzEgNS4zNjcyOCAyMy4yMjcxIDExLjA0MTRDMjMuMjcyNCAxMi43NDQ4IDIyLjc4NDMgMTQuNDE5MSAyMS44MzI5IDE1LjgyNDFDMjAuODgxNSAxNy4yMjkxIDE5LjUxNTYgMTguMjkyNyAxNy45MzEgMTguODYyNUMxOS44MDUgMTkuMzU2NyAyMS40NTg1IDIwLjQ3OTkgMjIuNjIxOCAyMi4wNDg4QzIzLjc4NTEgMjMuNjE3NyAyNC4zODk3IDI1LjUzOTcgMjQuMzM2NyAyNy41MDE1QzI0LjMzNjcgMzMuMzI5IDE5Ljg5ODEgMzcuNTIwNyAxMy4yNDAyIDM3LjUyMDdIMFYxLjI3NzgzSDEyLjI5ODdaTTExLjQ1OCAxNi42MTMzQzE0Ljk4ODcgMTYuNjEzMyAxNy4xMDcyIDE0LjU2ODYgMTcuMTA3MiAxMS41NTI2QzE3LjEwNzIgOC41MzY2MiAxNC45ODg3IDYuNDkxODkgMTEuMzA2NyA2LjQ5MTg5SDUuOTYwMlYxNi42MTMzSDExLjQ1OFpNMTIuMTEzNyAzMi4zMDY2QzE1Ljc0NTMgMzIuMzA2NiAxOC4xMTU5IDMwLjMxMyAxOC4xMTU5IDI3LjA5MjVDMTguMTE1OSAyMy44NzIxIDE2LjA0OCAyMS43NzYyIDEyLjMxNTUgMjEuNzc2Mkg1Ljk2MDJWMzIuMjk4MUwxMi4xMTM3IDMyLjMwNjZaIiBmaWxsPSJibGFjayI+PC9wYXRoPgo8cGF0aCBkPSJNNDIuOTIzMyAxOC41MDQ3QzQyLjI4OTIgMTguNDA0OSA0MS42NDg1IDE4LjM1MzYgNDEuMDA2NyAxOC4zNTE0QzM2LjQ2NzIgMTguMzUxNCAzNC4zOTkyIDIxLjAwOTUgMzQuMzk5MiAyNS42NjEzVjM3LjUyMDdIMjguNTE0NlYxMi42MjYySDM0LjIxNDJWMTYuNjEzNEMzNS4zNzQzIDEzLjkwNDEgMzguMDk4IDEyLjM1MzUgNDEuMzI2MSAxMi4zNTM1QzQxLjg1MDkgMTIuMzU1MSA0Mi4zNzQ0IDEyLjQwNjQgNDIuODg5NyAxMi41MDY5TDQyLjkyMzMgMTguNTA0N1oiIGZpbGw9ImJsYWNrIj48L3BhdGg+CjxwYXRoIGQ9Ik00OS4yODcyIDBDNTAuMzAzOSAwIDUxLjI3ODkgMC40MDkzMTcgNTEuOTk3OCAxLjEzNzg5QzUyLjcxNjcgMS44NjY0NyA1My4xMjA2IDIuODU0NjIgNTMuMTIwNiAzLjg4NDk4QzUzLjExNTYgNC42NDYxIDUyLjg4ODYgNS4zODg3NCA1Mi40NjgzIDYuMDE5NDhDNTIuMDQ3OSA2LjY1MDIzIDUxLjQ1MjkgNy4xNDA5NSA1MC43NTgxIDcuNDI5ODhDNTAuMDYzMyA3LjcxODgyIDQ5LjI5OTcgNy43OTMwOCA0OC41NjM0IDcuNjQzMzVDNDcuODI3IDcuNDkzNjEgNDcuMTUwOCA3LjEyNjU3IDQ2LjYxOTggNi41ODgzN0M0Ni4wODg3IDYuMDUwMTYgNDUuNzI2NiA1LjM2NDg0IDQ1LjU3ODggNC42MTg1OEM0NS40MzExIDMuODcyMzEgNDUuNTA0MyAzLjA5ODQzIDQ1Ljc4OTQgMi4zOTQyN0M0Ni4wNzQ1IDEuNjkwMSA0Ni41NTg3IDEuMDg3MDkgNDcuMTgxMSAwLjY2MTA3OEM0Ny44MDM1IDAuMjM1MDYzIDQ4LjUzNjIgMC4wMDUwNTc0NSA0OS4yODcyIDBaTTQ2LjQxMjIgMzcuNDg2N1YxMi42MjYySDUyLjIxMjdWMzcuNTIwOEw0Ni40MTIyIDM3LjQ4NjdaIiBmaWxsPSJibGFjayI+PC9wYXRoPgo8cGF0aCBkPSJNODEuMDU1MiAzMi45NzEzQzgxLjA1NTUgMzQuNDkxNCA4MS4xMzk3IDM2LjAxMDMgODEuMzA3MyAzNy41MjA4SDc1LjcwODZDNzUuNTU1OSAzNi40NTQgNzUuNDcxNiAzNS4zNzgzIDc1LjQ1NjQgMzQuMzAwNEM3NC42OTcgMzUuNTI5NiA3My42MjkgMzYuNTMyMyA3Mi4zNjE3IDM3LjIwNTlDNzEuMDk0NCAzNy44Nzk1IDY5LjY3MzIgMzguMTk5OSA2OC4yNDM3IDM4LjEzNDJDNjEuMTgyMiAzOC4xMzQyIDU2LjQ3NDYgMzIuNTExMiA1Ni40NzQ2IDI0Ljk5NjhDNTYuNDc0NiAxNy44NDAzIDYxLjI2NjMgMTEuOTYxNyA2OC4xNzY0IDExLjk2MTdDNzIuNDYzNyAxMS45NjE3IDc0LjYzMjYgMTMuOTU1MyA3NS4zODkyIDE1LjU0VjAuNTExMjNIODEuMDg4OEw4MS4wNTUyIDMyLjk3MTNaTTY4Ljg5OTQgMzIuOTIwMkM3Mi43MzI3IDMyLjkyMDIgNzUuNDA2IDI5LjY5OTcgNzUuNDA2IDI0Ljk0NTdDNzUuNDA2IDIwLjE5MTcgNzIuNzgzMiAxNy4yMjY5IDY4Ljk0OTggMTcuMjI2OUM2NS4xMTY1IDE3LjIyNjkgNjIuMjkxOSAyMC4yNDI5IDYyLjI5MTkgMjQuOTk2OEM2Mi4yOTE5IDI5Ljc1MDggNjQuOTE0NyAzMi45MjAyIDY4Ljg5OTQgMzIuOTIwMloiIGZpbGw9ImJsYWNrIj48L3BhdGg+CjxwYXRoIGQ9Ik0xMzcuMzM2IDMwLjQxNTNDMTM2LjAyNSAzNC43NjAzIDEzMi4xNSAzOC4yODc1IDEyNi4yNCAzOC4yODc1QzExOS41OSAzOC4yODc1IDExMy42ODkgMzMuMzgwMSAxMTMuNjg5IDI0Ljk0NTZDMTEzLjY4OSAxNy4wNzM0IDExOS40MzkgMTEuODU5NCAxMjUuNjM1IDExLjg1OTRDMTMzLjIgMTEuODU5NCAxMzcuNjM5IDE2LjkyMDEgMTM3LjYzOSAyNC43OTIzQzEzNy42NTYgMjUuNDI2NCAxMzcuNjA1IDI2LjA2MDYgMTM3LjQ4OCAyNi42ODM3SDExOS41NEMxMTkuNTg0IDI4LjQ0NzggMTIwLjMxNyAzMC4xMjIyIDEyMS41NzggMzEuMzM5M0MxMjIuODM4IDMyLjU1NjQgMTI0LjUyNCAzMy4yMTY4IDEyNi4yNjUgMzMuMTc1N0MxMjkuNzk2IDMzLjE3NTcgMTMxLjYyIDMxLjI4NDMgMTMyLjQyNyAyOC44MzA2TDEzNy4zMzYgMzAuNDE1M1pNMTMxLjczOCAyMi4zMzg2QzEzMS42MzcgMTkuNDI0OSAxMjkuNzI5IDE2LjgxNzggMTI1LjY5MyAxNi44MTc4QzEyNC4xODUgMTYuNzgzMSAxMjIuNzIyIDE3LjMzNjUgMTIxLjYwNSAxOC4zNjM5QzEyMC40ODggMTkuMzkxMyAxMTkuODAzIDIwLjgxNDEgMTE5LjY5MSAyMi4zMzg2SDEzMS43MzhaIiBmaWxsPSJibGFjayI+PC9wYXRoPgo8cGF0aCBkPSJNMTQxLjgyNiAzNy41MjA5VjEyLjYyNjNIMTQ3LjQyNFYxNS43OTU2QzE0OC44MzcgMTMuMjM5NyAxNTEuOTEzIDExLjkxMDYgMTU0LjY4OCAxMS45MTA2QzE1Ny45MTYgMTEuOTEwNiAxNjAuNzQgMTMuMzkzMSAxNjIuMDUyIDE2LjMwNjhDMTYzLjk2OCAxMy4wMzUyIDE2Ni44NDMgMTEuOTEwNiAxNzAuMDIxIDExLjkxMDZDMTc0LjQ2IDExLjkxMDYgMTc4LjY5NiAxNC43NzMzIDE3OC42OTYgMjEuMzY3NVYzNy41NTVIMTczLjA0N1YyMi4zMzg4QzE3My4wNDcgMTkuNDI1IDE3MS41ODUgMTcuMjI2OSAxNjguMzA2IDE3LjIyNjlDMTY1LjIyOSAxNy4yMjY5IDE2My4yMTIgMTkuNjgwNiAxNjMuMjEyIDIyLjc0NzdWMzcuNTIwOUgxNTcuNDYyVjIyLjMzODhDMTU3LjQ2MiAxOS40NzYxIDE1Ni4wNDkgMTcuMjI2OSAxNTIuNzIgMTcuMjI2OUMxNDkuNTkzIDE3LjIyNjkgMTQ3LjYyNiAxOS41Nzg0IDE0Ny42MjYgMjIuNzQ3N1YzNy41MjA5SDE0MS44MjZaIiBmaWxsPSJibGFjayI+PC9wYXRoPgo8cGF0aCBkPSJNMTk0LjM4MyAzOC4xODU0QzE4Ny4xNyAzOC4xODU0IDE4Mi41MyAzMi40MDkgMTgyLjUzIDI0Ljk0NThDMTgyLjUzIDE3LjczODEgMTg3LjIyMSAxMS45MTA2IDE5NC4yOTkgMTEuOTEwNkMxOTguNjM3IDExLjkxMDYgMjAwLjg1NiAxNC4yMTEgMjAxLjUxMiAxNS44OTc5VjEyLjYyNjNIMjA3LjIxMVYzMi45NzE0QzIwNy4yMTEgMzUuMDE2MSAyMDcuNDEzIDM3LjAwOTcgMjA3LjQ2MyAzNy41MjA5SDIwMS44NjVDMjAxLjY4NiAzNi4zMzY5IDIwMS42MDIgMzUuMTQwMyAyMDEuNjEzIDMzLjk0MjZDMjAwLjk0MSAzNS4yODE5IDE5OS45IDM2LjM5NTMgMTk4LjYxNyAzNy4xNDgyQzE5Ny4zMzQgMzcuOTAxMSAxOTUuODY0IDM4LjI2MTQgMTk0LjM4MyAzOC4xODU0Wk0xOTUuMDM5IDMzLjA3MzZDMTk4Ljg3MiAzMy4wNzM2IDIwMS41NDUgMjkuNzUwOSAyMDEuNTQ1IDI0Ljk0NThDMjAxLjU0NSAyMC4xNDA3IDE5OC45MjIgMTcuMDczNiAxOTUuMDM5IDE3LjA3MzZDMTkxLjE1NSAxNy4wNzM2IDE4OC4zODEgMjAuMTQwNyAxODguMzgxIDI0Ljk0NThDMTg4LjM4MSAyOS43NTA5IDE5MC45NTMgMzMuMDczNiAxOTUuMDM5IDMzLjA3MzZaIiBmaWxsPSJibGFjayI+PC9wYXRoPgo8cGF0aCBkPSJNMjI2LjE1OSAyMy4xNDY4TDIzNi40NDkgMzcuNTExMUgyMjkuMjg3TDIyMi4wNzQgMjcuMzM4NUwyMTkuMDQ3IDMwLjU1OVYzNy41MTExSDIxMy4yMTNWMC41MDE0NjVIMjE5LjAxNFYyMi42NTI3TDIyOC40NDYgMTIuNTgyNEgyMzYuMjEzTDIyNi4xNTkgMjMuMTQ2OFoiIGZpbGw9ImJsYWNrIj48L3BhdGg+CjxwYXRoIGQ9Ik0yNTkuODUzIDMwLjQwNTVDMjU4LjU0MSAzNC43NTA2IDI1NC42NTcgMzguMjc3NyAyNDguNzU2IDM4LjI3NzdDMjQyLjA5OCAzOC4yNzc3IDIzNi4xOTcgMzMuMzcwNCAyMzYuMTk3IDI0LjkzNTlDMjM2LjE5NyAxNy4wNjM3IDI0MS45NDcgMTEuODQ5NiAyNDguMTUxIDExLjg0OTZDMjU1LjcxNyAxMS44NDk2IDI2MC4xNTUgMTYuOTEwMyAyNjAuMTU1IDI0Ljc4MjVDMjYwLjE3MiAyNS40MTY3IDI2MC4xMjIgMjYuMDUwOCAyNjAuMDA0IDI2LjY3MzlIMjQyLjA0OEMyNDIuMDkyIDI4LjQzOCAyNDIuODI1IDMwLjExMjQgMjQ0LjA4NSAzMS4zMjk1QzI0NS4zNDYgMzIuNTQ2NiAyNDcuMDMyIDMzLjIwNzEgMjQ4Ljc3MyAzMy4xNjU5QzI1Mi4zMDQgMzMuMTY1OSAyNTQuMTE5IDMxLjI3NDUgMjU0LjkyNiAyOC44MjA4TDI1OS44NTMgMzAuNDA1NVpNMjU0LjI1NCAyMi4zMjg4QzI1NC4xNTMgMTkuNDE1MSAyNTIuMjM2IDE2LjgwODEgMjQ4LjIwMSAxNi44MDgxQzI0Ni42OTMgMTYuNzczMyAyNDUuMjMgMTcuMzI2OCAyNDQuMTEzIDE4LjM1NDFDMjQyLjk5NiAxOS4zODE1IDI0Mi4zMTEgMjAuODA0MyAyNDIuMTk5IDIyLjMyODhIMjU0LjI1NFoiIGZpbGw9ImJsYWNrIj48L3BhdGg+CjxwYXRoIGQ9Ik0yNzguNzE3IDE4LjQ5NUMyNzguMDgzIDE4LjM5NTEgMjc3LjQ0MiAxOC4zNDM5IDI3Ni44IDE4LjM0MTZDMjcyLjI2MSAxOC4zNDE2IDI3MC4xOTMgMjAuOTk5OCAyNzAuMTkzIDI1LjY1MTVWMzcuNTExSDI2NC4zMDhWMTIuNjE2NEgyNzAuMDA4VjE2LjYwMzZDMjcxLjE2OCAxMy44OTQzIDI3My44OTEgMTIuMzQzOCAyNzcuMTIgMTIuMzQzOEMyNzcuNjQ0IDEyLjM0NTMgMjc4LjE2OCAxMi4zOTY2IDI3OC42ODMgMTIuNDk3MUwyNzguNzE3IDE4LjQ5NVoiIGZpbGw9ImJsYWNrIj48L3BhdGg+CjxwYXRoIGQ9Ik0yOTAuNTUzIDI3LjA4MjlWMjEuOTE5OUgzODZWMjcuMDgyOUgyOTAuNTUzWiIgZmlsbD0iYmxhY2siPjwvcGF0aD4KPHBhdGggZmlsbC1ydWxlPSJldmVub2RkIiBjbGlwLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik05MS4wOTUyIDM4LjMwODFMODUuNzI1NyAzOS44ODU4Qzg2LjgxMTYgNDQuNDM1NiA5MS4xNzE2IDQ3Ljk5OTkgOTcuMjQ2MSA0Ny45OTk5QzEwNi40OTMgNDcuOTk5OSAxMDkuODU2IDQxLjgxNDYgMTA5Ljg1NiAzNS4xNjkyVjEyLjYyNjFIMTA0LjIwN1YxNS43OTU0QzEwMy4xNDcgMTMuNzUwNyAxMDAuNzc3IDEyLjE2NiA5Ni45NDM1IDEyLjE2NkM5MC4xODQ3IDEyLjE2NiA4NS41OTQ3IDE3LjYzNTcgODUuNTk0NyAyNC4yODFDODUuNTk0NyAzMS4yODQyIDkwLjM4NjQgMzYuMzk2IDk2Ljk0MzUgMzYuMzk2QzEwMC41MjUgMzYuMzk2IDEwMi45OTYgMzQuNzA5MSAxMDQuMDU1IDMyLjc2NjZWMzUuMzczN0MxMDQuMDU1IDQwLjQzNDQgMTAxLjczNSA0Mi44MzY5IDk3LjA5NDggNDIuODM2OUM5NS41OTA3IDQyLjg5MTggOTQuMTIxNiA0Mi4zNjk2IDkyLjk4MDggNDEuMzc0NkM5Mi4wNTQxIDQwLjU2NjMgOTEuMzk5NiAzOS40OTQzIDkxLjA5NTIgMzguMzA4MVpNOTcuOTAxOCAxNy4yNzc4QzEwMS41MzMgMTcuMjc3OCAxMDQuMjA3IDIwLjAyMTIgMTA0LjIwNyAyNC4yODFDMTA0LjIwNyAyOC41NzUgMTAxLjczNSAzMS4zMzUzIDk3LjkwMTggMzEuMzM1M0M5NC4wNjg0IDMxLjMzNTMgOTEuNDk2MSAyOC41MjM4IDkxLjQ5NjEgMjQuMjgxQzkxLjQ5NjEgMjAuMDM4MiA5NC4yNzAyIDE3LjI3NzggOTcuOTAxOCAxNy4yNzc4WiIgZmlsbD0iYmxhY2siPjwvcGF0aD4KPC9nPgo8ZGVmcz4KPGNsaXBQYXRoIGlkPSJjbGlwMF85MzZfODkiPgo8cmVjdCB3aWR0aD0iMzg2IiBoZWlnaHQ9IjQ4IiBmaWxsPSJ3aGl0ZSI+PC9yZWN0Pgo8L2NsaXBQYXRoPgo8L2RlZnM+Cjwvc3ZnPg==', w: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzg2IiBoZWlnaHQ9IjQ4IiB2aWV3Qm94PSIwIDAgMzg2IDQ4IiBmaWxsPSJub25lIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPgo8cGF0aCBkPSJNMTIuMjk4NyAxLjI3NzgzQzE5LjE1ODQgMS4yNzc4MyAyMy4yMjcxIDUuMzY3MjggMjMuMjI3MSAxMS4wNDE0QzIzLjI3MjQgMTIuNzQ0OCAyMi43ODQzIDE0LjQxOTEgMjEuODMyOSAxNS44MjQxQzIwLjg4MTUgMTcuMjI5MSAxOS41MTU2IDE4LjI5MjcgMTcuOTMxIDE4Ljg2MjVDMTkuODA1IDE5LjM1NjcgMjEuNDU4NSAyMC40Nzk5IDIyLjYyMTggMjIuMDQ4OEMyMy43ODUxIDIzLjYxNzcgMjQuMzg5NyAyNS41Mzk3IDI0LjMzNjcgMjcuNTAxNUMyNC4zMzY3IDMzLjMyOSAxOS44OTgxIDM3LjUyMDcgMTMuMjQwMiAzNy41MjA3SDBWMS4yNzc4M0gxMi4yOTg3Wk0xMS40NTggMTYuNjEzM0MxNC45ODg3IDE2LjYxMzMgMTcuMTA3MiAxNC41Njg2IDE3LjEwNzIgMTEuNTUyNkMxNy4xMDcyIDguNTM2NjIgMTQuOTg4NyA2LjQ5MTg5IDExLjMwNjcgNi40OTE4OUg1Ljk2MDJWMTYuNjEzM0gxMS40NThaTTEyLjExMzcgMzIuMzA2NkMxNS43NDUzIDMyLjMwNjYgMTguMTE1OSAzMC4zMTMgMTguMTE1OSAyNy4wOTI1QzE4LjExNTkgMjMuODcyMSAxNi4wNDggMjEuNzc2MiAxMi4zMTU1IDIxLjc3NjJINS45NjAyVjMyLjI5ODFMMTIuMTEzNyAzMi4zMDY2WiIgZmlsbD0id2hpdGUiPjwvcGF0aD4KPHBhdGggZD0iTTQyLjkyMzMgMTguNTA0N0M0Mi4yODkyIDE4LjQwNDkgNDEuNjQ4NSAxOC4zNTM2IDQxLjAwNjcgMTguMzUxNEMzNi40NjcyIDE4LjM1MTQgMzQuMzk5MiAyMS4wMDk1IDM0LjM5OTIgMjUuNjYxM1YzNy41MjA3SDI4LjUxNDZWMTIuNjI2MkgzNC4yMTQyVjE2LjYxMzRDMzUuMzc0MyAxMy45MDQxIDM4LjA5OCAxMi4zNTM1IDQxLjMyNjEgMTIuMzUzNUM0MS44NTA5IDEyLjM1NTEgNDIuMzc0NCAxMi40MDY0IDQyLjg4OTcgMTIuNTA2OUw0Mi45MjMzIDE4LjUwNDdaIiBmaWxsPSJ3aGl0ZSI+PC9wYXRoPgo8cGF0aCBkPSJNNDkuMjg3MiAwQzUwLjMwMzkgMCA1MS4yNzg5IDAuNDA5MzE3IDUxLjk5NzggMS4xMzc4OUM1Mi43MTY3IDEuODY2NDcgNTMuMTIwNiAyLjg1NDYyIDUzLjEyMDYgMy44ODQ5OEM1My4xMTU2IDQuNjQ2MSA1Mi44ODg2IDUuMzg4NzQgNTIuNDY4MyA2LjAxOTQ4QzUyLjA0NzkgNi42NTAyMyA1MS40NTI5IDcuMTQwOTUgNTAuNzU4MSA3LjQyOTg4QzUwLjA2MzMgNy43MTg4MiA0OS4yOTk3IDcuNzkzMDggNDguNTYzNCA3LjY0MzM1QzQ3LjgyNyA3LjQ5MzYxIDQ3LjE1MDggNy4xMjY1NyA0Ni42MTk4IDYuNTg4MzdDNDYuMDg4NyA2LjA1MDE2IDQ1LjcyNjYgNS4zNjQ4NCA0NS41Nzg4IDQuNjE4NThDNDUuNDMxMSAzLjg3MjMxIDQ1LjUwNDMgMy4wOTg0MyA0NS43ODk0IDIuMzk0MjdDNDYuMDc0NSAxLjY5MDEgNDYuNTU4NyAxLjA4NzA5IDQ3LjE4MTEgMC42NjEwNzhDNDcuODAzNSAwLjIzNTA2MyA0OC41MzYyIDAuMDA1MDU3NDUgNDkuMjg3MiAwWk00Ni40MTIyIDM3LjQ4NjdWMTIuNjI2Mkg1Mi4yMTI3VjM3LjUyMDhMNDYuNDEyMiAzNy40ODY3WiIgZmlsbD0id2hpdGUiPjwvcGF0aD4KPHBhdGggZD0iTTgxLjA1NTIgMzIuOTcxM0M4MS4wNTU1IDM0LjQ5MTQgODEuMTM5NyAzNi4wMTAzIDgxLjMwNzMgMzcuNTIwOEg3NS43MDg2Qzc1LjU1NTkgMzYuNDU0IDc1LjQ3MTYgMzUuMzc4MyA3NS40NTY0IDM0LjMwMDRDNzQuNjk3IDM1LjUyOTYgNzMuNjI5IDM2LjUzMjMgNzIuMzYxNyAzNy4yMDU5QzcxLjA5NDQgMzcuODc5NSA2OS42NzMyIDM4LjE5OTkgNjguMjQzNyAzOC4xMzQyQzYxLjE4MjIgMzguMTM0MiA1Ni40NzQ2IDMyLjUxMTIgNTYuNDc0NiAyNC45OTY4QzU2LjQ3NDYgMTcuODQwMyA2MS4yNjYzIDExLjk2MTcgNjguMTc2NCAxMS45NjE3QzcyLjQ2MzcgMTEuOTYxNyA3NC42MzI2IDEzLjk1NTMgNzUuMzg5MiAxNS41NFYwLjUxMTIzSDgxLjA4ODhMODEuMDU1MiAzMi45NzEzWk02OC44OTk0IDMyLjkyMDJDNzIuNzMyNyAzMi45MjAyIDc1LjQwNiAyOS42OTk3IDc1LjQwNiAyNC45NDU3Qzc1LjQwNiAyMC4xOTE3IDcyLjc4MzIgMTcuMjI2OSA2OC45NDk4IDE3LjIyNjlDNjUuMTE2NSAxNy4yMjY5IDYyLjI5MTkgMjAuMjQyOSA2Mi4yOTE5IDI0Ljk5NjhDNjIuMjkxOSAyOS43NTA4IDY0LjkxNDcgMzIuOTIwMiA2OC44OTk0IDMyLjkyMDJaIiBmaWxsPSJ3aGl0ZSI+PC9wYXRoPgo8cGF0aCBkPSJNMTM3LjMzNiAzMC40MTUzQzEzNi4wMjUgMzQuNzYwMyAxMzIuMTUgMzguMjg3NSAxMjYuMjQgMzguMjg3NUMxMTkuNTkgMzguMjg3NSAxMTMuNjg5IDMzLjM4MDEgMTEzLjY4OSAyNC45NDU2QzExMy42ODkgMTcuMDczNCAxMTkuNDM5IDExLjg1OTQgMTI1LjYzNSAxMS44NTk0QzEzMy4yIDExLjg1OTQgMTM3LjYzOSAxNi45MjAxIDEzNy42MzkgMjQuNzkyM0MxMzcuNjU2IDI1LjQyNjQgMTM3LjYwNSAyNi4wNjA2IDEzNy40ODggMjYuNjgzN0gxMTkuNTRDMTE5LjU4NCAyOC40NDc4IDEyMC4zMTcgMzAuMTIyMiAxMjEuNTc4IDMxLjMzOTNDMTIyLjgzOCAzMi41NTY0IDEyNC41MjQgMzMuMjE2OCAxMjYuMjY1IDMzLjE3NTdDMTI5Ljc5NiAzMy4xNzU3IDEzMS42MiAzMS4yODQzIDEzMi40MjcgMjguODMwNkwxMzcuMzM2IDMwLjQxNTNaTTEzMS43MzggMjIuMzM4NkMxMzEuNjM3IDE5LjQyNDkgMTI5LjcyOSAxNi44MTc4IDEyNS42OTMgMTYuODE3OEMxMjQuMTg1IDE2Ljc4MzEgMTIyLjcyMiAxNy4zMzY1IDEyMS42MDUgMTguMzYzOUMxMjAuNDg4IDE5LjM5MTMgMTE5LjgwMyAyMC44MTQxIDExOS42OTEgMjIuMzM4NkgxMzEuNzM4WiIgZmlsbD0id2hpdGUiPjwvcGF0aD4KPHBhdGggZD0iTTE0MS44MjYgMzcuNTIwOVYxMi42MjYzSDE0Ny40MjRWMTUuNzk1NkMxNDguODM3IDEzLjIzOTcgMTUxLjkxMyAxMS45MTA2IDE1NC42ODggMTEuOTEwNkMxNTcuOTE2IDExLjkxMDYgMTYwLjc0IDEzLjM5MzEgMTYyLjA1MiAxNi4zMDY4QzE2My45NjggMTMuMDM1MiAxNjYuODQzIDExLjkxMDYgMTcwLjAyMSAxMS45MTA2QzE3NC40NiAxMS45MTA2IDE3OC42OTYgMTQuNzczMyAxNzguNjk2IDIxLjM2NzVWMzcuNTU1SDE3My4wNDdWMjIuMzM4OEMxNzMuMDQ3IDE5LjQyNSAxNzEuNTg1IDE3LjIyNjkgMTY4LjMwNiAxNy4yMjY5QzE2NS4yMjkgMTcuMjI2OSAxNjMuMjEyIDE5LjY4MDYgMTYzLjIxMiAyMi43NDc3VjM3LjUyMDlIMTU3LjQ2MlYyMi4zMzg4QzE1Ny40NjIgMTkuNDc2MSAxNTYuMDQ5IDE3LjIyNjkgMTUyLjcyIDE3LjIyNjlDMTQ5LjU5MyAxNy4yMjY5IDE0Ny42MjYgMTkuNTc4NCAxNDcuNjI2IDIyLjc0NzdWMzcuNTIwOUgxNDEuODI2WiIgZmlsbD0id2hpdGUiPjwvcGF0aD4KPHBhdGggZD0iTTE5NC4zODMgMzguMTg1NEMxODcuMTcgMzguMTg1NCAxODIuNTMgMzIuNDA5IDE4Mi41MyAyNC45NDU4QzE4Mi41MyAxNy43MzgxIDE4Ny4yMjEgMTEuOTEwNiAxOTQuMjk5IDExLjkxMDZDMTk4LjYzNyAxMS45MTA2IDIwMC44NTYgMTQuMjExIDIwMS41MTIgMTUuODk3OVYxMi42MjYzSDIwNy4yMTFWMzIuOTcxNEMyMDcuMjExIDM1LjAxNjEgMjA3LjQxMyAzNy4wMDk3IDIwNy40NjMgMzcuNTIwOUgyMDEuODY1QzIwMS42ODYgMzYuMzM2OSAyMDEuNjAyIDM1LjE0MDMgMjAxLjYxMyAzMy45NDI2QzIwMC45NDEgMzUuMjgxOSAxOTkuOSAzNi4zOTUzIDE5OC42MTcgMzcuMTQ4MkMxOTcuMzM0IDM3LjkwMTEgMTk1Ljg2NCAzOC4yNjE0IDE5NC4zODMgMzguMTg1NFpNMTk1LjAzOSAzMy4wNzM2QzE5OC44NzIgMzMuMDczNiAyMDEuNTQ1IDI5Ljc1MDkgMjAxLjU0NSAyNC45NDU4QzIwMS41NDUgMjAuMTQwNyAxOTguOTIyIDE3LjA3MzYgMTk1LjAzOSAxNy4wNzM2QzE5MS4xNTUgMTcuMDczNiAxODguMzgxIDIwLjE0MDcgMTg4LjM4MSAyNC45NDU4QzE4OC4zODEgMjkuNzUwOSAxOTAuOTUzIDMzLjA3MzYgMTk1LjAzOSAzMy4wNzM2WiIgZmlsbD0id2hpdGUiPjwvcGF0aD4KPHBhdGggZD0iTTIyNi4xNTkgMjMuMTQ2OEwyMzYuNDQ5IDM3LjUxMTFIMjI5LjI4N0wyMjIuMDc0IDI3LjMzODVMMjE5LjA0NyAzMC41NTlWMzcuNTExMUgyMTMuMjEzVjAuNTAxNDY1SDIxOS4wMTRWMjIuNjUyN0wyMjguNDQ2IDEyLjU4MjRIMjM2LjIxM0wyMjYuMTU5IDIzLjE0NjhaIiBmaWxsPSJ3aGl0ZSI+PC9wYXRoPgo8cGF0aCBkPSJNMjU5Ljg1MyAzMC40MDU1QzI1OC41NDEgMzQuNzUwNiAyNTQuNjU3IDM4LjI3NzcgMjQ4Ljc1NiAzOC4yNzc3QzI0Mi4wOTggMzguMjc3NyAyMzYuMTk3IDMzLjM3MDQgMjM2LjE5NyAyNC45MzU5QzIzNi4xOTcgMTcuMDYzNyAyNDEuOTQ3IDExLjg0OTYgMjQ4LjE1MSAxMS44NDk2QzI1NS43MTcgMTEuODQ5NiAyNjAuMTU1IDE2LjkxMDMgMjYwLjE1NSAyNC43ODI1QzI2MC4xNzIgMjUuNDE2NyAyNjAuMTIyIDI2LjA1MDggMjYwLjAwNCAyNi42NzM5SDI0Mi4wNDhDMjQyLjA5MiAyOC40MzggMjQyLjgyNSAzMC4xMTI0IDI0NC4wODUgMzEuMzI5NUMyNDUuMzQ2IDMyLjU0NjYgMjQ3LjAzMiAzMy4yMDcxIDI0OC43NzMgMzMuMTY1OUMyNTIuMzA0IDMzLjE2NTkgMjU0LjExOSAzMS4yNzQ1IDI1NC45MjYgMjguODIwOEwyNTkuODUzIDMwLjQwNTVaTTI1NC4yNTQgMjIuMzI4OEMyNTQuMTUzIDE5LjQxNTEgMjUyLjIzNiAxNi44MDgxIDI0OC4yMDEgMTYuODA4MUMyNDYuNjkzIDE2Ljc3MzMgMjQ1LjIzIDE3LjMyNjggMjQ0LjExMyAxOC4zNTQxQzI0Mi45OTYgMTkuMzgxNSAyNDIuMzExIDIwLjgwNDMgMjQyLjE5OSAyMi4zMjg4SDI1NC4yNTRaIiBmaWxsPSJ3aGl0ZSI+PC9wYXRoPgo8cGF0aCBkPSJNMjc4LjcxNyAxOC40OTVDMjc4LjA4MyAxOC4zOTUxIDI3Ny40NDIgMTguMzQzOSAyNzYuOCAxOC4zNDE2QzI3Mi4yNjEgMTguMzQxNiAyNzAuMTkzIDIwLjk5OTggMjcwLjE5MyAyNS42NTE1VjM3LjUxMUgyNjQuMzA4VjEyLjYxNjRIMjcwLjAwOFYxNi42MDM2QzI3MS4xNjggMTMuODk0MyAyNzMuODkxIDEyLjM0MzggMjc3LjEyIDEyLjM0MzhDMjc3LjY0NCAxMi4zNDUzIDI3OC4xNjggMTIuMzk2NiAyNzguNjgzIDEyLjQ5NzFMMjc4LjcxNyAxOC40OTVaIiBmaWxsPSJ3aGl0ZSI+PC9wYXRoPgo8cGF0aCBkPSJNMjkwLjU1MyAyNy4wODI5VjIxLjkxOTlIMzg2VjI3LjA4MjlIMjkwLjU1M1oiIGZpbGw9IndoaXRlIj48L3BhdGg+CjxwYXRoIGZpbGwtcnVsZT0iZXZlbm9kZCIgY2xpcC1ydWxlPSJldmVub2RkIiBkPSJNOTEuMDk1MiAzOC4zMDgxTDg1LjcyNTcgMzkuODg1OEM4Ni44MTE2IDQ0LjQzNTYgOTEuMTcxNiA0Ny45OTk5IDk3LjI0NjEgNDcuOTk5OUMxMDYuNDkzIDQ3Ljk5OTkgMTA5Ljg1NiA0MS44MTQ2IDEwOS44NTYgMzUuMTY5MlYxMi42MjYxSDEwNC4yMDdWMTUuNzk1NEMxMDMuMTQ3IDEzLjc1MDcgMTAwLjc3NyAxMi4xNjYgOTYuOTQzNSAxMi4xNjZDOTAuMTg0NyAxMi4xNjYgODUuNTk0NyAxNy42MzU3IDg1LjU5NDcgMjQuMjgxQzg1LjU5NDcgMzEuMjg0MiA5MC4zODY0IDM2LjM5NiA5Ni45NDM1IDM2LjM5NkMxMDAuNTI1IDM2LjM5NiAxMDIuOTk2IDM0LjcwOTEgMTA0LjA1NSAzMi43NjY2VjM1LjM3MzdDMTA0LjA1NSA0MC40MzQ0IDEwMS43MzUgNDIuODM2OSA5Ny4wOTQ4IDQyLjgzNjlDOTUuNTkwNyA0Mi44OTE4IDk0LjEyMTYgNDIuMzY5NiA5Mi45ODA4IDQxLjM3NDZDOTIuMDU0MSA0MC41NjYzIDkxLjM5OTYgMzkuNDk0MyA5MS4wOTUyIDM4LjMwODFaTTk3LjkwMTggMTcuMjc3OEMxMDEuNTMzIDE3LjI3NzggMTA0LjIwNyAyMC4wMjEyIDEwNC4yMDcgMjQuMjgxQzEwNC4yMDcgMjguNTc1IDEwMS43MzUgMzEuMzM1MyA5Ny45MDE4IDMxLjMzNTNDOTQuMDY4NCAzMS4zMzUzIDkxLjQ5NjEgMjguNTIzOCA5MS40OTYxIDI0LjI4MUM5MS40OTYxIDIwLjAzODIgOTQuMjcwMiAxNy4yNzc4IDk3LjkwMTggMTcuMjc3OFoiIGZpbGw9IndoaXRlIj48L3BhdGg+Cjwvc3ZnPg==' };
document.querySelectorAll('img[data-wm]').forEach(i => { i.src = BM_WM[i.dataset.wm]; });
</script>
</body>
</html>

````
